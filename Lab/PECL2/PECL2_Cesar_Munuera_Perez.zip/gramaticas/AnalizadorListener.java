import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;

public class AnalizadorListener extends ElParserBaseListener {

	String arbol = "";
	ArrayList<String> al= new ArrayList<String>();

	public void printTree() {
		try{
			File file = new File("programa3.txt");
			BufferedWriter bw = new BufferedWriter(new FileWriter(file));
			for (String texto : al) {
				bw.write(texto + "\n");
			}
			bw.close();
		}catch(Exception e){
		}

    }
    
    @Override public void enterFichero(ElParser.FicheroContext ctx) { 
		arbol += "Fichero/";
		al.add(arbol);
    }


    @Override public void exitFichero(ElParser.FicheroContext ctx) {
		arbol = arbol.replace("exitFichero/", "");
		printTree();
	}
	

	@Override public void enterComentario(ElParser.ComentarioContext ctx) {
		arbol += "enterComentario/";
		al.add(arbol);
	}
	

	@Override public void exitComentario(ElParser.ComentarioContext ctx) { 
		arbol = arbol.replace("exitComentario/", "");
	}
	

    @Override public void enterTextos(ElParser.TextosContext ctx) { 
		arbol += "enterTextos/";
		al.add(arbol);
	}
	

    @Override public void exitTextos(ElParser.TextosContext ctx) { 
		arbol = arbol.replace("exitTextos/", "");
	}
	

    @Override public void enterLeer(ElParser.LeerContext ctx) { 
		arbol += "exitLeer/";
		al.add(arbol);
	}

	
	@Override public void exitLeer(ElParser.LeerContext ctx) { 
		arbol = arbol.replace("exitLeer/", "");
	}


    @Override public void enterDefinir(ElParser.DefinirContext ctx) { 
		arbol += "enterDefinir/";
		al.add(arbol);
	}


    @Override public void exitDefinir(ElParser.DefinirContext ctx) { 
		arbol = arbol.replace("exitDefinir/", "");
	}


	@Override public void enterEscribir(ElParser.EscribirContext ctx) { 
		arbol += "enterEscribir/";
		al.add(arbol);
	}


	@Override public void exitEscribir(ElParser.EscribirContext ctx) { 
		arbol = arbol.replace("exitEscribir/", "");
	}


	@Override public void enterSi(ElParser.SiContext ctx) { 
		arbol += "enterSi/";
		al.add(arbol);
	}


	@Override public void exitSi(ElParser.SiContext ctx) { 
		arbol = arbol.replace("exitSi/", "");
	}


	@Override public void enterSignos(ElParser.SignosContext ctx) { 
		arbol += "enterSignos/";
		al.add(arbol);
	}


	@Override public void exitSignos(ElParser.SignosContext ctx) { 
		arbol = arbol.replace("exitSignos/", "");
	}


	@Override public void enterPara(ElParser.ParaContext ctx) { 
		arbol += "enterPara/";
		al.add(arbol);
	}


	@Override public void exitPara(ElParser.ParaContext ctx) { 
		arbol = arbol.replace("exitPara/", "");
	}


	@Override public void enterAsignacion(ElParser.AsignacionContext ctx) { 
		arbol += "enterAsignacion/";
		al.add(arbol);
	}


	@Override public void exitAsignacion(ElParser.AsignacionContext ctx) { 
		arbol = arbol.replace("exitAsignacion/", "");
	}


	@Override public void enterAsignacion_funciones(ElParser.Asignacion_funcionesContext ctx) { 
		arbol += "enterAsignacion_funciones/";
		al.add(arbol);
	}


	@Override public void exitAsignacion_funciones(ElParser.Asignacion_funcionesContext ctx) { 
		arbol = arbol.replace("exitAsignacion_funciones/", "");
	}


	@Override public void enterMientras(ElParser.MientrasContext ctx) { 
		arbol += "enterMientras/";
		al.add(arbol);
	}


	@Override public void exitMientras(ElParser.MientrasContext ctx) { 
		arbol = arbol.replace("exitMientras/", "");
	}


	@Override public void enterComparacion(ElParser.ComparacionContext ctx) { 
		arbol += "enterComparacion/";
		al.add(arbol);
	}


	@Override public void exitComparacion(ElParser.ComparacionContext ctx) { 
		arbol = arbol.replace("exitComparacion/", "");
	}


	@Override public void enterAsignacion_restasuma(ElParser.Asignacion_restasumaContext ctx) {
		arbol += "enterAsignacion_restasuma/";
		al.add(arbol);
	}


	@Override public void exitAsignacion_restasuma(ElParser.Asignacion_restasumaContext ctx) { 
		arbol = arbol.replace("exitAsignacion_restasuma/", "");
	}


	@Override public void enterRepetir(ElParser.RepetirContext ctx) { 
		arbol += "enterRepetir/";
		al.add(arbol);
	}


	@Override public void exitRepetir(ElParser.RepetirContext ctx) { 
		arbol = arbol.replace("exitRepetir/", "");
	}


	@Override public void enterSegun(ElParser.SegunContext ctx) { 
		arbol += "enterSegun/";
		al.add(arbol);
	}


	@Override public void exitSegun(ElParser.SegunContext ctx) { 
		arbol = arbol.replace("exitSegun/", "");
	}


	@Override public void enterDimension(ElParser.DimensionContext ctx) { 
		arbol += "enterDimension/";
		al.add(arbol);
	}


	@Override public void exitDimension(ElParser.DimensionContext ctx) { 
		arbol = arbol.replace("exitDimension/", "");
	}


	@Override public void enterFunciones(ElParser.FuncionesContext ctx) { 
		arbol += "enterFunciones/";
		al.add(arbol);
	}


	@Override public void exitFunciones(ElParser.FuncionesContext ctx) { 
		arbol = arbol.replace("exitFunciones/", "");
	}


	@Override public void enterFuncion(ElParser.FuncionContext ctx) { 
		arbol += "enterFuncion/";
		al.add(arbol);
	}


	@Override public void exitFuncion(ElParser.FuncionContext ctx) { 
		arbol = arbol.replace("exitFuncion/", "");
	}


	@Override public void enterAbs(ElParser.AbsContext ctx) { 
		arbol += "enterAbs/";
		al.add(arbol);
	}


	@Override public void exitAbs(ElParser.AbsContext ctx) { 
		arbol = arbol.replace("exitAbs/", "");
	}


	@Override public void enterTrunc(ElParser.TruncContext ctx) { 
		arbol += "enterTrunc/";
		al.add(arbol);
	}


	@Override public void exitTrunc(ElParser.TruncContext ctx) { 
		arbol = arbol.replace("exitTrunc/", "");
	}


	@Override public void enterRedon(ElParser.RedonContext ctx) { 
		arbol += "enterRedon/";
		al.add(arbol);
	}


	@Override public void exitRedon(ElParser.RedonContext ctx) { 
		arbol = arbol.replace("exitRedon/", "");
	}


	@Override public void enterRc(ElParser.RcContext ctx) { 
		arbol += "enterRc/";
		al.add(arbol);
	}


	@Override public void exitRc(ElParser.RcContext ctx) { 
		arbol = arbol.replace("exitRc/", "");
	}


	@Override public void enterSen(ElParser.SenContext ctx) { 
		arbol += "enterSen/";
		al.add(arbol);
	}


	@Override public void exitSen(ElParser.SenContext ctx) { 
		arbol = arbol.replace("exitSen/", "");
	}


	@Override public void enterCos(ElParser.CosContext ctx) { 
		arbol += "enterCos/";
		al.add(arbol);
	}


	@Override public void exitCos(ElParser.CosContext ctx) { 
		arbol = arbol.replace("exitCos/", "");
	}


	@Override public void enterTan(ElParser.TanContext ctx) { 
		arbol += "enterTan/";
		al.add(arbol);
	}


	@Override public void exitTan(ElParser.TanContext ctx) { 
		arbol = arbol.replace("exitTan/", "");
	}


	@Override public void enterAsen(ElParser.AsenContext ctx) { 
		arbol += "enterAsen/";
		al.add(arbol);
	}


	@Override public void exitAsen(ElParser.AsenContext ctx) { 
		arbol = arbol.replace("exitAsen/", "");
	}


	@Override public void enterAcos(ElParser.AcosContext ctx) { 
		arbol += "enterAcos/";
		al.add(arbol);
	}


	@Override public void exitAcos(ElParser.AcosContext ctx) { 
		arbol = arbol.replace("exitAcos/", "");
	}


	@Override public void enterAtan(ElParser.AtanContext ctx) { 
		arbol += "enterAtan/";
		al.add(arbol);
	}


	@Override public void exitAtan(ElParser.AtanContext ctx) { 
		arbol = arbol.replace("exitAtan/", "");
	}


	@Override public void enterLn(ElParser.LnContext ctx) { 
		arbol += "enterLn/";
		al.add(arbol);
	}


	@Override public void exitLn(ElParser.LnContext ctx) { 
		arbol = arbol.replace("exitLn/", "");
	}


	@Override public void enterExp(ElParser.ExpContext ctx) { 
		arbol += "enterExp/";
		al.add(arbol);
	}


	@Override public void exitExp(ElParser.ExpContext ctx) { 
		arbol = arbol.replace("exitExp/", "");
	}


	@Override public void enterAzar(ElParser.AzarContext ctx) { 
		arbol += "enterAzar/";
		al.add(arbol);
	}


	@Override public void exitAzar(ElParser.AzarContext ctx) { 
		arbol = arbol.replace("exitAzar/", "");
	}


	@Override public void enterFunc_matematicas(ElParser.Func_matematicasContext ctx) { 
		arbol += "enterFunc_matematicas/";
		al.add(arbol);
	}


	@Override public void exitFunc_matematicas(ElParser.Func_matematicasContext ctx) { 
		arbol = arbol.replace("exitFunc_matematicas/", "");
	}


	@Override public void enterLongitud(ElParser.LongitudContext ctx) { 
		arbol += "enterLongitud/";
		al.add(arbol);
	}


	@Override public void exitLongitud(ElParser.LongitudContext ctx) { 
		arbol = arbol.replace("exitLongitud/", "");
	}


	@Override public void enterSub_cadena(ElParser.Sub_cadenaContext ctx) { 
		arbol += "enterSub_cadena/";
		al.add(arbol);
	}


	@Override public void exitSub_cadena(ElParser.Sub_cadenaContext ctx) { 
		arbol = arbol.replace("exitSub_cadena/", "");
	}


	@Override public void enterConcatenar(ElParser.ConcatenarContext ctx) { 
		arbol += "enterConcatenar/";
		al.add(arbol);
	}


	@Override public void exitConcatenar(ElParser.ConcatenarContext ctx) { 
		arbol = arbol.replace("exitConcatenar/", "");
	}


	@Override public void enterConvertir_a_numero(ElParser.Convertir_a_numeroContext ctx) { 
		arbol += "enterConvertir_a_numero/";
		al.add(arbol);
	}


	@Override public void exitConvertir_a_numero(ElParser.Convertir_a_numeroContext ctx) { 
		arbol = arbol.replace("exitConvertir_a_numero/", "");
	}


	@Override public void enterConvertir_a_texto(ElParser.Convertir_a_textoContext ctx) { 
		arbol += "enterConvertir_a_texto/";
		al.add(arbol);
	}


	@Override public void exitConvertir_a_texto(ElParser.Convertir_a_textoContext ctx) { 
		arbol = arbol.replace("exitConvertir_a_texto/", "");
	}


	@Override public void enterMayusculas(ElParser.MayusculasContext ctx) { 
		arbol += "enterMayusculas/";
		al.add(arbol);
	}


	@Override public void exitMayusculas(ElParser.MayusculasContext ctx) { 
		arbol = arbol.replace("exitMayusculas/", "");
	}


	@Override public void enterMinusculas(ElParser.MinusculasContext ctx) { 
		arbol += "enterMinusculas/";
		al.add(arbol);
	}


	@Override public void exitMinusculas(ElParser.MinusculasContext ctx) { 
		arbol = arbol.replace("exitMinusculas/", "");
	}


	@Override public void enterFunc_cadenas(ElParser.Func_cadenasContext ctx) { 
		arbol += "enterFunc_cadenas/";
		al.add(arbol);
	}


	@Override public void exitFunc_cadenas(ElParser.Func_cadenasContext ctx) { 
		arbol = arbol.replace("exitFunc_cadenas/", "");
	}

	@Override public void enterAlgoritmo(ElParser.AlgoritmoContext ctx) { 
		arbol += "enterAlgoritmo/";
		al.add(arbol);
	}


	@Override public void exitAlgoritmo(ElParser.AlgoritmoContext ctx) { 
		arbol = arbol.replace("exitAlgoritmo/", "");
	}


	@Override public void visitTerminal(TerminalNode node) { 
		String textFromNode = node.getText();
        if (textFromNode.equals("\t") | textFromNode.equals("    ")){
			textFromNode = "tab";
		}else if (textFromNode.equals("\r\n")){
			textFromNode = "intro";
		}
		al.add(arbol + textFromNode);
	}


	@Override public void visitErrorNode(ErrorNode node) { 

	}

}
