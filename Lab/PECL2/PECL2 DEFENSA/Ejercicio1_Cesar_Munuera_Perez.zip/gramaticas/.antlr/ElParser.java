// Generated from c:\Users\cesar\Desktop\Uni\Programas varios\ANTLR\gramaticas\ElParser.g4 by ANTLR 4.8
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class ElParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.8", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		INTRO=1, ESPACIO=2, COMA=3, MAS=4, MENOS=5, POR=6, ENTRE=7, POTENCIA=8, 
		MOD=9, CONJUNCION=10, DISYUNCION=11, NEGACION=12, FLECHA_ASIGNACION=13, 
		SIGNO_MENOR_QUE=14, SIGNO_MAYOR_QUE=15, SIGNO_IGUAL=16, SIGNO_MENOROIGUAL=17, 
		SIGNO_MAYOROIGUAL=18, SIGNO_DISTINTO=19, DOS_PUNTOS=20, PUNTO_Y_COMA=21, 
		APERTURA_CORCHETE=22, CIERRE_CORCHETE=23, APERTURA_PARENTESIS=24, CIERRE_PARENTESIS=25, 
		COMENT_ABRIR=26, COMENT_LINEA=27, CABECERA_DEFINIR=28, COMO=29, TIPO=30, 
		CABECERA_ESCRIBIR=31, CABECERA_LEER=32, CABECERA_SI=33, ENTONCES=34, SINO=35, 
		FINSI=36, CABECERA_PARA=37, HASTA=38, HACER=39, CON=40, PASO_A=41, PASO_B=42, 
		FINPARA=43, CABECERA_MIENTRAS=44, FINMIENTRAS=45, CABECERA_REPETIR=46, 
		QUE=47, CABECERA_SEGUN=48, DE=49, OTRO=50, MODO=51, FIN_SEGUN=52, CABECERA_FUNCION=53, 
		POR_VALOR=54, POR_REFERENCIA=55, FIN_FUNCION=56, CABECERA_DIMENSION=57, 
		CABECERA_ABS=58, CABECERA_TRUNC=59, CABECERA_REDON=60, CABECERA_RC=61, 
		CABECERA_SEN=62, CABECERA_COS=63, CABECERA_TAN=64, CABECERA_ASEN=65, CABECERA_ACOS=66, 
		CABECERA_ATAN=67, CABECERA_LN=68, CABECERA_EXP=69, CABECERA_AZAR=70, CABECERA_LONGITUD=71, 
		CABECERA_SUB_CADENA=72, CABECERA_CONCATENAR=73, CABECERA_CONVERTIR_A_NUMERO=74, 
		CABECERA_CONVERTIR_A_TEXTO=75, CABECERA_MAYUSCULAS=76, CABECERA_MINUSCULAS=77, 
		CABECERA_ALGORITMO=78, FIN_ALGORITMO=79, COMILLA=80, GUION=81, NUMEROS=82, 
		VAR=83, TOPRINT=84, TEXTO=85, NOMBRE_CL=86, COMENT_CERRAR=87, TEXTO_MULTILINEA=88, 
		FINAL_COMENT=89, TEXTO_LINEA=90;
	public static final int
		RULE_fichero = 0, RULE_comentario = 1, RULE_textos = 2, RULE_leer = 3, 
		RULE_definir = 4, RULE_escribir = 5, RULE_si = 6, RULE_signos = 7, RULE_para = 8, 
		RULE_asignacion = 9, RULE_asignacion_funciones = 10, RULE_mientras = 11, 
		RULE_comparacion = 12, RULE_asignacion_restasuma = 13, RULE_repetir = 14, 
		RULE_segun = 15, RULE_dimension = 16, RULE_funciones = 17, RULE_funcion = 18, 
		RULE_abs = 19, RULE_trunc = 20, RULE_redon = 21, RULE_rc = 22, RULE_sen = 23, 
		RULE_cos = 24, RULE_tan = 25, RULE_asen = 26, RULE_acos = 27, RULE_atan = 28, 
		RULE_ln = 29, RULE_exp = 30, RULE_azar = 31, RULE_func_matematicas = 32, 
		RULE_longitud = 33, RULE_sub_cadena = 34, RULE_concatenar = 35, RULE_convertir_a_numero = 36, 
		RULE_convertir_a_texto = 37, RULE_mayusculas = 38, RULE_minusculas = 39, 
		RULE_func_cadenas = 40, RULE_algoritmo = 41;
	private static String[] makeRuleNames() {
		return new String[] {
			"fichero", "comentario", "textos", "leer", "definir", "escribir", "si", 
			"signos", "para", "asignacion", "asignacion_funciones", "mientras", "comparacion", 
			"asignacion_restasuma", "repetir", "segun", "dimension", "funciones", 
			"funcion", "abs", "trunc", "redon", "rc", "sen", "cos", "tan", "asen", 
			"acos", "atan", "ln", "exp", "azar", "func_matematicas", "longitud", 
			"sub_cadena", "concatenar", "convertir_a_numero", "convertir_a_texto", 
			"mayusculas", "minusculas", "func_cadenas", "algoritmo"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, "'/*'", "'//'", null, "'Como'", null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, "'*/'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "INTRO", "ESPACIO", "COMA", "MAS", "MENOS", "POR", "ENTRE", "POTENCIA", 
			"MOD", "CONJUNCION", "DISYUNCION", "NEGACION", "FLECHA_ASIGNACION", "SIGNO_MENOR_QUE", 
			"SIGNO_MAYOR_QUE", "SIGNO_IGUAL", "SIGNO_MENOROIGUAL", "SIGNO_MAYOROIGUAL", 
			"SIGNO_DISTINTO", "DOS_PUNTOS", "PUNTO_Y_COMA", "APERTURA_CORCHETE", 
			"CIERRE_CORCHETE", "APERTURA_PARENTESIS", "CIERRE_PARENTESIS", "COMENT_ABRIR", 
			"COMENT_LINEA", "CABECERA_DEFINIR", "COMO", "TIPO", "CABECERA_ESCRIBIR", 
			"CABECERA_LEER", "CABECERA_SI", "ENTONCES", "SINO", "FINSI", "CABECERA_PARA", 
			"HASTA", "HACER", "CON", "PASO_A", "PASO_B", "FINPARA", "CABECERA_MIENTRAS", 
			"FINMIENTRAS", "CABECERA_REPETIR", "QUE", "CABECERA_SEGUN", "DE", "OTRO", 
			"MODO", "FIN_SEGUN", "CABECERA_FUNCION", "POR_VALOR", "POR_REFERENCIA", 
			"FIN_FUNCION", "CABECERA_DIMENSION", "CABECERA_ABS", "CABECERA_TRUNC", 
			"CABECERA_REDON", "CABECERA_RC", "CABECERA_SEN", "CABECERA_COS", "CABECERA_TAN", 
			"CABECERA_ASEN", "CABECERA_ACOS", "CABECERA_ATAN", "CABECERA_LN", "CABECERA_EXP", 
			"CABECERA_AZAR", "CABECERA_LONGITUD", "CABECERA_SUB_CADENA", "CABECERA_CONCATENAR", 
			"CABECERA_CONVERTIR_A_NUMERO", "CABECERA_CONVERTIR_A_TEXTO", "CABECERA_MAYUSCULAS", 
			"CABECERA_MINUSCULAS", "CABECERA_ALGORITMO", "FIN_ALGORITMO", "COMILLA", 
			"GUION", "NUMEROS", "VAR", "TOPRINT", "TEXTO", "NOMBRE_CL", "COMENT_CERRAR", 
			"TEXTO_MULTILINEA", "FINAL_COMENT", "TEXTO_LINEA"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "ElParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public ElParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class FicheroContext extends ParserRuleContext {
		public List<ComentarioContext> comentario() {
			return getRuleContexts(ComentarioContext.class);
		}
		public ComentarioContext comentario(int i) {
			return getRuleContext(ComentarioContext.class,i);
		}
		public List<AlgoritmoContext> algoritmo() {
			return getRuleContexts(AlgoritmoContext.class);
		}
		public AlgoritmoContext algoritmo(int i) {
			return getRuleContext(AlgoritmoContext.class,i);
		}
		public List<FuncionContext> funcion() {
			return getRuleContexts(FuncionContext.class);
		}
		public FuncionContext funcion(int i) {
			return getRuleContext(FuncionContext.class,i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public FicheroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fichero; }
	}

	public final FicheroContext fichero() throws RecognitionException {
		FicheroContext _localctx = new FicheroContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_fichero);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(88); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				setState(88);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case COMENT_ABRIR:
				case COMENT_LINEA:
					{
					setState(84);
					comentario();
					}
					break;
				case CABECERA_ALGORITMO:
					{
					setState(85);
					algoritmo();
					}
					break;
				case CABECERA_FUNCION:
					{
					setState(86);
					funcion();
					}
					break;
				case INTRO:
					{
					setState(87);
					match(INTRO);
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(90); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << INTRO) | (1L << COMENT_ABRIR) | (1L << COMENT_LINEA) | (1L << CABECERA_FUNCION))) != 0) || _la==CABECERA_ALGORITMO );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ComentarioContext extends ParserRuleContext {
		public TerminalNode COMENT_ABRIR() { return getToken(ElParser.COMENT_ABRIR, 0); }
		public TerminalNode COMENT_CERRAR() { return getToken(ElParser.COMENT_CERRAR, 0); }
		public List<TextosContext> textos() {
			return getRuleContexts(TextosContext.class);
		}
		public TextosContext textos(int i) {
			return getRuleContext(TextosContext.class,i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public TerminalNode COMENT_LINEA() { return getToken(ElParser.COMENT_LINEA, 0); }
		public TerminalNode FINAL_COMENT() { return getToken(ElParser.FINAL_COMENT, 0); }
		public ComentarioContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comentario; }
	}

	public final ComentarioContext comentario() throws RecognitionException {
		ComentarioContext _localctx = new ComentarioContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_comentario);
		int _la;
		try {
			setState(109);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case COMENT_ABRIR:
				enterOuterAlt(_localctx, 1);
				{
				setState(92);
				match(COMENT_ABRIR);
				setState(97);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==INTRO || _la==TEXTO_MULTILINEA || _la==TEXTO_LINEA) {
					{
					setState(95);
					_errHandler.sync(this);
					switch (_input.LA(1)) {
					case TEXTO_MULTILINEA:
					case TEXTO_LINEA:
						{
						setState(93);
						textos();
						}
						break;
					case INTRO:
						{
						setState(94);
						match(INTRO);
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					setState(99);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(100);
				match(COMENT_CERRAR);
				}
				break;
			case COMENT_LINEA:
				enterOuterAlt(_localctx, 2);
				{
				setState(101);
				match(COMENT_LINEA);
				setState(105);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==TEXTO_MULTILINEA || _la==TEXTO_LINEA) {
					{
					{
					setState(102);
					textos();
					}
					}
					setState(107);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(108);
				match(FINAL_COMENT);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TextosContext extends ParserRuleContext {
		public List<TerminalNode> TEXTO_MULTILINEA() { return getTokens(ElParser.TEXTO_MULTILINEA); }
		public TerminalNode TEXTO_MULTILINEA(int i) {
			return getToken(ElParser.TEXTO_MULTILINEA, i);
		}
		public List<TerminalNode> TEXTO_LINEA() { return getTokens(ElParser.TEXTO_LINEA); }
		public TerminalNode TEXTO_LINEA(int i) {
			return getToken(ElParser.TEXTO_LINEA, i);
		}
		public TextosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_textos; }
	}

	public final TextosContext textos() throws RecognitionException {
		TextosContext _localctx = new TextosContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_textos);
		try {
			int _alt;
			setState(121);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TEXTO_MULTILINEA:
				enterOuterAlt(_localctx, 1);
				{
				setState(112); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(111);
						match(TEXTO_MULTILINEA);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(114); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,6,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				}
				break;
			case TEXTO_LINEA:
				enterOuterAlt(_localctx, 2);
				{
				setState(117); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(116);
						match(TEXTO_LINEA);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(119); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,7,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LeerContext extends ParserRuleContext {
		public TerminalNode CABECERA_LEER() { return getToken(ElParser.CABECERA_LEER, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public TerminalNode PUNTO_Y_COMA() { return getToken(ElParser.PUNTO_Y_COMA, 0); }
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public ComentarioContext comentario() {
			return getRuleContext(ComentarioContext.class,0);
		}
		public LeerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_leer; }
	}

	public final LeerContext leer() throws RecognitionException {
		LeerContext _localctx = new LeerContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_leer);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(123);
			match(CABECERA_LEER);
			setState(125); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(124);
				match(ESPACIO);
				}
				}
				setState(127); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(129);
			match(VAR);
			setState(137);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ESPACIO || _la==PUNTO_Y_COMA) {
				{
				setState(133);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==ESPACIO) {
					{
					{
					setState(130);
					match(ESPACIO);
					}
					}
					setState(135);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(136);
				match(PUNTO_Y_COMA);
				}
			}

			setState(140); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(139);
					match(INTRO);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(142); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,12,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(145);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,13,_ctx) ) {
			case 1:
				{
				setState(144);
				comentario();
				}
				break;
			}
			setState(150);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,14,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(147);
					match(INTRO);
					}
					} 
				}
				setState(152);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,14,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DefinirContext extends ParserRuleContext {
		public TerminalNode CABECERA_DEFINIR() { return getToken(ElParser.CABECERA_DEFINIR, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public TerminalNode COMO() { return getToken(ElParser.COMO, 0); }
		public TerminalNode TIPO() { return getToken(ElParser.TIPO, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public TerminalNode PUNTO_Y_COMA() { return getToken(ElParser.PUNTO_Y_COMA, 0); }
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public ComentarioContext comentario() {
			return getRuleContext(ComentarioContext.class,0);
		}
		public DefinirContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_definir; }
	}

	public final DefinirContext definir() throws RecognitionException {
		DefinirContext _localctx = new DefinirContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_definir);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(153);
			match(CABECERA_DEFINIR);
			setState(155); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(154);
				match(ESPACIO);
				}
				}
				setState(157); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(159);
			match(VAR);
			setState(161); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(160);
				match(ESPACIO);
				}
				}
				setState(163); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(165);
			match(COMO);
			setState(167); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(166);
				match(ESPACIO);
				}
				}
				setState(169); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(171);
			match(TIPO);
			setState(175);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(172);
				match(ESPACIO);
				}
				}
				setState(177);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(179);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==PUNTO_Y_COMA) {
				{
				setState(178);
				match(PUNTO_Y_COMA);
				}
			}

			setState(182); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(181);
					match(INTRO);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(184); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,20,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(187);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,21,_ctx) ) {
			case 1:
				{
				setState(186);
				comentario();
				}
				break;
			}
			setState(192);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,22,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(189);
					match(INTRO);
					}
					} 
				}
				setState(194);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,22,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EscribirContext extends ParserRuleContext {
		public TerminalNode CABECERA_ESCRIBIR() { return getToken(ElParser.CABECERA_ESCRIBIR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> VAR() { return getTokens(ElParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ElParser.VAR, i);
		}
		public TerminalNode PUNTO_Y_COMA() { return getToken(ElParser.PUNTO_Y_COMA, 0); }
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public ComentarioContext comentario() {
			return getRuleContext(ComentarioContext.class,0);
		}
		public List<TerminalNode> TOPRINT() { return getTokens(ElParser.TOPRINT); }
		public TerminalNode TOPRINT(int i) {
			return getToken(ElParser.TOPRINT, i);
		}
		public List<TerminalNode> COMA() { return getTokens(ElParser.COMA); }
		public TerminalNode COMA(int i) {
			return getToken(ElParser.COMA, i);
		}
		public List<TerminalNode> MAS() { return getTokens(ElParser.MAS); }
		public TerminalNode MAS(int i) {
			return getToken(ElParser.MAS, i);
		}
		public List<TerminalNode> APERTURA_PARENTESIS() { return getTokens(ElParser.APERTURA_PARENTESIS); }
		public TerminalNode APERTURA_PARENTESIS(int i) {
			return getToken(ElParser.APERTURA_PARENTESIS, i);
		}
		public List<TerminalNode> CIERRE_PARENTESIS() { return getTokens(ElParser.CIERRE_PARENTESIS); }
		public TerminalNode CIERRE_PARENTESIS(int i) {
			return getToken(ElParser.CIERRE_PARENTESIS, i);
		}
		public List<TerminalNode> NUMEROS() { return getTokens(ElParser.NUMEROS); }
		public TerminalNode NUMEROS(int i) {
			return getToken(ElParser.NUMEROS, i);
		}
		public List<TerminalNode> POR_VALOR() { return getTokens(ElParser.POR_VALOR); }
		public TerminalNode POR_VALOR(int i) {
			return getToken(ElParser.POR_VALOR, i);
		}
		public List<TerminalNode> POR_REFERENCIA() { return getTokens(ElParser.POR_REFERENCIA); }
		public TerminalNode POR_REFERENCIA(int i) {
			return getToken(ElParser.POR_REFERENCIA, i);
		}
		public List<Func_matematicasContext> func_matematicas() {
			return getRuleContexts(Func_matematicasContext.class);
		}
		public Func_matematicasContext func_matematicas(int i) {
			return getRuleContext(Func_matematicasContext.class,i);
		}
		public List<Func_cadenasContext> func_cadenas() {
			return getRuleContexts(Func_cadenasContext.class);
		}
		public Func_cadenasContext func_cadenas(int i) {
			return getRuleContext(Func_cadenasContext.class,i);
		}
		public EscribirContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_escribir; }
	}

	public final EscribirContext escribir() throws RecognitionException {
		EscribirContext _localctx = new EscribirContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_escribir);
		int _la;
		try {
			int _alt;
			setState(478);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,82,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(195);
				match(CABECERA_ESCRIBIR);
				setState(197); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(196);
					match(ESPACIO);
					}
					}
					setState(199); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==ESPACIO );
				{
				setState(255);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case TOPRINT:
					{
					{
					setState(201);
					match(TOPRINT);
					setState(225);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,28,_ctx);
					while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
						if ( _alt==1 ) {
							{
							{
							setState(220);
							_errHandler.sync(this);
							switch ( getInterpreter().adaptivePredict(_input,27,_ctx) ) {
							case 1:
								{
								setState(203); 
								_errHandler.sync(this);
								_la = _input.LA(1);
								do {
									{
									{
									setState(202);
									match(ESPACIO);
									}
									}
									setState(205); 
									_errHandler.sync(this);
									_la = _input.LA(1);
								} while ( _la==ESPACIO );
								}
								break;
							case 2:
								{
								setState(210);
								_errHandler.sync(this);
								_la = _input.LA(1);
								while (_la==ESPACIO) {
									{
									{
									setState(207);
									match(ESPACIO);
									}
									}
									setState(212);
									_errHandler.sync(this);
									_la = _input.LA(1);
								}
								setState(213);
								_la = _input.LA(1);
								if ( !(_la==COMA || _la==MAS) ) {
								_errHandler.recoverInline(this);
								}
								else {
									if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
									_errHandler.reportMatch(this);
									consume();
								}
								setState(217);
								_errHandler.sync(this);
								_la = _input.LA(1);
								while (_la==ESPACIO) {
									{
									{
									setState(214);
									match(ESPACIO);
									}
									}
									setState(219);
									_errHandler.sync(this);
									_la = _input.LA(1);
								}
								}
								break;
							}
							setState(222);
							match(TOPRINT);
							}
							} 
						}
						setState(227);
						_errHandler.sync(this);
						_alt = getInterpreter().adaptivePredict(_input,28,_ctx);
					}
					}
					}
					break;
				case VAR:
					{
					setState(228);
					match(VAR);
					setState(252);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,33,_ctx);
					while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
						if ( _alt==1 ) {
							{
							{
							setState(247);
							_errHandler.sync(this);
							switch ( getInterpreter().adaptivePredict(_input,32,_ctx) ) {
							case 1:
								{
								setState(230); 
								_errHandler.sync(this);
								_la = _input.LA(1);
								do {
									{
									{
									setState(229);
									match(ESPACIO);
									}
									}
									setState(232); 
									_errHandler.sync(this);
									_la = _input.LA(1);
								} while ( _la==ESPACIO );
								}
								break;
							case 2:
								{
								setState(237);
								_errHandler.sync(this);
								_la = _input.LA(1);
								while (_la==ESPACIO) {
									{
									{
									setState(234);
									match(ESPACIO);
									}
									}
									setState(239);
									_errHandler.sync(this);
									_la = _input.LA(1);
								}
								setState(240);
								match(COMA);
								setState(244);
								_errHandler.sync(this);
								_la = _input.LA(1);
								while (_la==ESPACIO) {
									{
									{
									setState(241);
									match(ESPACIO);
									}
									}
									setState(246);
									_errHandler.sync(this);
									_la = _input.LA(1);
								}
								}
								break;
							}
							setState(249);
							match(VAR);
							}
							} 
						}
						setState(254);
						_errHandler.sync(this);
						_alt = getInterpreter().adaptivePredict(_input,33,_ctx);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(264);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ESPACIO || _la==PUNTO_Y_COMA) {
					{
					setState(260);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==ESPACIO) {
						{
						{
						setState(257);
						match(ESPACIO);
						}
						}
						setState(262);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					setState(263);
					match(PUNTO_Y_COMA);
					}
				}

				setState(267); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(266);
						match(INTRO);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(269); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,37,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(272);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,38,_ctx) ) {
				case 1:
					{
					setState(271);
					comentario();
					}
					break;
				}
				setState(277);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,39,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(274);
						match(INTRO);
						}
						} 
					}
					setState(279);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,39,_ctx);
				}
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(280);
				match(CABECERA_ESCRIBIR);
				setState(282); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(281);
						match(ESPACIO);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(284); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,40,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(422); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(352);
						_errHandler.sync(this);
						_la = _input.LA(1);
						if (_la==VAR) {
							{
							setState(286);
							match(VAR);
							setState(341);
							_errHandler.sync(this);
							_la = _input.LA(1);
							if (_la==APERTURA_PARENTESIS) {
								{
								setState(287);
								match(APERTURA_PARENTESIS);
								setState(291);
								_errHandler.sync(this);
								_alt = getInterpreter().adaptivePredict(_input,41,_ctx);
								while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
									if ( _alt==1 ) {
										{
										{
										setState(288);
										match(ESPACIO);
										}
										} 
									}
									setState(293);
									_errHandler.sync(this);
									_alt = getInterpreter().adaptivePredict(_input,41,_ctx);
								}
								setState(332);
								_errHandler.sync(this);
								_la = _input.LA(1);
								if (_la==NUMEROS || _la==VAR) {
									{
									setState(294);
									_la = _input.LA(1);
									if ( !(_la==NUMEROS || _la==VAR) ) {
									_errHandler.recoverInline(this);
									}
									else {
										if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
										_errHandler.reportMatch(this);
										consume();
									}
									setState(302);
									_errHandler.sync(this);
									switch ( getInterpreter().adaptivePredict(_input,43,_ctx) ) {
									case 1:
										{
										setState(298);
										_errHandler.sync(this);
										_la = _input.LA(1);
										while (_la==ESPACIO) {
											{
											{
											setState(295);
											match(ESPACIO);
											}
											}
											setState(300);
											_errHandler.sync(this);
											_la = _input.LA(1);
										}
										setState(301);
										_la = _input.LA(1);
										if ( !(_la==POR_VALOR || _la==POR_REFERENCIA) ) {
										_errHandler.recoverInline(this);
										}
										else {
											if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
											_errHandler.reportMatch(this);
											consume();
										}
										}
										break;
									}
									setState(329);
									_errHandler.sync(this);
									_alt = getInterpreter().adaptivePredict(_input,48,_ctx);
									while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
										if ( _alt==1 ) {
											{
											{
											setState(307);
											_errHandler.sync(this);
											_la = _input.LA(1);
											while (_la==ESPACIO) {
												{
												{
												setState(304);
												match(ESPACIO);
												}
												}
												setState(309);
												_errHandler.sync(this);
												_la = _input.LA(1);
											}
											setState(310);
											match(COMA);
											setState(314);
											_errHandler.sync(this);
											_la = _input.LA(1);
											while (_la==ESPACIO) {
												{
												{
												setState(311);
												match(ESPACIO);
												}
												}
												setState(316);
												_errHandler.sync(this);
												_la = _input.LA(1);
											}
											setState(317);
											_la = _input.LA(1);
											if ( !(_la==NUMEROS || _la==VAR) ) {
											_errHandler.recoverInline(this);
											}
											else {
												if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
												_errHandler.reportMatch(this);
												consume();
											}
											setState(325);
											_errHandler.sync(this);
											switch ( getInterpreter().adaptivePredict(_input,47,_ctx) ) {
											case 1:
												{
												setState(321);
												_errHandler.sync(this);
												_la = _input.LA(1);
												while (_la==ESPACIO) {
													{
													{
													setState(318);
													match(ESPACIO);
													}
													}
													setState(323);
													_errHandler.sync(this);
													_la = _input.LA(1);
												}
												setState(324);
												_la = _input.LA(1);
												if ( !(_la==POR_VALOR || _la==POR_REFERENCIA) ) {
												_errHandler.recoverInline(this);
												}
												else {
													if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
													_errHandler.reportMatch(this);
													consume();
												}
												}
												break;
											}
											}
											} 
										}
										setState(331);
										_errHandler.sync(this);
										_alt = getInterpreter().adaptivePredict(_input,48,_ctx);
									}
									}
								}

								setState(337);
								_errHandler.sync(this);
								_la = _input.LA(1);
								while (_la==ESPACIO) {
									{
									{
									setState(334);
									match(ESPACIO);
									}
									}
									setState(339);
									_errHandler.sync(this);
									_la = _input.LA(1);
								}
								setState(340);
								match(CIERRE_PARENTESIS);
								}
							}

							setState(350);
							_errHandler.sync(this);
							switch (_input.LA(1)) {
							case MAS:
								{
								setState(343);
								match(MAS);
								}
								break;
							case COMA:
								{
								setState(344);
								match(COMA);
								}
								break;
							case ESPACIO:
								{
								setState(346); 
								_errHandler.sync(this);
								_alt = 1;
								do {
									switch (_alt) {
									case 1:
										{
										{
										setState(345);
										match(ESPACIO);
										}
										}
										break;
									default:
										throw new NoViableAltException(this);
									}
									setState(348); 
									_errHandler.sync(this);
									_alt = getInterpreter().adaptivePredict(_input,52,_ctx);
								} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
								}
								break;
							default:
								throw new NoViableAltException(this);
							}
							}
						}

						setState(378);
						_errHandler.sync(this);
						_la = _input.LA(1);
						if (_la==TOPRINT) {
							{
							setState(354);
							match(TOPRINT);
							setState(375);
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,59,_ctx);
							while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
								if ( _alt==1 ) {
									{
									setState(373);
									_errHandler.sync(this);
									switch ( getInterpreter().adaptivePredict(_input,58,_ctx) ) {
									case 1:
										{
										setState(356); 
										_errHandler.sync(this);
										_alt = 1;
										do {
											switch (_alt) {
											case 1:
												{
												{
												setState(355);
												match(ESPACIO);
												}
												}
												break;
											default:
												throw new NoViableAltException(this);
											}
											setState(358); 
											_errHandler.sync(this);
											_alt = getInterpreter().adaptivePredict(_input,55,_ctx);
										} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
										}
										break;
									case 2:
										{
										setState(363);
										_errHandler.sync(this);
										_la = _input.LA(1);
										while (_la==ESPACIO) {
											{
											{
											setState(360);
											match(ESPACIO);
											}
											}
											setState(365);
											_errHandler.sync(this);
											_la = _input.LA(1);
										}
										setState(366);
										_la = _input.LA(1);
										if ( !(_la==COMA || _la==MAS) ) {
										_errHandler.recoverInline(this);
										}
										else {
											if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
											_errHandler.reportMatch(this);
											consume();
										}
										setState(370);
										_errHandler.sync(this);
										_alt = getInterpreter().adaptivePredict(_input,57,_ctx);
										while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
											if ( _alt==1 ) {
												{
												{
												setState(367);
												match(ESPACIO);
												}
												} 
											}
											setState(372);
											_errHandler.sync(this);
											_alt = getInterpreter().adaptivePredict(_input,57,_ctx);
										}
										}
										break;
									}
									} 
								}
								setState(377);
								_errHandler.sync(this);
								_alt = getInterpreter().adaptivePredict(_input,59,_ctx);
							}
							}
						}

						setState(383);
						_errHandler.sync(this);
						_alt = getInterpreter().adaptivePredict(_input,61,_ctx);
						while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
							if ( _alt==1 ) {
								{
								{
								setState(380);
								match(ESPACIO);
								}
								} 
							}
							setState(385);
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,61,_ctx);
						}
						setState(386);
						_la = _input.LA(1);
						if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << ESPACIO) | (1L << COMA) | (1L << MAS))) != 0)) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(390);
						_errHandler.sync(this);
						_alt = getInterpreter().adaptivePredict(_input,62,_ctx);
						while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
							if ( _alt==1 ) {
								{
								{
								setState(387);
								match(ESPACIO);
								}
								} 
							}
							setState(392);
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,62,_ctx);
						}
						setState(420);
						_errHandler.sync(this);
						switch ( getInterpreter().adaptivePredict(_input,68,_ctx) ) {
						case 1:
							{
							setState(393);
							match(VAR);
							setState(417);
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,67,_ctx);
							while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
								if ( _alt==1 ) {
									{
									{
									setState(412);
									_errHandler.sync(this);
									switch ( getInterpreter().adaptivePredict(_input,66,_ctx) ) {
									case 1:
										{
										setState(395); 
										_errHandler.sync(this);
										_la = _input.LA(1);
										do {
											{
											{
											setState(394);
											match(ESPACIO);
											}
											}
											setState(397); 
											_errHandler.sync(this);
											_la = _input.LA(1);
										} while ( _la==ESPACIO );
										}
										break;
									case 2:
										{
										setState(402);
										_errHandler.sync(this);
										_la = _input.LA(1);
										while (_la==ESPACIO) {
											{
											{
											setState(399);
											match(ESPACIO);
											}
											}
											setState(404);
											_errHandler.sync(this);
											_la = _input.LA(1);
										}
										setState(405);
										match(COMA);
										setState(409);
										_errHandler.sync(this);
										_la = _input.LA(1);
										while (_la==ESPACIO) {
											{
											{
											setState(406);
											match(ESPACIO);
											}
											}
											setState(411);
											_errHandler.sync(this);
											_la = _input.LA(1);
										}
										}
										break;
									}
									setState(414);
									match(VAR);
									}
									} 
								}
								setState(419);
								_errHandler.sync(this);
								_alt = getInterpreter().adaptivePredict(_input,67,_ctx);
							}
							}
							break;
						}
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(424); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,69,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(426);
				match(CABECERA_ESCRIBIR);
				setState(474); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					setState(474);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,80,_ctx) ) {
					case 1:
						{
						{
						setState(445);
						_errHandler.sync(this);
						switch ( getInterpreter().adaptivePredict(_input,73,_ctx) ) {
						case 1:
							{
							setState(428); 
							_errHandler.sync(this);
							_la = _input.LA(1);
							do {
								{
								{
								setState(427);
								match(ESPACIO);
								}
								}
								setState(430); 
								_errHandler.sync(this);
								_la = _input.LA(1);
							} while ( _la==ESPACIO );
							}
							break;
						case 2:
							{
							setState(435);
							_errHandler.sync(this);
							_la = _input.LA(1);
							while (_la==ESPACIO) {
								{
								{
								setState(432);
								match(ESPACIO);
								}
								}
								setState(437);
								_errHandler.sync(this);
								_la = _input.LA(1);
							}
							setState(438);
							match(COMA);
							setState(442);
							_errHandler.sync(this);
							_la = _input.LA(1);
							while (_la==ESPACIO) {
								{
								{
								setState(439);
								match(ESPACIO);
								}
								}
								setState(444);
								_errHandler.sync(this);
								_la = _input.LA(1);
							}
							}
							break;
						}
						setState(449);
						_errHandler.sync(this);
						switch (_input.LA(1)) {
						case CABECERA_ABS:
						case CABECERA_TRUNC:
						case CABECERA_REDON:
						case CABECERA_RC:
						case CABECERA_SEN:
						case CABECERA_COS:
						case CABECERA_TAN:
						case CABECERA_ASEN:
						case CABECERA_ACOS:
						case CABECERA_ATAN:
						case CABECERA_LN:
						case CABECERA_EXP:
						case CABECERA_AZAR:
							{
							setState(447);
							func_matematicas();
							}
							break;
						case CABECERA_LONGITUD:
						case CABECERA_SUB_CADENA:
						case CABECERA_CONCATENAR:
						case CABECERA_CONVERTIR_A_NUMERO:
						case CABECERA_CONVERTIR_A_TEXTO:
						case CABECERA_MAYUSCULAS:
						case CABECERA_MINUSCULAS:
							{
							setState(448);
							func_cadenas();
							}
							break;
						default:
							throw new NoViableAltException(this);
						}
						}
						}
						break;
					case 2:
						{
						{
						setState(469);
						_errHandler.sync(this);
						switch ( getInterpreter().adaptivePredict(_input,78,_ctx) ) {
						case 1:
							{
							setState(452); 
							_errHandler.sync(this);
							_alt = 1;
							do {
								switch (_alt) {
								case 1:
									{
									{
									setState(451);
									match(ESPACIO);
									}
									}
									break;
								default:
									throw new NoViableAltException(this);
								}
								setState(454); 
								_errHandler.sync(this);
								_alt = getInterpreter().adaptivePredict(_input,75,_ctx);
							} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
							}
							break;
						case 2:
							{
							setState(459);
							_errHandler.sync(this);
							_la = _input.LA(1);
							while (_la==ESPACIO) {
								{
								{
								setState(456);
								match(ESPACIO);
								}
								}
								setState(461);
								_errHandler.sync(this);
								_la = _input.LA(1);
							}
							setState(462);
							match(COMA);
							setState(466);
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,77,_ctx);
							while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
								if ( _alt==1 ) {
									{
									{
									setState(463);
									match(ESPACIO);
									}
									} 
								}
								setState(468);
								_errHandler.sync(this);
								_alt = getInterpreter().adaptivePredict(_input,77,_ctx);
							}
							}
							break;
						}
						setState(472);
						_errHandler.sync(this);
						switch ( getInterpreter().adaptivePredict(_input,79,_ctx) ) {
						case 1:
							{
							setState(471);
							_la = _input.LA(1);
							if ( !(((((_la - 82)) & ~0x3f) == 0 && ((1L << (_la - 82)) & ((1L << (NUMEROS - 82)) | (1L << (VAR - 82)) | (1L << (TOPRINT - 82)))) != 0)) ) {
							_errHandler.recoverInline(this);
							}
							else {
								if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
								_errHandler.reportMatch(this);
								consume();
							}
							}
							break;
						}
						}
						}
						break;
					}
					}
					setState(476); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==ESPACIO || _la==COMA );
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SiContext extends ParserRuleContext {
		public TerminalNode CABECERA_SI() { return getToken(ElParser.CABECERA_SI, 0); }
		public SignosContext signos() {
			return getRuleContext(SignosContext.class,0);
		}
		public TerminalNode ENTONCES() { return getToken(ElParser.ENTONCES, 0); }
		public TerminalNode FINSI() { return getToken(ElParser.FINSI, 0); }
		public List<TerminalNode> VAR() { return getTokens(ElParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ElParser.VAR, i);
		}
		public List<TerminalNode> TOPRINT() { return getTokens(ElParser.TOPRINT); }
		public TerminalNode TOPRINT(int i) {
			return getToken(ElParser.TOPRINT, i);
		}
		public List<TerminalNode> NUMEROS() { return getTokens(ElParser.NUMEROS); }
		public TerminalNode NUMEROS(int i) {
			return getToken(ElParser.NUMEROS, i);
		}
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public List<ComentarioContext> comentario() {
			return getRuleContexts(ComentarioContext.class);
		}
		public ComentarioContext comentario(int i) {
			return getRuleContext(ComentarioContext.class,i);
		}
		public List<FuncionesContext> funciones() {
			return getRuleContexts(FuncionesContext.class);
		}
		public FuncionesContext funciones(int i) {
			return getRuleContext(FuncionesContext.class,i);
		}
		public TerminalNode SINO() { return getToken(ElParser.SINO, 0); }
		public SiContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_si; }
	}

	public final SiContext si() throws RecognitionException {
		SiContext _localctx = new SiContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_si);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(480);
			match(CABECERA_SI);
			setState(482); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(481);
				match(ESPACIO);
				}
				}
				setState(484); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(486);
			_la = _input.LA(1);
			if ( !(((((_la - 82)) & ~0x3f) == 0 && ((1L << (_la - 82)) & ((1L << (NUMEROS - 82)) | (1L << (VAR - 82)) | (1L << (TOPRINT - 82)))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(490);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(487);
				match(ESPACIO);
				}
				}
				setState(492);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(493);
			signos();
			setState(497);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(494);
				match(ESPACIO);
				}
				}
				setState(499);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(500);
			_la = _input.LA(1);
			if ( !(((((_la - 82)) & ~0x3f) == 0 && ((1L << (_la - 82)) & ((1L << (NUMEROS - 82)) | (1L << (VAR - 82)) | (1L << (TOPRINT - 82)))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(502); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(501);
				match(ESPACIO);
				}
				}
				setState(504); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(506);
			match(ENTONCES);
			setState(508); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(507);
					match(INTRO);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(510); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,87,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(513);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==COMENT_ABRIR || _la==COMENT_LINEA) {
				{
				setState(512);
				comentario();
				}
			}

			setState(518);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==INTRO) {
				{
				{
				setState(515);
				match(INTRO);
				}
				}
				setState(520);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(522); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(521);
				funciones();
				}
				}
				setState(524); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((((_la - 28)) & ~0x3f) == 0 && ((1L << (_la - 28)) & ((1L << (CABECERA_DEFINIR - 28)) | (1L << (CABECERA_ESCRIBIR - 28)) | (1L << (CABECERA_LEER - 28)) | (1L << (CABECERA_SI - 28)) | (1L << (CABECERA_PARA - 28)) | (1L << (CABECERA_MIENTRAS - 28)) | (1L << (CABECERA_REPETIR - 28)) | (1L << (CABECERA_SEGUN - 28)) | (1L << (CABECERA_DIMENSION - 28)) | (1L << (VAR - 28)))) != 0) );
			setState(529);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==INTRO) {
				{
				{
				setState(526);
				match(INTRO);
				}
				}
				setState(531);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(558);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==SINO) {
				{
				setState(532);
				match(SINO);
				setState(534); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(533);
						match(INTRO);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(536); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,92,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(539);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMENT_ABRIR || _la==COMENT_LINEA) {
					{
					setState(538);
					comentario();
					}
				}

				setState(544);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==INTRO) {
					{
					{
					setState(541);
					match(INTRO);
					}
					}
					setState(546);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(548); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(547);
					funciones();
					}
					}
					setState(550); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( ((((_la - 28)) & ~0x3f) == 0 && ((1L << (_la - 28)) & ((1L << (CABECERA_DEFINIR - 28)) | (1L << (CABECERA_ESCRIBIR - 28)) | (1L << (CABECERA_LEER - 28)) | (1L << (CABECERA_SI - 28)) | (1L << (CABECERA_PARA - 28)) | (1L << (CABECERA_MIENTRAS - 28)) | (1L << (CABECERA_REPETIR - 28)) | (1L << (CABECERA_SEGUN - 28)) | (1L << (CABECERA_DIMENSION - 28)) | (1L << (VAR - 28)))) != 0) );
				setState(555);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==INTRO) {
					{
					{
					setState(552);
					match(INTRO);
					}
					}
					setState(557);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
			}

			setState(560);
			match(FINSI);
			setState(575);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,101,_ctx) ) {
			case 1:
				{
				setState(562); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(561);
						match(INTRO);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(564); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,98,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(567);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,99,_ctx) ) {
				case 1:
					{
					setState(566);
					comentario();
					}
					break;
				}
				setState(572);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,100,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(569);
						match(INTRO);
						}
						} 
					}
					setState(574);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,100,_ctx);
				}
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SignosContext extends ParserRuleContext {
		public TerminalNode SIGNO_MENOR_QUE() { return getToken(ElParser.SIGNO_MENOR_QUE, 0); }
		public TerminalNode SIGNO_MAYOR_QUE() { return getToken(ElParser.SIGNO_MAYOR_QUE, 0); }
		public TerminalNode SIGNO_IGUAL() { return getToken(ElParser.SIGNO_IGUAL, 0); }
		public TerminalNode SIGNO_MENOROIGUAL() { return getToken(ElParser.SIGNO_MENOROIGUAL, 0); }
		public TerminalNode SIGNO_MAYOROIGUAL() { return getToken(ElParser.SIGNO_MAYOROIGUAL, 0); }
		public TerminalNode SIGNO_DISTINTO() { return getToken(ElParser.SIGNO_DISTINTO, 0); }
		public SignosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_signos; }
	}

	public final SignosContext signos() throws RecognitionException {
		SignosContext _localctx = new SignosContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_signos);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(577);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << SIGNO_MENOR_QUE) | (1L << SIGNO_MAYOR_QUE) | (1L << SIGNO_IGUAL) | (1L << SIGNO_MENOROIGUAL) | (1L << SIGNO_MAYOROIGUAL) | (1L << SIGNO_DISTINTO))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParaContext extends ParserRuleContext {
		public TerminalNode CABECERA_PARA() { return getToken(ElParser.CABECERA_PARA, 0); }
		public AsignacionContext asignacion() {
			return getRuleContext(AsignacionContext.class,0);
		}
		public TerminalNode HASTA() { return getToken(ElParser.HASTA, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode FINPARA() { return getToken(ElParser.FINPARA, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public List<ComentarioContext> comentario() {
			return getRuleContexts(ComentarioContext.class);
		}
		public ComentarioContext comentario(int i) {
			return getRuleContext(ComentarioContext.class,i);
		}
		public List<FuncionesContext> funciones() {
			return getRuleContexts(FuncionesContext.class);
		}
		public FuncionesContext funciones(int i) {
			return getRuleContext(FuncionesContext.class,i);
		}
		public TerminalNode HACER() { return getToken(ElParser.HACER, 0); }
		public TerminalNode CON() { return getToken(ElParser.CON, 0); }
		public TerminalNode PASO_A() { return getToken(ElParser.PASO_A, 0); }
		public TerminalNode PASO_B() { return getToken(ElParser.PASO_B, 0); }
		public ParaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_para; }
	}

	public final ParaContext para() throws RecognitionException {
		ParaContext _localctx = new ParaContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_para);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(579);
			match(CABECERA_PARA);
			setState(581); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(580);
				match(ESPACIO);
				}
				}
				setState(583); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(585);
			asignacion();
			setState(589);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(586);
				match(ESPACIO);
				}
				}
				setState(591);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(592);
			match(HASTA);
			setState(594); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(593);
				match(ESPACIO);
				}
				}
				setState(596); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(598);
			match(NUMEROS);
			setState(600); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(599);
				match(ESPACIO);
				}
				}
				setState(602); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(624);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case HACER:
				{
				{
				setState(604);
				match(HACER);
				}
				}
				break;
			case CON:
				{
				{
				setState(605);
				match(CON);
				setState(607); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(606);
					match(ESPACIO);
					}
					}
					setState(609); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==ESPACIO );
				setState(611);
				match(PASO_A);
				setState(613); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(612);
					match(ESPACIO);
					}
					}
					setState(615); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==ESPACIO );
				setState(617);
				match(PASO_B);
				setState(619); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(618);
					match(ESPACIO);
					}
					}
					setState(621); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==ESPACIO );
				setState(623);
				match(HACER);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(627); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(626);
					match(INTRO);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(629); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,110,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(632);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==COMENT_ABRIR || _la==COMENT_LINEA) {
				{
				setState(631);
				comentario();
				}
			}

			setState(637);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==INTRO) {
				{
				{
				setState(634);
				match(INTRO);
				}
				}
				setState(639);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(641); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(640);
				funciones();
				}
				}
				setState(643); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((((_la - 28)) & ~0x3f) == 0 && ((1L << (_la - 28)) & ((1L << (CABECERA_DEFINIR - 28)) | (1L << (CABECERA_ESCRIBIR - 28)) | (1L << (CABECERA_LEER - 28)) | (1L << (CABECERA_SI - 28)) | (1L << (CABECERA_PARA - 28)) | (1L << (CABECERA_MIENTRAS - 28)) | (1L << (CABECERA_REPETIR - 28)) | (1L << (CABECERA_SEGUN - 28)) | (1L << (CABECERA_DIMENSION - 28)) | (1L << (VAR - 28)))) != 0) );
			setState(648);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==INTRO) {
				{
				{
				setState(645);
				match(INTRO);
				}
				}
				setState(650);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(651);
			match(FINPARA);
			setState(666);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,118,_ctx) ) {
			case 1:
				{
				setState(653); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(652);
						match(INTRO);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(655); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,115,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(658);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,116,_ctx) ) {
				case 1:
					{
					setState(657);
					comentario();
					}
					break;
				}
				setState(663);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,117,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(660);
						match(INTRO);
						}
						} 
					}
					setState(665);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,117,_ctx);
				}
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AsignacionContext extends ParserRuleContext {
		public List<TerminalNode> VAR() { return getTokens(ElParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ElParser.VAR, i);
		}
		public TerminalNode FLECHA_ASIGNACION() { return getToken(ElParser.FLECHA_ASIGNACION, 0); }
		public TerminalNode SIGNO_IGUAL() { return getToken(ElParser.SIGNO_IGUAL, 0); }
		public List<TerminalNode> NUMEROS() { return getTokens(ElParser.NUMEROS); }
		public TerminalNode NUMEROS(int i) {
			return getToken(ElParser.NUMEROS, i);
		}
		public List<TerminalNode> TOPRINT() { return getTokens(ElParser.TOPRINT); }
		public TerminalNode TOPRINT(int i) {
			return getToken(ElParser.TOPRINT, i);
		}
		public Asignacion_funcionesContext asignacion_funciones() {
			return getRuleContext(Asignacion_funcionesContext.class,0);
		}
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public List<TerminalNode> MAS() { return getTokens(ElParser.MAS); }
		public TerminalNode MAS(int i) {
			return getToken(ElParser.MAS, i);
		}
		public List<TerminalNode> MENOS() { return getTokens(ElParser.MENOS); }
		public TerminalNode MENOS(int i) {
			return getToken(ElParser.MENOS, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public ComentarioContext comentario() {
			return getRuleContext(ComentarioContext.class,0);
		}
		public AsignacionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_asignacion; }
	}

	public final AsignacionContext asignacion() throws RecognitionException {
		AsignacionContext _localctx = new AsignacionContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_asignacion);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(668);
			match(VAR);
			setState(672);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(669);
				match(ESPACIO);
				}
				}
				setState(674);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(675);
			_la = _input.LA(1);
			if ( !(_la==FLECHA_ASIGNACION || _la==SIGNO_IGUAL) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(679);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,120,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(676);
					match(ESPACIO);
					}
					} 
				}
				setState(681);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,120,_ctx);
			}
			setState(683);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==APERTURA_PARENTESIS) {
				{
				setState(682);
				match(APERTURA_PARENTESIS);
				}
			}

			setState(688);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,122,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(685);
					match(ESPACIO);
					}
					} 
				}
				setState(690);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,122,_ctx);
			}
			setState(771);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,135,_ctx) ) {
			case 1:
				{
				setState(691);
				match(VAR);
				}
				break;
			case 2:
				{
				setState(692);
				match(VAR);
				setState(696);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==ESPACIO) {
					{
					{
					setState(693);
					match(ESPACIO);
					}
					}
					setState(698);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(707); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(699);
					_la = _input.LA(1);
					if ( !(_la==MAS || _la==MENOS) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					setState(703);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==ESPACIO) {
						{
						{
						setState(700);
						match(ESPACIO);
						}
						}
						setState(705);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					setState(706);
					match(NUMEROS);
					}
					}
					setState(709); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==MAS || _la==MENOS );
				}
				break;
			case 3:
				{
				setState(711);
				match(VAR);
				setState(715);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==ESPACIO) {
					{
					{
					setState(712);
					match(ESPACIO);
					}
					}
					setState(717);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(726); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(718);
					match(MAS);
					setState(722);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==ESPACIO) {
						{
						{
						setState(719);
						match(ESPACIO);
						}
						}
						setState(724);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					setState(725);
					_la = _input.LA(1);
					if ( !(_la==VAR || _la==TOPRINT) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
					}
					setState(728); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==MAS );
				}
				break;
			case 4:
				{
				setState(730);
				match(NUMEROS);
				setState(734);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,129,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(731);
						match(ESPACIO);
						}
						} 
					}
					setState(736);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,129,_ctx);
				}
				setState(747);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==MAS || _la==MENOS) {
					{
					{
					setState(737);
					_la = _input.LA(1);
					if ( !(_la==MAS || _la==MENOS) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					setState(741);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==ESPACIO) {
						{
						{
						setState(738);
						match(ESPACIO);
						}
						}
						setState(743);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					setState(744);
					match(NUMEROS);
					}
					}
					setState(749);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case 5:
				{
				setState(750);
				match(TOPRINT);
				setState(754);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,132,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(751);
						match(ESPACIO);
						}
						} 
					}
					setState(756);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,132,_ctx);
				}
				setState(767);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==MAS) {
					{
					{
					setState(757);
					match(MAS);
					setState(761);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==ESPACIO) {
						{
						{
						setState(758);
						match(ESPACIO);
						}
						}
						setState(763);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					setState(764);
					match(TOPRINT);
					}
					}
					setState(769);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case 6:
				{
				setState(770);
				asignacion_funciones();
				}
				break;
			}
			setState(776);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,136,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(773);
					match(ESPACIO);
					}
					} 
				}
				setState(778);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,136,_ctx);
			}
			setState(780);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==CIERRE_PARENTESIS) {
				{
				setState(779);
				match(CIERRE_PARENTESIS);
				}
			}

			setState(796);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,141,_ctx) ) {
			case 1:
				{
				setState(783); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(782);
						match(INTRO);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(785); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,138,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(788);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,139,_ctx) ) {
				case 1:
					{
					setState(787);
					comentario();
					}
					break;
				}
				setState(793);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,140,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(790);
						match(INTRO);
						}
						} 
					}
					setState(795);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,140,_ctx);
				}
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Asignacion_funcionesContext extends ParserRuleContext {
		public List<TerminalNode> VAR() { return getTokens(ElParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ElParser.VAR, i);
		}
		public List<TerminalNode> NUMEROS() { return getTokens(ElParser.NUMEROS); }
		public TerminalNode NUMEROS(int i) {
			return getToken(ElParser.NUMEROS, i);
		}
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> MAS() { return getTokens(ElParser.MAS); }
		public TerminalNode MAS(int i) {
			return getToken(ElParser.MAS, i);
		}
		public List<Func_cadenasContext> func_cadenas() {
			return getRuleContexts(Func_cadenasContext.class);
		}
		public Func_cadenasContext func_cadenas(int i) {
			return getRuleContext(Func_cadenasContext.class,i);
		}
		public List<Func_matematicasContext> func_matematicas() {
			return getRuleContexts(Func_matematicasContext.class);
		}
		public Func_matematicasContext func_matematicas(int i) {
			return getRuleContext(Func_matematicasContext.class,i);
		}
		public Asignacion_funcionesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_asignacion_funciones; }
	}

	public final Asignacion_funcionesContext asignacion_funciones() throws RecognitionException {
		Asignacion_funcionesContext _localctx = new Asignacion_funcionesContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_asignacion_funciones);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(844); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					setState(844);
					_errHandler.sync(this);
					switch (_input.LA(1)) {
					case CABECERA_ABS:
					case CABECERA_TRUNC:
					case CABECERA_REDON:
					case CABECERA_RC:
					case CABECERA_SEN:
					case CABECERA_COS:
					case CABECERA_TAN:
					case CABECERA_ASEN:
					case CABECERA_ACOS:
					case CABECERA_ATAN:
					case CABECERA_LN:
					case CABECERA_EXP:
					case CABECERA_AZAR:
					case CABECERA_LONGITUD:
					case CABECERA_SUB_CADENA:
					case CABECERA_CONCATENAR:
					case CABECERA_CONVERTIR_A_NUMERO:
					case CABECERA_CONVERTIR_A_TEXTO:
					case CABECERA_MAYUSCULAS:
					case CABECERA_MINUSCULAS:
						{
						{
						setState(800);
						_errHandler.sync(this);
						switch (_input.LA(1)) {
						case CABECERA_LONGITUD:
						case CABECERA_SUB_CADENA:
						case CABECERA_CONCATENAR:
						case CABECERA_CONVERTIR_A_NUMERO:
						case CABECERA_CONVERTIR_A_TEXTO:
						case CABECERA_MAYUSCULAS:
						case CABECERA_MINUSCULAS:
							{
							setState(798);
							func_cadenas();
							}
							break;
						case CABECERA_ABS:
						case CABECERA_TRUNC:
						case CABECERA_REDON:
						case CABECERA_RC:
						case CABECERA_SEN:
						case CABECERA_COS:
						case CABECERA_TAN:
						case CABECERA_ASEN:
						case CABECERA_ACOS:
						case CABECERA_ATAN:
						case CABECERA_LN:
						case CABECERA_EXP:
						case CABECERA_AZAR:
							{
							setState(799);
							func_matematicas();
							}
							break;
						default:
							throw new NoViableAltException(this);
						}
						setState(815);
						_errHandler.sync(this);
						switch ( getInterpreter().adaptivePredict(_input,145,_ctx) ) {
						case 1:
							{
							setState(805);
							_errHandler.sync(this);
							_la = _input.LA(1);
							while (_la==ESPACIO) {
								{
								{
								setState(802);
								match(ESPACIO);
								}
								}
								setState(807);
								_errHandler.sync(this);
								_la = _input.LA(1);
							}
							setState(808);
							match(MAS);
							setState(812);
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,144,_ctx);
							while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
								if ( _alt==1 ) {
									{
									{
									setState(809);
									match(ESPACIO);
									}
									} 
								}
								setState(814);
								_errHandler.sync(this);
								_alt = getInterpreter().adaptivePredict(_input,144,_ctx);
							}
							}
							break;
						}
						}
						}
						break;
					case ESPACIO:
					case NUMEROS:
					case VAR:
						{
						setState(820);
						_errHandler.sync(this);
						_la = _input.LA(1);
						while (_la==ESPACIO) {
							{
							{
							setState(817);
							match(ESPACIO);
							}
							}
							setState(822);
							_errHandler.sync(this);
							_la = _input.LA(1);
						}
						setState(823);
						_la = _input.LA(1);
						if ( !(_la==NUMEROS || _la==VAR) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(842);
						_errHandler.sync(this);
						switch ( getInterpreter().adaptivePredict(_input,150,_ctx) ) {
						case 1:
							{
							setState(825); 
							_errHandler.sync(this);
							_alt = 1;
							do {
								switch (_alt) {
								case 1:
									{
									{
									setState(824);
									match(ESPACIO);
									}
									}
									break;
								default:
									throw new NoViableAltException(this);
								}
								setState(827); 
								_errHandler.sync(this);
								_alt = getInterpreter().adaptivePredict(_input,147,_ctx);
							} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
							}
							break;
						case 2:
							{
							setState(832);
							_errHandler.sync(this);
							_la = _input.LA(1);
							while (_la==ESPACIO) {
								{
								{
								setState(829);
								match(ESPACIO);
								}
								}
								setState(834);
								_errHandler.sync(this);
								_la = _input.LA(1);
							}
							setState(835);
							match(MAS);
							setState(839);
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,149,_ctx);
							while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
								if ( _alt==1 ) {
									{
									{
									setState(836);
									match(ESPACIO);
									}
									} 
								}
								setState(841);
								_errHandler.sync(this);
								_alt = getInterpreter().adaptivePredict(_input,149,_ctx);
							}
							}
							break;
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(846); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,152,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MientrasContext extends ParserRuleContext {
		public TerminalNode CABECERA_MIENTRAS() { return getToken(ElParser.CABECERA_MIENTRAS, 0); }
		public ComparacionContext comparacion() {
			return getRuleContext(ComparacionContext.class,0);
		}
		public TerminalNode HACER() { return getToken(ElParser.HACER, 0); }
		public TerminalNode FINMIENTRAS() { return getToken(ElParser.FINMIENTRAS, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public List<ComentarioContext> comentario() {
			return getRuleContexts(ComentarioContext.class);
		}
		public ComentarioContext comentario(int i) {
			return getRuleContext(ComentarioContext.class,i);
		}
		public List<FuncionesContext> funciones() {
			return getRuleContexts(FuncionesContext.class);
		}
		public FuncionesContext funciones(int i) {
			return getRuleContext(FuncionesContext.class,i);
		}
		public List<Asignacion_restasumaContext> asignacion_restasuma() {
			return getRuleContexts(Asignacion_restasumaContext.class);
		}
		public Asignacion_restasumaContext asignacion_restasuma(int i) {
			return getRuleContext(Asignacion_restasumaContext.class,i);
		}
		public MientrasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mientras; }
	}

	public final MientrasContext mientras() throws RecognitionException {
		MientrasContext _localctx = new MientrasContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_mientras);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(848);
			match(CABECERA_MIENTRAS);
			setState(850); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(849);
				match(ESPACIO);
				}
				}
				setState(852); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(854);
			comparacion();
			setState(856); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(855);
				match(ESPACIO);
				}
				}
				setState(858); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(860);
			match(HACER);
			setState(862); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(861);
					match(INTRO);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(864); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,155,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(867);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==COMENT_ABRIR || _la==COMENT_LINEA) {
				{
				setState(866);
				comentario();
				}
			}

			setState(872);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==INTRO) {
				{
				{
				setState(869);
				match(INTRO);
				}
				}
				setState(874);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(884);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,159,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(875);
					funciones();
					setState(879);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==INTRO) {
						{
						{
						setState(876);
						match(INTRO);
						}
						}
						setState(881);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
					} 
				}
				setState(886);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,159,_ctx);
			}
			setState(895);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==VAR) {
				{
				{
				setState(887);
				asignacion_restasuma();
				setState(889); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(888);
					match(INTRO);
					}
					}
					setState(891); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==INTRO );
				}
				}
				setState(897);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(898);
			match(FINMIENTRAS);
			setState(913);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,165,_ctx) ) {
			case 1:
				{
				setState(900); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(899);
						match(INTRO);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(902); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,162,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(905);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,163,_ctx) ) {
				case 1:
					{
					setState(904);
					comentario();
					}
					break;
				}
				setState(910);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,164,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(907);
						match(INTRO);
						}
						} 
					}
					setState(912);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,164,_ctx);
				}
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ComparacionContext extends ParserRuleContext {
		public List<TerminalNode> VAR() { return getTokens(ElParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ElParser.VAR, i);
		}
		public SignosContext signos() {
			return getRuleContext(SignosContext.class,0);
		}
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public ComparacionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comparacion; }
	}

	public final ComparacionContext comparacion() throws RecognitionException {
		ComparacionContext _localctx = new ComparacionContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_comparacion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(915);
			match(VAR);
			setState(919);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(916);
				match(ESPACIO);
				}
				}
				setState(921);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(922);
			signos();
			setState(926);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(923);
				match(ESPACIO);
				}
				}
				setState(928);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(929);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Asignacion_restasumaContext extends ParserRuleContext {
		public List<TerminalNode> VAR() { return getTokens(ElParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ElParser.VAR, i);
		}
		public TerminalNode FLECHA_ASIGNACION() { return getToken(ElParser.FLECHA_ASIGNACION, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> NUMEROS() { return getTokens(ElParser.NUMEROS); }
		public TerminalNode NUMEROS(int i) {
			return getToken(ElParser.NUMEROS, i);
		}
		public List<TerminalNode> MAS() { return getTokens(ElParser.MAS); }
		public TerminalNode MAS(int i) {
			return getToken(ElParser.MAS, i);
		}
		public List<TerminalNode> MENOS() { return getTokens(ElParser.MENOS); }
		public TerminalNode MENOS(int i) {
			return getToken(ElParser.MENOS, i);
		}
		public Asignacion_restasumaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_asignacion_restasuma; }
	}

	public final Asignacion_restasumaContext asignacion_restasuma() throws RecognitionException {
		Asignacion_restasumaContext _localctx = new Asignacion_restasumaContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_asignacion_restasuma);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(931);
			match(VAR);
			setState(935);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(932);
				match(ESPACIO);
				}
				}
				setState(937);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(938);
			match(FLECHA_ASIGNACION);
			setState(942);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(939);
				match(ESPACIO);
				}
				}
				setState(944);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(945);
			match(VAR);
			setState(949);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(946);
				match(ESPACIO);
				}
				}
				setState(951);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(960); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(952);
				_la = _input.LA(1);
				if ( !(_la==MAS || _la==MENOS) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(956);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==ESPACIO) {
					{
					{
					setState(953);
					match(ESPACIO);
					}
					}
					setState(958);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(959);
				match(NUMEROS);
				}
				}
				setState(962); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==MAS || _la==MENOS );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RepetirContext extends ParserRuleContext {
		public TerminalNode CABECERA_REPETIR() { return getToken(ElParser.CABECERA_REPETIR, 0); }
		public TerminalNode HASTA() { return getToken(ElParser.HASTA, 0); }
		public TerminalNode QUE() { return getToken(ElParser.QUE, 0); }
		public ComparacionContext comparacion() {
			return getRuleContext(ComparacionContext.class,0);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public List<ComentarioContext> comentario() {
			return getRuleContexts(ComentarioContext.class);
		}
		public ComentarioContext comentario(int i) {
			return getRuleContext(ComentarioContext.class,i);
		}
		public List<FuncionesContext> funciones() {
			return getRuleContexts(FuncionesContext.class);
		}
		public FuncionesContext funciones(int i) {
			return getRuleContext(FuncionesContext.class,i);
		}
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public RepetirContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_repetir; }
	}

	public final RepetirContext repetir() throws RecognitionException {
		RepetirContext _localctx = new RepetirContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_repetir);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(964);
			match(CABECERA_REPETIR);
			setState(966); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(965);
					match(INTRO);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(968); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,173,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(971);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==COMENT_ABRIR || _la==COMENT_LINEA) {
				{
				setState(970);
				comentario();
				}
			}

			setState(976);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==INTRO) {
				{
				{
				setState(973);
				match(INTRO);
				}
				}
				setState(978);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(986); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(979);
				funciones();
				setState(983);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==INTRO) {
					{
					{
					setState(980);
					match(INTRO);
					}
					}
					setState(985);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				}
				setState(988); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( ((((_la - 28)) & ~0x3f) == 0 && ((1L << (_la - 28)) & ((1L << (CABECERA_DEFINIR - 28)) | (1L << (CABECERA_ESCRIBIR - 28)) | (1L << (CABECERA_LEER - 28)) | (1L << (CABECERA_SI - 28)) | (1L << (CABECERA_PARA - 28)) | (1L << (CABECERA_MIENTRAS - 28)) | (1L << (CABECERA_REPETIR - 28)) | (1L << (CABECERA_SEGUN - 28)) | (1L << (CABECERA_DIMENSION - 28)) | (1L << (VAR - 28)))) != 0) );
			setState(990);
			match(HASTA);
			setState(992); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(991);
				match(ESPACIO);
				}
				}
				setState(994); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(996);
			match(QUE);
			setState(998); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(997);
				match(ESPACIO);
				}
				}
				setState(1000); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(1002);
			comparacion();
			setState(1004); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(1003);
					match(INTRO);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(1006); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,180,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(1009);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,181,_ctx) ) {
			case 1:
				{
				setState(1008);
				comentario();
				}
				break;
			}
			setState(1014);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,182,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1011);
					match(INTRO);
					}
					} 
				}
				setState(1016);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,182,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SegunContext extends ParserRuleContext {
		public TerminalNode CABECERA_SEGUN() { return getToken(ElParser.CABECERA_SEGUN, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public TerminalNode HACER() { return getToken(ElParser.HACER, 0); }
		public TerminalNode DE() { return getToken(ElParser.DE, 0); }
		public TerminalNode OTRO() { return getToken(ElParser.OTRO, 0); }
		public TerminalNode MODO() { return getToken(ElParser.MODO, 0); }
		public List<TerminalNode> DOS_PUNTOS() { return getTokens(ElParser.DOS_PUNTOS); }
		public TerminalNode DOS_PUNTOS(int i) {
			return getToken(ElParser.DOS_PUNTOS, i);
		}
		public List<FuncionesContext> funciones() {
			return getRuleContexts(FuncionesContext.class);
		}
		public FuncionesContext funciones(int i) {
			return getRuleContext(FuncionesContext.class,i);
		}
		public TerminalNode FIN_SEGUN() { return getToken(ElParser.FIN_SEGUN, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public List<ComentarioContext> comentario() {
			return getRuleContexts(ComentarioContext.class);
		}
		public ComentarioContext comentario(int i) {
			return getRuleContext(ComentarioContext.class,i);
		}
		public List<TerminalNode> NUMEROS() { return getTokens(ElParser.NUMEROS); }
		public TerminalNode NUMEROS(int i) {
			return getToken(ElParser.NUMEROS, i);
		}
		public List<TerminalNode> TOPRINT() { return getTokens(ElParser.TOPRINT); }
		public TerminalNode TOPRINT(int i) {
			return getToken(ElParser.TOPRINT, i);
		}
		public SegunContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_segun; }
	}

	public final SegunContext segun() throws RecognitionException {
		SegunContext _localctx = new SegunContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_segun);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1017);
			match(CABECERA_SEGUN);
			setState(1019); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(1018);
				match(ESPACIO);
				}
				}
				setState(1021); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(1023);
			match(VAR);
			setState(1025); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(1024);
				match(ESPACIO);
				}
				}
				setState(1027); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(1029);
			match(HACER);
			setState(1031); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(1030);
					match(INTRO);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(1033); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,185,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(1036);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==COMENT_ABRIR || _la==COMENT_LINEA) {
				{
				setState(1035);
				comentario();
				}
			}

			setState(1041);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==INTRO) {
				{
				{
				setState(1038);
				match(INTRO);
				}
				}
				setState(1043);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1079);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==NUMEROS || _la==TOPRINT) {
				{
				{
				setState(1044);
				_la = _input.LA(1);
				if ( !(_la==NUMEROS || _la==TOPRINT) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1048);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==ESPACIO) {
					{
					{
					setState(1045);
					match(ESPACIO);
					}
					}
					setState(1050);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1051);
				match(DOS_PUNTOS);
				setState(1053); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(1052);
						match(INTRO);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(1055); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,189,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(1058);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMENT_ABRIR || _la==COMENT_LINEA) {
					{
					setState(1057);
					comentario();
					}
				}

				setState(1063);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==INTRO) {
					{
					{
					setState(1060);
					match(INTRO);
					}
					}
					setState(1065);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1073); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(1066);
					funciones();
					setState(1070);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==INTRO) {
						{
						{
						setState(1067);
						match(INTRO);
						}
						}
						setState(1072);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
					}
					setState(1075); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( ((((_la - 28)) & ~0x3f) == 0 && ((1L << (_la - 28)) & ((1L << (CABECERA_DEFINIR - 28)) | (1L << (CABECERA_ESCRIBIR - 28)) | (1L << (CABECERA_LEER - 28)) | (1L << (CABECERA_SI - 28)) | (1L << (CABECERA_PARA - 28)) | (1L << (CABECERA_MIENTRAS - 28)) | (1L << (CABECERA_REPETIR - 28)) | (1L << (CABECERA_SEGUN - 28)) | (1L << (CABECERA_DIMENSION - 28)) | (1L << (VAR - 28)))) != 0) );
				}
				}
				setState(1081);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1082);
			match(DE);
			setState(1084); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(1083);
				match(ESPACIO);
				}
				}
				setState(1086); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(1088);
			match(OTRO);
			setState(1090); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(1089);
				match(ESPACIO);
				}
				}
				setState(1092); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(1094);
			match(MODO);
			setState(1098);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1095);
				match(ESPACIO);
				}
				}
				setState(1100);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1101);
			match(DOS_PUNTOS);
			setState(1103); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(1102);
					match(INTRO);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(1105); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,198,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(1108);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==COMENT_ABRIR || _la==COMENT_LINEA) {
				{
				setState(1107);
				comentario();
				}
			}

			setState(1113);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==INTRO) {
				{
				{
				setState(1110);
				match(INTRO);
				}
				}
				setState(1115);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1116);
			funciones();
			setState(1120);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==INTRO) {
				{
				{
				setState(1117);
				match(INTRO);
				}
				}
				setState(1122);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1123);
			match(FIN_SEGUN);
			setState(1138);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,205,_ctx) ) {
			case 1:
				{
				setState(1125); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(1124);
						match(INTRO);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(1127); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,202,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(1130);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,203,_ctx) ) {
				case 1:
					{
					setState(1129);
					comentario();
					}
					break;
				}
				setState(1135);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,204,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(1132);
						match(INTRO);
						}
						} 
					}
					setState(1137);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,204,_ctx);
				}
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DimensionContext extends ParserRuleContext {
		public TerminalNode CABECERA_DIMENSION() { return getToken(ElParser.CABECERA_DIMENSION, 0); }
		public List<TerminalNode> VAR() { return getTokens(ElParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ElParser.VAR, i);
		}
		public TerminalNode APERTURA_CORCHETE() { return getToken(ElParser.APERTURA_CORCHETE, 0); }
		public TerminalNode CIERRE_CORCHETE() { return getToken(ElParser.CIERRE_CORCHETE, 0); }
		public List<TerminalNode> NUMEROS() { return getTokens(ElParser.NUMEROS); }
		public TerminalNode NUMEROS(int i) {
			return getToken(ElParser.NUMEROS, i);
		}
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> COMA() { return getTokens(ElParser.COMA); }
		public TerminalNode COMA(int i) {
			return getToken(ElParser.COMA, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public ComentarioContext comentario() {
			return getRuleContext(ComentarioContext.class,0);
		}
		public DimensionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dimension; }
	}

	public final DimensionContext dimension() throws RecognitionException {
		DimensionContext _localctx = new DimensionContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_dimension);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1140);
			match(CABECERA_DIMENSION);
			setState(1142); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(1141);
				match(ESPACIO);
				}
				}
				setState(1144); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(1146);
			match(VAR);
			setState(1150);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1147);
				match(ESPACIO);
				}
				}
				setState(1152);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1153);
			match(APERTURA_CORCHETE);
			setState(1157);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1154);
				match(ESPACIO);
				}
				}
				setState(1159);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1160);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1164);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,209,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1161);
					match(ESPACIO);
					}
					} 
				}
				setState(1166);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,209,_ctx);
			}
			setState(1177);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMA) {
				{
				{
				setState(1167);
				match(COMA);
				setState(1171);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==ESPACIO) {
					{
					{
					setState(1168);
					match(ESPACIO);
					}
					}
					setState(1173);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1174);
				_la = _input.LA(1);
				if ( !(_la==NUMEROS || _la==VAR) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				}
				setState(1179);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1183);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1180);
				match(ESPACIO);
				}
				}
				setState(1185);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1186);
			match(CIERRE_CORCHETE);
			setState(1201);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,216,_ctx) ) {
			case 1:
				{
				setState(1188); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(1187);
						match(INTRO);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(1190); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,213,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(1193);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,214,_ctx) ) {
				case 1:
					{
					setState(1192);
					comentario();
					}
					break;
				}
				setState(1198);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,215,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(1195);
						match(INTRO);
						}
						} 
					}
					setState(1200);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,215,_ctx);
				}
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FuncionesContext extends ParserRuleContext {
		public AsignacionContext asignacion() {
			return getRuleContext(AsignacionContext.class,0);
		}
		public LeerContext leer() {
			return getRuleContext(LeerContext.class,0);
		}
		public DefinirContext definir() {
			return getRuleContext(DefinirContext.class,0);
		}
		public EscribirContext escribir() {
			return getRuleContext(EscribirContext.class,0);
		}
		public SiContext si() {
			return getRuleContext(SiContext.class,0);
		}
		public ParaContext para() {
			return getRuleContext(ParaContext.class,0);
		}
		public MientrasContext mientras() {
			return getRuleContext(MientrasContext.class,0);
		}
		public RepetirContext repetir() {
			return getRuleContext(RepetirContext.class,0);
		}
		public SegunContext segun() {
			return getRuleContext(SegunContext.class,0);
		}
		public DimensionContext dimension() {
			return getRuleContext(DimensionContext.class,0);
		}
		public FuncionesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_funciones; }
	}

	public final FuncionesContext funciones() throws RecognitionException {
		FuncionesContext _localctx = new FuncionesContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_funciones);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1213);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case VAR:
				{
				setState(1203);
				asignacion();
				}
				break;
			case CABECERA_LEER:
				{
				setState(1204);
				leer();
				}
				break;
			case CABECERA_DEFINIR:
				{
				setState(1205);
				definir();
				}
				break;
			case CABECERA_ESCRIBIR:
				{
				setState(1206);
				escribir();
				}
				break;
			case CABECERA_SI:
				{
				setState(1207);
				si();
				}
				break;
			case CABECERA_PARA:
				{
				setState(1208);
				para();
				}
				break;
			case CABECERA_MIENTRAS:
				{
				setState(1209);
				mientras();
				}
				break;
			case CABECERA_REPETIR:
				{
				setState(1210);
				repetir();
				}
				break;
			case CABECERA_SEGUN:
				{
				setState(1211);
				segun();
				}
				break;
			case CABECERA_DIMENSION:
				{
				setState(1212);
				dimension();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FuncionContext extends ParserRuleContext {
		public TerminalNode CABECERA_FUNCION() { return getToken(ElParser.CABECERA_FUNCION, 0); }
		public List<TerminalNode> VAR() { return getTokens(ElParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ElParser.VAR, i);
		}
		public TerminalNode FIN_FUNCION() { return getToken(ElParser.FIN_FUNCION, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public TerminalNode FLECHA_ASIGNACION() { return getToken(ElParser.FLECHA_ASIGNACION, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public List<ComentarioContext> comentario() {
			return getRuleContexts(ComentarioContext.class);
		}
		public ComentarioContext comentario(int i) {
			return getRuleContext(ComentarioContext.class,i);
		}
		public List<FuncionesContext> funciones() {
			return getRuleContexts(FuncionesContext.class);
		}
		public FuncionesContext funciones(int i) {
			return getRuleContext(FuncionesContext.class,i);
		}
		public List<TerminalNode> NUMEROS() { return getTokens(ElParser.NUMEROS); }
		public TerminalNode NUMEROS(int i) {
			return getToken(ElParser.NUMEROS, i);
		}
		public List<TerminalNode> COMA() { return getTokens(ElParser.COMA); }
		public TerminalNode COMA(int i) {
			return getToken(ElParser.COMA, i);
		}
		public List<TerminalNode> POR_VALOR() { return getTokens(ElParser.POR_VALOR); }
		public TerminalNode POR_VALOR(int i) {
			return getToken(ElParser.POR_VALOR, i);
		}
		public List<TerminalNode> POR_REFERENCIA() { return getTokens(ElParser.POR_REFERENCIA); }
		public TerminalNode POR_REFERENCIA(int i) {
			return getToken(ElParser.POR_REFERENCIA, i);
		}
		public FuncionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_funcion; }
	}

	public final FuncionContext funcion() throws RecognitionException {
		FuncionContext _localctx = new FuncionContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_funcion);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1215);
			match(CABECERA_FUNCION);
			setState(1217); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(1216);
					match(ESPACIO);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(1219); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,218,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(1229);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,220,_ctx) ) {
			case 1:
				{
				setState(1221);
				match(VAR);
				setState(1225);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==ESPACIO) {
					{
					{
					setState(1222);
					match(ESPACIO);
					}
					}
					setState(1227);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1228);
				match(FLECHA_ASIGNACION);
				}
				break;
			}
			setState(1234);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1231);
				match(ESPACIO);
				}
				}
				setState(1236);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1237);
			match(VAR);
			setState(1241);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1238);
				match(ESPACIO);
				}
				}
				setState(1243);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1298);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==APERTURA_PARENTESIS) {
				{
				setState(1244);
				match(APERTURA_PARENTESIS);
				setState(1248);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,223,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(1245);
						match(ESPACIO);
						}
						} 
					}
					setState(1250);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,223,_ctx);
				}
				setState(1289);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NUMEROS || _la==VAR) {
					{
					setState(1251);
					_la = _input.LA(1);
					if ( !(_la==NUMEROS || _la==VAR) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					setState(1259);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,225,_ctx) ) {
					case 1:
						{
						setState(1255);
						_errHandler.sync(this);
						_la = _input.LA(1);
						while (_la==ESPACIO) {
							{
							{
							setState(1252);
							match(ESPACIO);
							}
							}
							setState(1257);
							_errHandler.sync(this);
							_la = _input.LA(1);
						}
						setState(1258);
						_la = _input.LA(1);
						if ( !(_la==POR_VALOR || _la==POR_REFERENCIA) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						}
						break;
					}
					setState(1286);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,230,_ctx);
					while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
						if ( _alt==1 ) {
							{
							{
							setState(1264);
							_errHandler.sync(this);
							_la = _input.LA(1);
							while (_la==ESPACIO) {
								{
								{
								setState(1261);
								match(ESPACIO);
								}
								}
								setState(1266);
								_errHandler.sync(this);
								_la = _input.LA(1);
							}
							setState(1267);
							match(COMA);
							setState(1271);
							_errHandler.sync(this);
							_la = _input.LA(1);
							while (_la==ESPACIO) {
								{
								{
								setState(1268);
								match(ESPACIO);
								}
								}
								setState(1273);
								_errHandler.sync(this);
								_la = _input.LA(1);
							}
							setState(1274);
							_la = _input.LA(1);
							if ( !(_la==NUMEROS || _la==VAR) ) {
							_errHandler.recoverInline(this);
							}
							else {
								if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
								_errHandler.reportMatch(this);
								consume();
							}
							setState(1282);
							_errHandler.sync(this);
							switch ( getInterpreter().adaptivePredict(_input,229,_ctx) ) {
							case 1:
								{
								setState(1278);
								_errHandler.sync(this);
								_la = _input.LA(1);
								while (_la==ESPACIO) {
									{
									{
									setState(1275);
									match(ESPACIO);
									}
									}
									setState(1280);
									_errHandler.sync(this);
									_la = _input.LA(1);
								}
								setState(1281);
								_la = _input.LA(1);
								if ( !(_la==POR_VALOR || _la==POR_REFERENCIA) ) {
								_errHandler.recoverInline(this);
								}
								else {
									if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
									_errHandler.reportMatch(this);
									consume();
								}
								}
								break;
							}
							}
							} 
						}
						setState(1288);
						_errHandler.sync(this);
						_alt = getInterpreter().adaptivePredict(_input,230,_ctx);
					}
					}
				}

				setState(1294);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==ESPACIO) {
					{
					{
					setState(1291);
					match(ESPACIO);
					}
					}
					setState(1296);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1297);
				match(CIERRE_PARENTESIS);
				}
			}

			setState(1301); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(1300);
					match(INTRO);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(1303); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,234,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(1306);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==COMENT_ABRIR || _la==COMENT_LINEA) {
				{
				setState(1305);
				comentario();
				}
			}

			setState(1311);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==INTRO) {
				{
				{
				setState(1308);
				match(INTRO);
				}
				}
				setState(1313);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1323);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 28)) & ~0x3f) == 0 && ((1L << (_la - 28)) & ((1L << (CABECERA_DEFINIR - 28)) | (1L << (CABECERA_ESCRIBIR - 28)) | (1L << (CABECERA_LEER - 28)) | (1L << (CABECERA_SI - 28)) | (1L << (CABECERA_PARA - 28)) | (1L << (CABECERA_MIENTRAS - 28)) | (1L << (CABECERA_REPETIR - 28)) | (1L << (CABECERA_SEGUN - 28)) | (1L << (CABECERA_DIMENSION - 28)) | (1L << (VAR - 28)))) != 0)) {
				{
				{
				setState(1314);
				funciones();
				setState(1318);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==INTRO) {
					{
					{
					setState(1315);
					match(INTRO);
					}
					}
					setState(1320);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				}
				setState(1325);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1326);
			match(FIN_FUNCION);
			setState(1341);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,242,_ctx) ) {
			case 1:
				{
				setState(1328); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(1327);
						match(INTRO);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(1330); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,239,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(1333);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,240,_ctx) ) {
				case 1:
					{
					setState(1332);
					comentario();
					}
					break;
				}
				setState(1338);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,241,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(1335);
						match(INTRO);
						}
						} 
					}
					setState(1340);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,241,_ctx);
				}
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AbsContext extends ParserRuleContext {
		public TerminalNode CABECERA_ABS() { return getToken(ElParser.CABECERA_ABS, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public ComentarioContext comentario() {
			return getRuleContext(ComentarioContext.class,0);
		}
		public AbsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_abs; }
	}

	public final AbsContext abs() throws RecognitionException {
		AbsContext _localctx = new AbsContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_abs);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1343);
			match(CABECERA_ABS);
			setState(1347);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1344);
				match(ESPACIO);
				}
				}
				setState(1349);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1350);
			match(APERTURA_PARENTESIS);
			setState(1354);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1351);
				match(ESPACIO);
				}
				}
				setState(1356);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1357);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1361);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1358);
				match(ESPACIO);
				}
				}
				setState(1363);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1364);
			match(CIERRE_PARENTESIS);
			setState(1366); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(1365);
					match(INTRO);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(1368); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,246,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(1371);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,247,_ctx) ) {
			case 1:
				{
				setState(1370);
				comentario();
				}
				break;
			}
			setState(1376);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,248,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1373);
					match(INTRO);
					}
					} 
				}
				setState(1378);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,248,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TruncContext extends ParserRuleContext {
		public TerminalNode CABECERA_TRUNC() { return getToken(ElParser.CABECERA_TRUNC, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public TruncContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_trunc; }
	}

	public final TruncContext trunc() throws RecognitionException {
		TruncContext _localctx = new TruncContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_trunc);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1379);
			match(CABECERA_TRUNC);
			setState(1383);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1380);
				match(ESPACIO);
				}
				}
				setState(1385);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1386);
			match(APERTURA_PARENTESIS);
			setState(1390);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1387);
				match(ESPACIO);
				}
				}
				setState(1392);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1393);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1397);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1394);
				match(ESPACIO);
				}
				}
				setState(1399);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1400);
			match(CIERRE_PARENTESIS);
			setState(1404);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,252,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1401);
					match(INTRO);
					}
					} 
				}
				setState(1406);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,252,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RedonContext extends ParserRuleContext {
		public TerminalNode CABECERA_REDON() { return getToken(ElParser.CABECERA_REDON, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public RedonContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_redon; }
	}

	public final RedonContext redon() throws RecognitionException {
		RedonContext _localctx = new RedonContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_redon);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1407);
			match(CABECERA_REDON);
			setState(1411);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1408);
				match(ESPACIO);
				}
				}
				setState(1413);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1414);
			match(APERTURA_PARENTESIS);
			setState(1418);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1415);
				match(ESPACIO);
				}
				}
				setState(1420);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1421);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1425);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1422);
				match(ESPACIO);
				}
				}
				setState(1427);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1428);
			match(CIERRE_PARENTESIS);
			setState(1432);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,256,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1429);
					match(INTRO);
					}
					} 
				}
				setState(1434);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,256,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RcContext extends ParserRuleContext {
		public TerminalNode CABECERA_RC() { return getToken(ElParser.CABECERA_RC, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public RcContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rc; }
	}

	public final RcContext rc() throws RecognitionException {
		RcContext _localctx = new RcContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_rc);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1435);
			match(CABECERA_RC);
			setState(1439);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1436);
				match(ESPACIO);
				}
				}
				setState(1441);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1442);
			match(APERTURA_PARENTESIS);
			setState(1446);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1443);
				match(ESPACIO);
				}
				}
				setState(1448);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1449);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1453);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1450);
				match(ESPACIO);
				}
				}
				setState(1455);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1456);
			match(CIERRE_PARENTESIS);
			setState(1460);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,260,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1457);
					match(INTRO);
					}
					} 
				}
				setState(1462);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,260,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SenContext extends ParserRuleContext {
		public TerminalNode CABECERA_SEN() { return getToken(ElParser.CABECERA_SEN, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public SenContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sen; }
	}

	public final SenContext sen() throws RecognitionException {
		SenContext _localctx = new SenContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_sen);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1463);
			match(CABECERA_SEN);
			setState(1467);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1464);
				match(ESPACIO);
				}
				}
				setState(1469);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1470);
			match(APERTURA_PARENTESIS);
			setState(1474);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1471);
				match(ESPACIO);
				}
				}
				setState(1476);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1477);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1481);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1478);
				match(ESPACIO);
				}
				}
				setState(1483);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1484);
			match(CIERRE_PARENTESIS);
			setState(1488);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,264,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1485);
					match(INTRO);
					}
					} 
				}
				setState(1490);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,264,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CosContext extends ParserRuleContext {
		public TerminalNode CABECERA_COS() { return getToken(ElParser.CABECERA_COS, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public CosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cos; }
	}

	public final CosContext cos() throws RecognitionException {
		CosContext _localctx = new CosContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_cos);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1491);
			match(CABECERA_COS);
			setState(1495);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1492);
				match(ESPACIO);
				}
				}
				setState(1497);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1498);
			match(APERTURA_PARENTESIS);
			setState(1502);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1499);
				match(ESPACIO);
				}
				}
				setState(1504);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1505);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1509);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1506);
				match(ESPACIO);
				}
				}
				setState(1511);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1512);
			match(CIERRE_PARENTESIS);
			setState(1516);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,268,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1513);
					match(INTRO);
					}
					} 
				}
				setState(1518);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,268,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TanContext extends ParserRuleContext {
		public TerminalNode CABECERA_TAN() { return getToken(ElParser.CABECERA_TAN, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public TanContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tan; }
	}

	public final TanContext tan() throws RecognitionException {
		TanContext _localctx = new TanContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_tan);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1519);
			match(CABECERA_TAN);
			setState(1523);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1520);
				match(ESPACIO);
				}
				}
				setState(1525);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1526);
			match(APERTURA_PARENTESIS);
			setState(1530);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1527);
				match(ESPACIO);
				}
				}
				setState(1532);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1533);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1537);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1534);
				match(ESPACIO);
				}
				}
				setState(1539);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1540);
			match(CIERRE_PARENTESIS);
			setState(1544);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,272,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1541);
					match(INTRO);
					}
					} 
				}
				setState(1546);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,272,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AsenContext extends ParserRuleContext {
		public TerminalNode CABECERA_ASEN() { return getToken(ElParser.CABECERA_ASEN, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public AsenContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_asen; }
	}

	public final AsenContext asen() throws RecognitionException {
		AsenContext _localctx = new AsenContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_asen);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1547);
			match(CABECERA_ASEN);
			setState(1551);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1548);
				match(ESPACIO);
				}
				}
				setState(1553);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1554);
			match(APERTURA_PARENTESIS);
			setState(1558);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1555);
				match(ESPACIO);
				}
				}
				setState(1560);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1561);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1565);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1562);
				match(ESPACIO);
				}
				}
				setState(1567);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1568);
			match(CIERRE_PARENTESIS);
			setState(1572);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,276,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1569);
					match(INTRO);
					}
					} 
				}
				setState(1574);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,276,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AcosContext extends ParserRuleContext {
		public TerminalNode CABECERA_ACOS() { return getToken(ElParser.CABECERA_ACOS, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public AcosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_acos; }
	}

	public final AcosContext acos() throws RecognitionException {
		AcosContext _localctx = new AcosContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_acos);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1575);
			match(CABECERA_ACOS);
			setState(1579);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1576);
				match(ESPACIO);
				}
				}
				setState(1581);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1582);
			match(APERTURA_PARENTESIS);
			setState(1586);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1583);
				match(ESPACIO);
				}
				}
				setState(1588);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1589);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1593);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1590);
				match(ESPACIO);
				}
				}
				setState(1595);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1596);
			match(CIERRE_PARENTESIS);
			setState(1600);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,280,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1597);
					match(INTRO);
					}
					} 
				}
				setState(1602);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,280,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AtanContext extends ParserRuleContext {
		public TerminalNode CABECERA_ATAN() { return getToken(ElParser.CABECERA_ATAN, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public AtanContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atan; }
	}

	public final AtanContext atan() throws RecognitionException {
		AtanContext _localctx = new AtanContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_atan);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1603);
			match(CABECERA_ATAN);
			setState(1607);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1604);
				match(ESPACIO);
				}
				}
				setState(1609);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1610);
			match(APERTURA_PARENTESIS);
			setState(1614);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1611);
				match(ESPACIO);
				}
				}
				setState(1616);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1617);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1621);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1618);
				match(ESPACIO);
				}
				}
				setState(1623);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1624);
			match(CIERRE_PARENTESIS);
			setState(1628);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,284,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1625);
					match(INTRO);
					}
					} 
				}
				setState(1630);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,284,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LnContext extends ParserRuleContext {
		public TerminalNode CABECERA_LN() { return getToken(ElParser.CABECERA_LN, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public LnContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ln; }
	}

	public final LnContext ln() throws RecognitionException {
		LnContext _localctx = new LnContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_ln);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1631);
			match(CABECERA_LN);
			setState(1635);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1632);
				match(ESPACIO);
				}
				}
				setState(1637);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1638);
			match(APERTURA_PARENTESIS);
			setState(1642);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1639);
				match(ESPACIO);
				}
				}
				setState(1644);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1645);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1649);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1646);
				match(ESPACIO);
				}
				}
				setState(1651);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1652);
			match(CIERRE_PARENTESIS);
			setState(1656);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,288,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1653);
					match(INTRO);
					}
					} 
				}
				setState(1658);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,288,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpContext extends ParserRuleContext {
		public TerminalNode CABECERA_EXP() { return getToken(ElParser.CABECERA_EXP, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public ExpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exp; }
	}

	public final ExpContext exp() throws RecognitionException {
		ExpContext _localctx = new ExpContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_exp);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1659);
			match(CABECERA_EXP);
			setState(1663);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1660);
				match(ESPACIO);
				}
				}
				setState(1665);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1666);
			match(APERTURA_PARENTESIS);
			setState(1670);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1667);
				match(ESPACIO);
				}
				}
				setState(1672);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1673);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1677);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1674);
				match(ESPACIO);
				}
				}
				setState(1679);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1680);
			match(CIERRE_PARENTESIS);
			setState(1684);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,292,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1681);
					match(INTRO);
					}
					} 
				}
				setState(1686);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,292,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AzarContext extends ParserRuleContext {
		public TerminalNode CABECERA_AZAR() { return getToken(ElParser.CABECERA_AZAR, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public AzarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_azar; }
	}

	public final AzarContext azar() throws RecognitionException {
		AzarContext _localctx = new AzarContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_azar);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1687);
			match(CABECERA_AZAR);
			setState(1691);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1688);
				match(ESPACIO);
				}
				}
				setState(1693);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1694);
			match(APERTURA_PARENTESIS);
			setState(1698);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1695);
				match(ESPACIO);
				}
				}
				setState(1700);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1701);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1705);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1702);
				match(ESPACIO);
				}
				}
				setState(1707);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1708);
			match(CIERRE_PARENTESIS);
			setState(1712);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,296,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1709);
					match(INTRO);
					}
					} 
				}
				setState(1714);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,296,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Func_matematicasContext extends ParserRuleContext {
		public AbsContext abs() {
			return getRuleContext(AbsContext.class,0);
		}
		public TruncContext trunc() {
			return getRuleContext(TruncContext.class,0);
		}
		public RedonContext redon() {
			return getRuleContext(RedonContext.class,0);
		}
		public RcContext rc() {
			return getRuleContext(RcContext.class,0);
		}
		public SenContext sen() {
			return getRuleContext(SenContext.class,0);
		}
		public CosContext cos() {
			return getRuleContext(CosContext.class,0);
		}
		public TanContext tan() {
			return getRuleContext(TanContext.class,0);
		}
		public AsenContext asen() {
			return getRuleContext(AsenContext.class,0);
		}
		public AcosContext acos() {
			return getRuleContext(AcosContext.class,0);
		}
		public AtanContext atan() {
			return getRuleContext(AtanContext.class,0);
		}
		public LnContext ln() {
			return getRuleContext(LnContext.class,0);
		}
		public ExpContext exp() {
			return getRuleContext(ExpContext.class,0);
		}
		public AzarContext azar() {
			return getRuleContext(AzarContext.class,0);
		}
		public TerminalNode PUNTO_Y_COMA() { return getToken(ElParser.PUNTO_Y_COMA, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public Func_matematicasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_func_matematicas; }
	}

	public final Func_matematicasContext func_matematicas() throws RecognitionException {
		Func_matematicasContext _localctx = new Func_matematicasContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_func_matematicas);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(1728);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CABECERA_ABS:
				{
				setState(1715);
				abs();
				}
				break;
			case CABECERA_TRUNC:
				{
				setState(1716);
				trunc();
				}
				break;
			case CABECERA_REDON:
				{
				setState(1717);
				redon();
				}
				break;
			case CABECERA_RC:
				{
				setState(1718);
				rc();
				}
				break;
			case CABECERA_SEN:
				{
				setState(1719);
				sen();
				}
				break;
			case CABECERA_COS:
				{
				setState(1720);
				cos();
				}
				break;
			case CABECERA_TAN:
				{
				setState(1721);
				tan();
				}
				break;
			case CABECERA_ASEN:
				{
				setState(1722);
				asen();
				}
				break;
			case CABECERA_ACOS:
				{
				setState(1723);
				acos();
				}
				break;
			case CABECERA_ATAN:
				{
				setState(1724);
				atan();
				}
				break;
			case CABECERA_LN:
				{
				setState(1725);
				ln();
				}
				break;
			case CABECERA_EXP:
				{
				setState(1726);
				exp();
				}
				break;
			case CABECERA_AZAR:
				{
				setState(1727);
				azar();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(1737);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,299,_ctx) ) {
			case 1:
				{
				setState(1733);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==ESPACIO) {
					{
					{
					setState(1730);
					match(ESPACIO);
					}
					}
					setState(1735);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1736);
				match(PUNTO_Y_COMA);
				}
				break;
			}
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LongitudContext extends ParserRuleContext {
		public TerminalNode CABECERA_LONGITUD() { return getToken(ElParser.CABECERA_LONGITUD, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public LongitudContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_longitud; }
	}

	public final LongitudContext longitud() throws RecognitionException {
		LongitudContext _localctx = new LongitudContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_longitud);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1739);
			match(CABECERA_LONGITUD);
			setState(1743);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1740);
				match(ESPACIO);
				}
				}
				setState(1745);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1746);
			match(APERTURA_PARENTESIS);
			setState(1750);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1747);
				match(ESPACIO);
				}
				}
				setState(1752);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1753);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1757);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1754);
				match(ESPACIO);
				}
				}
				setState(1759);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1760);
			match(CIERRE_PARENTESIS);
			setState(1764);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,303,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1761);
					match(INTRO);
					}
					} 
				}
				setState(1766);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,303,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Sub_cadenaContext extends ParserRuleContext {
		public TerminalNode CABECERA_SUB_CADENA() { return getToken(ElParser.CABECERA_SUB_CADENA, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public List<TerminalNode> COMA() { return getTokens(ElParser.COMA); }
		public TerminalNode COMA(int i) {
			return getToken(ElParser.COMA, i);
		}
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode TOPRINT() { return getToken(ElParser.TOPRINT, 0); }
		public List<TerminalNode> VAR() { return getTokens(ElParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ElParser.VAR, i);
		}
		public List<TerminalNode> NUMEROS() { return getTokens(ElParser.NUMEROS); }
		public TerminalNode NUMEROS(int i) {
			return getToken(ElParser.NUMEROS, i);
		}
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public Sub_cadenaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sub_cadena; }
	}

	public final Sub_cadenaContext sub_cadena() throws RecognitionException {
		Sub_cadenaContext _localctx = new Sub_cadenaContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_sub_cadena);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1767);
			match(CABECERA_SUB_CADENA);
			setState(1771);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1768);
				match(ESPACIO);
				}
				}
				setState(1773);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1774);
			match(APERTURA_PARENTESIS);
			setState(1778);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1775);
				match(ESPACIO);
				}
				}
				setState(1780);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1781);
			_la = _input.LA(1);
			if ( !(_la==VAR || _la==TOPRINT) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1785);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1782);
				match(ESPACIO);
				}
				}
				setState(1787);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1788);
			match(COMA);
			setState(1792);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1789);
				match(ESPACIO);
				}
				}
				setState(1794);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1795);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1799);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1796);
				match(ESPACIO);
				}
				}
				setState(1801);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1802);
			match(COMA);
			setState(1806);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1803);
				match(ESPACIO);
				}
				}
				setState(1808);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1809);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1813);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1810);
				match(ESPACIO);
				}
				}
				setState(1815);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1816);
			match(CIERRE_PARENTESIS);
			setState(1820);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,311,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1817);
					match(INTRO);
					}
					} 
				}
				setState(1822);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,311,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConcatenarContext extends ParserRuleContext {
		public TerminalNode CABECERA_CONCATENAR() { return getToken(ElParser.CABECERA_CONCATENAR, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode COMA() { return getToken(ElParser.COMA, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public List<TerminalNode> TOPRINT() { return getTokens(ElParser.TOPRINT); }
		public TerminalNode TOPRINT(int i) {
			return getToken(ElParser.TOPRINT, i);
		}
		public List<TerminalNode> VAR() { return getTokens(ElParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ElParser.VAR, i);
		}
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public ConcatenarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_concatenar; }
	}

	public final ConcatenarContext concatenar() throws RecognitionException {
		ConcatenarContext _localctx = new ConcatenarContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_concatenar);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1823);
			match(CABECERA_CONCATENAR);
			setState(1827);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1824);
				match(ESPACIO);
				}
				}
				setState(1829);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1830);
			match(APERTURA_PARENTESIS);
			setState(1834);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1831);
				match(ESPACIO);
				}
				}
				setState(1836);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1837);
			_la = _input.LA(1);
			if ( !(_la==VAR || _la==TOPRINT) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1841);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1838);
				match(ESPACIO);
				}
				}
				setState(1843);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1844);
			match(COMA);
			setState(1848);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1845);
				match(ESPACIO);
				}
				}
				setState(1850);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1851);
			_la = _input.LA(1);
			if ( !(_la==VAR || _la==TOPRINT) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1855);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1852);
				match(ESPACIO);
				}
				}
				setState(1857);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1858);
			match(CIERRE_PARENTESIS);
			setState(1862);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,317,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1859);
					match(INTRO);
					}
					} 
				}
				setState(1864);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,317,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Convertir_a_numeroContext extends ParserRuleContext {
		public TerminalNode CABECERA_CONVERTIR_A_NUMERO() { return getToken(ElParser.CABECERA_CONVERTIR_A_NUMERO, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode TOPRINT() { return getToken(ElParser.TOPRINT, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public Convertir_a_numeroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_convertir_a_numero; }
	}

	public final Convertir_a_numeroContext convertir_a_numero() throws RecognitionException {
		Convertir_a_numeroContext _localctx = new Convertir_a_numeroContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_convertir_a_numero);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1865);
			match(CABECERA_CONVERTIR_A_NUMERO);
			setState(1869);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1866);
				match(ESPACIO);
				}
				}
				setState(1871);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1872);
			match(APERTURA_PARENTESIS);
			setState(1876);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1873);
				match(ESPACIO);
				}
				}
				setState(1878);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1879);
			_la = _input.LA(1);
			if ( !(_la==VAR || _la==TOPRINT) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1883);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1880);
				match(ESPACIO);
				}
				}
				setState(1885);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1886);
			match(CIERRE_PARENTESIS);
			setState(1890);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,321,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1887);
					match(INTRO);
					}
					} 
				}
				setState(1892);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,321,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Convertir_a_textoContext extends ParserRuleContext {
		public TerminalNode CABECERA_CONVERTIR_A_TEXTO() { return getToken(ElParser.CABECERA_CONVERTIR_A_TEXTO, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode NUMEROS() { return getToken(ElParser.NUMEROS, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public Convertir_a_textoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_convertir_a_texto; }
	}

	public final Convertir_a_textoContext convertir_a_texto() throws RecognitionException {
		Convertir_a_textoContext _localctx = new Convertir_a_textoContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_convertir_a_texto);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1893);
			match(CABECERA_CONVERTIR_A_TEXTO);
			setState(1897);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1894);
				match(ESPACIO);
				}
				}
				setState(1899);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1900);
			match(APERTURA_PARENTESIS);
			setState(1904);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1901);
				match(ESPACIO);
				}
				}
				setState(1906);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1907);
			_la = _input.LA(1);
			if ( !(_la==NUMEROS || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1911);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1908);
				match(ESPACIO);
				}
				}
				setState(1913);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1914);
			match(CIERRE_PARENTESIS);
			setState(1918);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,325,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1915);
					match(INTRO);
					}
					} 
				}
				setState(1920);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,325,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MayusculasContext extends ParserRuleContext {
		public TerminalNode CABECERA_MAYUSCULAS() { return getToken(ElParser.CABECERA_MAYUSCULAS, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode TOPRINT() { return getToken(ElParser.TOPRINT, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public MayusculasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mayusculas; }
	}

	public final MayusculasContext mayusculas() throws RecognitionException {
		MayusculasContext _localctx = new MayusculasContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_mayusculas);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1921);
			match(CABECERA_MAYUSCULAS);
			setState(1925);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1922);
				match(ESPACIO);
				}
				}
				setState(1927);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1928);
			match(APERTURA_PARENTESIS);
			setState(1932);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1929);
				match(ESPACIO);
				}
				}
				setState(1934);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1935);
			_la = _input.LA(1);
			if ( !(_la==VAR || _la==TOPRINT) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1939);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1936);
				match(ESPACIO);
				}
				}
				setState(1941);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1942);
			match(CIERRE_PARENTESIS);
			setState(1946);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,329,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1943);
					match(INTRO);
					}
					} 
				}
				setState(1948);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,329,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MinusculasContext extends ParserRuleContext {
		public TerminalNode CABECERA_MINUSCULAS() { return getToken(ElParser.CABECERA_MINUSCULAS, 0); }
		public TerminalNode APERTURA_PARENTESIS() { return getToken(ElParser.APERTURA_PARENTESIS, 0); }
		public TerminalNode CIERRE_PARENTESIS() { return getToken(ElParser.CIERRE_PARENTESIS, 0); }
		public TerminalNode TOPRINT() { return getToken(ElParser.TOPRINT, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public MinusculasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_minusculas; }
	}

	public final MinusculasContext minusculas() throws RecognitionException {
		MinusculasContext _localctx = new MinusculasContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_minusculas);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1949);
			match(CABECERA_MINUSCULAS);
			setState(1953);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1950);
				match(ESPACIO);
				}
				}
				setState(1955);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1956);
			match(APERTURA_PARENTESIS);
			setState(1960);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1957);
				match(ESPACIO);
				}
				}
				setState(1962);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1963);
			_la = _input.LA(1);
			if ( !(_la==VAR || _la==TOPRINT) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1967);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ESPACIO) {
				{
				{
				setState(1964);
				match(ESPACIO);
				}
				}
				setState(1969);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1970);
			match(CIERRE_PARENTESIS);
			setState(1974);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,333,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(1971);
					match(INTRO);
					}
					} 
				}
				setState(1976);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,333,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Func_cadenasContext extends ParserRuleContext {
		public LongitudContext longitud() {
			return getRuleContext(LongitudContext.class,0);
		}
		public Sub_cadenaContext sub_cadena() {
			return getRuleContext(Sub_cadenaContext.class,0);
		}
		public ConcatenarContext concatenar() {
			return getRuleContext(ConcatenarContext.class,0);
		}
		public Convertir_a_numeroContext convertir_a_numero() {
			return getRuleContext(Convertir_a_numeroContext.class,0);
		}
		public Convertir_a_textoContext convertir_a_texto() {
			return getRuleContext(Convertir_a_textoContext.class,0);
		}
		public MayusculasContext mayusculas() {
			return getRuleContext(MayusculasContext.class,0);
		}
		public MinusculasContext minusculas() {
			return getRuleContext(MinusculasContext.class,0);
		}
		public TerminalNode PUNTO_Y_COMA() { return getToken(ElParser.PUNTO_Y_COMA, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public Func_cadenasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_func_cadenas; }
	}

	public final Func_cadenasContext func_cadenas() throws RecognitionException {
		Func_cadenasContext _localctx = new Func_cadenasContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_func_cadenas);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(1984);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CABECERA_LONGITUD:
				{
				setState(1977);
				longitud();
				}
				break;
			case CABECERA_SUB_CADENA:
				{
				setState(1978);
				sub_cadena();
				}
				break;
			case CABECERA_CONCATENAR:
				{
				setState(1979);
				concatenar();
				}
				break;
			case CABECERA_CONVERTIR_A_NUMERO:
				{
				setState(1980);
				convertir_a_numero();
				}
				break;
			case CABECERA_CONVERTIR_A_TEXTO:
				{
				setState(1981);
				convertir_a_texto();
				}
				break;
			case CABECERA_MAYUSCULAS:
				{
				setState(1982);
				mayusculas();
				}
				break;
			case CABECERA_MINUSCULAS:
				{
				setState(1983);
				minusculas();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(1993);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,336,_ctx) ) {
			case 1:
				{
				setState(1989);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==ESPACIO) {
					{
					{
					setState(1986);
					match(ESPACIO);
					}
					}
					setState(1991);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1992);
				match(PUNTO_Y_COMA);
				}
				break;
			}
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AlgoritmoContext extends ParserRuleContext {
		public TerminalNode CABECERA_ALGORITMO() { return getToken(ElParser.CABECERA_ALGORITMO, 0); }
		public TerminalNode VAR() { return getToken(ElParser.VAR, 0); }
		public TerminalNode FIN_ALGORITMO() { return getToken(ElParser.FIN_ALGORITMO, 0); }
		public List<TerminalNode> ESPACIO() { return getTokens(ElParser.ESPACIO); }
		public TerminalNode ESPACIO(int i) {
			return getToken(ElParser.ESPACIO, i);
		}
		public List<TerminalNode> INTRO() { return getTokens(ElParser.INTRO); }
		public TerminalNode INTRO(int i) {
			return getToken(ElParser.INTRO, i);
		}
		public List<ComentarioContext> comentario() {
			return getRuleContexts(ComentarioContext.class);
		}
		public ComentarioContext comentario(int i) {
			return getRuleContext(ComentarioContext.class,i);
		}
		public List<AsignacionContext> asignacion() {
			return getRuleContexts(AsignacionContext.class);
		}
		public AsignacionContext asignacion(int i) {
			return getRuleContext(AsignacionContext.class,i);
		}
		public List<LeerContext> leer() {
			return getRuleContexts(LeerContext.class);
		}
		public LeerContext leer(int i) {
			return getRuleContext(LeerContext.class,i);
		}
		public List<DefinirContext> definir() {
			return getRuleContexts(DefinirContext.class);
		}
		public DefinirContext definir(int i) {
			return getRuleContext(DefinirContext.class,i);
		}
		public List<EscribirContext> escribir() {
			return getRuleContexts(EscribirContext.class);
		}
		public EscribirContext escribir(int i) {
			return getRuleContext(EscribirContext.class,i);
		}
		public List<SiContext> si() {
			return getRuleContexts(SiContext.class);
		}
		public SiContext si(int i) {
			return getRuleContext(SiContext.class,i);
		}
		public List<ParaContext> para() {
			return getRuleContexts(ParaContext.class);
		}
		public ParaContext para(int i) {
			return getRuleContext(ParaContext.class,i);
		}
		public List<MientrasContext> mientras() {
			return getRuleContexts(MientrasContext.class);
		}
		public MientrasContext mientras(int i) {
			return getRuleContext(MientrasContext.class,i);
		}
		public List<RepetirContext> repetir() {
			return getRuleContexts(RepetirContext.class);
		}
		public RepetirContext repetir(int i) {
			return getRuleContext(RepetirContext.class,i);
		}
		public List<SegunContext> segun() {
			return getRuleContexts(SegunContext.class);
		}
		public SegunContext segun(int i) {
			return getRuleContext(SegunContext.class,i);
		}
		public List<DimensionContext> dimension() {
			return getRuleContexts(DimensionContext.class);
		}
		public DimensionContext dimension(int i) {
			return getRuleContext(DimensionContext.class,i);
		}
		public AlgoritmoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_algoritmo; }
	}

	public final AlgoritmoContext algoritmo() throws RecognitionException {
		AlgoritmoContext _localctx = new AlgoritmoContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_algoritmo);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1995);
			match(CABECERA_ALGORITMO);
			setState(1997); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(1996);
				match(ESPACIO);
				}
				}
				setState(1999); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ESPACIO );
			setState(2001);
			match(VAR);
			setState(2003); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(2002);
					match(INTRO);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(2005); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,338,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(2008);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,339,_ctx) ) {
			case 1:
				{
				setState(2007);
				comentario();
				}
				break;
			}
			setState(2013);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,340,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(2010);
					match(INTRO);
					}
					} 
				}
				setState(2015);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,340,_ctx);
			}
			setState(2028); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					setState(2028);
					_errHandler.sync(this);
					switch (_input.LA(1)) {
					case VAR:
						{
						setState(2016);
						asignacion();
						}
						break;
					case COMENT_ABRIR:
					case COMENT_LINEA:
						{
						setState(2017);
						comentario();
						}
						break;
					case CABECERA_LEER:
						{
						setState(2018);
						leer();
						}
						break;
					case CABECERA_DEFINIR:
						{
						setState(2019);
						definir();
						}
						break;
					case CABECERA_ESCRIBIR:
						{
						setState(2020);
						escribir();
						}
						break;
					case CABECERA_SI:
						{
						setState(2021);
						si();
						}
						break;
					case CABECERA_PARA:
						{
						setState(2022);
						para();
						}
						break;
					case CABECERA_MIENTRAS:
						{
						setState(2023);
						mientras();
						}
						break;
					case CABECERA_REPETIR:
						{
						setState(2024);
						repetir();
						}
						break;
					case CABECERA_SEGUN:
						{
						setState(2025);
						segun();
						}
						break;
					case CABECERA_DIMENSION:
						{
						setState(2026);
						dimension();
						}
						break;
					case INTRO:
						{
						setState(2027);
						match(INTRO);
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(2030); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,342,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			setState(2035);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==INTRO) {
				{
				{
				setState(2032);
				match(INTRO);
				}
				}
				setState(2037);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(2038);
			match(FIN_ALGORITMO);
			setState(2053);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,347,_ctx) ) {
			case 1:
				{
				setState(2040); 
				_errHandler.sync(this);
				_alt = 1;
				do {
					switch (_alt) {
					case 1:
						{
						{
						setState(2039);
						match(INTRO);
						}
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					setState(2042); 
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,344,_ctx);
				} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
				setState(2045);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,345,_ctx) ) {
				case 1:
					{
					setState(2044);
					comentario();
					}
					break;
				}
				setState(2050);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,346,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(2047);
						match(INTRO);
						}
						} 
					}
					setState(2052);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,346,_ctx);
				}
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\\\u080a\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t \4!"+
		"\t!\4\"\t\"\4#\t#\4$\t$\4%\t%\4&\t&\4\'\t\'\4(\t(\4)\t)\4*\t*\4+\t+\3"+
		"\2\3\2\3\2\3\2\6\2[\n\2\r\2\16\2\\\3\3\3\3\3\3\7\3b\n\3\f\3\16\3e\13\3"+
		"\3\3\3\3\3\3\7\3j\n\3\f\3\16\3m\13\3\3\3\5\3p\n\3\3\4\6\4s\n\4\r\4\16"+
		"\4t\3\4\6\4x\n\4\r\4\16\4y\5\4|\n\4\3\5\3\5\6\5\u0080\n\5\r\5\16\5\u0081"+
		"\3\5\3\5\7\5\u0086\n\5\f\5\16\5\u0089\13\5\3\5\5\5\u008c\n\5\3\5\6\5\u008f"+
		"\n\5\r\5\16\5\u0090\3\5\5\5\u0094\n\5\3\5\7\5\u0097\n\5\f\5\16\5\u009a"+
		"\13\5\3\6\3\6\6\6\u009e\n\6\r\6\16\6\u009f\3\6\3\6\6\6\u00a4\n\6\r\6\16"+
		"\6\u00a5\3\6\3\6\6\6\u00aa\n\6\r\6\16\6\u00ab\3\6\3\6\7\6\u00b0\n\6\f"+
		"\6\16\6\u00b3\13\6\3\6\5\6\u00b6\n\6\3\6\6\6\u00b9\n\6\r\6\16\6\u00ba"+
		"\3\6\5\6\u00be\n\6\3\6\7\6\u00c1\n\6\f\6\16\6\u00c4\13\6\3\7\3\7\6\7\u00c8"+
		"\n\7\r\7\16\7\u00c9\3\7\3\7\6\7\u00ce\n\7\r\7\16\7\u00cf\3\7\7\7\u00d3"+
		"\n\7\f\7\16\7\u00d6\13\7\3\7\3\7\7\7\u00da\n\7\f\7\16\7\u00dd\13\7\5\7"+
		"\u00df\n\7\3\7\7\7\u00e2\n\7\f\7\16\7\u00e5\13\7\3\7\3\7\6\7\u00e9\n\7"+
		"\r\7\16\7\u00ea\3\7\7\7\u00ee\n\7\f\7\16\7\u00f1\13\7\3\7\3\7\7\7\u00f5"+
		"\n\7\f\7\16\7\u00f8\13\7\5\7\u00fa\n\7\3\7\7\7\u00fd\n\7\f\7\16\7\u0100"+
		"\13\7\5\7\u0102\n\7\3\7\7\7\u0105\n\7\f\7\16\7\u0108\13\7\3\7\5\7\u010b"+
		"\n\7\3\7\6\7\u010e\n\7\r\7\16\7\u010f\3\7\5\7\u0113\n\7\3\7\7\7\u0116"+
		"\n\7\f\7\16\7\u0119\13\7\3\7\3\7\6\7\u011d\n\7\r\7\16\7\u011e\3\7\3\7"+
		"\3\7\7\7\u0124\n\7\f\7\16\7\u0127\13\7\3\7\3\7\7\7\u012b\n\7\f\7\16\7"+
		"\u012e\13\7\3\7\5\7\u0131\n\7\3\7\7\7\u0134\n\7\f\7\16\7\u0137\13\7\3"+
		"\7\3\7\7\7\u013b\n\7\f\7\16\7\u013e\13\7\3\7\3\7\7\7\u0142\n\7\f\7\16"+
		"\7\u0145\13\7\3\7\5\7\u0148\n\7\7\7\u014a\n\7\f\7\16\7\u014d\13\7\5\7"+
		"\u014f\n\7\3\7\7\7\u0152\n\7\f\7\16\7\u0155\13\7\3\7\5\7\u0158\n\7\3\7"+
		"\3\7\3\7\6\7\u015d\n\7\r\7\16\7\u015e\5\7\u0161\n\7\5\7\u0163\n\7\3\7"+
		"\3\7\6\7\u0167\n\7\r\7\16\7\u0168\3\7\7\7\u016c\n\7\f\7\16\7\u016f\13"+
		"\7\3\7\3\7\7\7\u0173\n\7\f\7\16\7\u0176\13\7\7\7\u0178\n\7\f\7\16\7\u017b"+
		"\13\7\5\7\u017d\n\7\3\7\7\7\u0180\n\7\f\7\16\7\u0183\13\7\3\7\3\7\7\7"+
		"\u0187\n\7\f\7\16\7\u018a\13\7\3\7\3\7\6\7\u018e\n\7\r\7\16\7\u018f\3"+
		"\7\7\7\u0193\n\7\f\7\16\7\u0196\13\7\3\7\3\7\7\7\u019a\n\7\f\7\16\7\u019d"+
		"\13\7\5\7\u019f\n\7\3\7\7\7\u01a2\n\7\f\7\16\7\u01a5\13\7\5\7\u01a7\n"+
		"\7\6\7\u01a9\n\7\r\7\16\7\u01aa\3\7\3\7\6\7\u01af\n\7\r\7\16\7\u01b0\3"+
		"\7\7\7\u01b4\n\7\f\7\16\7\u01b7\13\7\3\7\3\7\7\7\u01bb\n\7\f\7\16\7\u01be"+
		"\13\7\5\7\u01c0\n\7\3\7\3\7\5\7\u01c4\n\7\3\7\6\7\u01c7\n\7\r\7\16\7\u01c8"+
		"\3\7\7\7\u01cc\n\7\f\7\16\7\u01cf\13\7\3\7\3\7\7\7\u01d3\n\7\f\7\16\7"+
		"\u01d6\13\7\5\7\u01d8\n\7\3\7\5\7\u01db\n\7\6\7\u01dd\n\7\r\7\16\7\u01de"+
		"\5\7\u01e1\n\7\3\b\3\b\6\b\u01e5\n\b\r\b\16\b\u01e6\3\b\3\b\7\b\u01eb"+
		"\n\b\f\b\16\b\u01ee\13\b\3\b\3\b\7\b\u01f2\n\b\f\b\16\b\u01f5\13\b\3\b"+
		"\3\b\6\b\u01f9\n\b\r\b\16\b\u01fa\3\b\3\b\6\b\u01ff\n\b\r\b\16\b\u0200"+
		"\3\b\5\b\u0204\n\b\3\b\7\b\u0207\n\b\f\b\16\b\u020a\13\b\3\b\6\b\u020d"+
		"\n\b\r\b\16\b\u020e\3\b\7\b\u0212\n\b\f\b\16\b\u0215\13\b\3\b\3\b\6\b"+
		"\u0219\n\b\r\b\16\b\u021a\3\b\5\b\u021e\n\b\3\b\7\b\u0221\n\b\f\b\16\b"+
		"\u0224\13\b\3\b\6\b\u0227\n\b\r\b\16\b\u0228\3\b\7\b\u022c\n\b\f\b\16"+
		"\b\u022f\13\b\5\b\u0231\n\b\3\b\3\b\6\b\u0235\n\b\r\b\16\b\u0236\3\b\5"+
		"\b\u023a\n\b\3\b\7\b\u023d\n\b\f\b\16\b\u0240\13\b\5\b\u0242\n\b\3\t\3"+
		"\t\3\n\3\n\6\n\u0248\n\n\r\n\16\n\u0249\3\n\3\n\7\n\u024e\n\n\f\n\16\n"+
		"\u0251\13\n\3\n\3\n\6\n\u0255\n\n\r\n\16\n\u0256\3\n\3\n\6\n\u025b\n\n"+
		"\r\n\16\n\u025c\3\n\3\n\3\n\6\n\u0262\n\n\r\n\16\n\u0263\3\n\3\n\6\n\u0268"+
		"\n\n\r\n\16\n\u0269\3\n\3\n\6\n\u026e\n\n\r\n\16\n\u026f\3\n\5\n\u0273"+
		"\n\n\3\n\6\n\u0276\n\n\r\n\16\n\u0277\3\n\5\n\u027b\n\n\3\n\7\n\u027e"+
		"\n\n\f\n\16\n\u0281\13\n\3\n\6\n\u0284\n\n\r\n\16\n\u0285\3\n\7\n\u0289"+
		"\n\n\f\n\16\n\u028c\13\n\3\n\3\n\6\n\u0290\n\n\r\n\16\n\u0291\3\n\5\n"+
		"\u0295\n\n\3\n\7\n\u0298\n\n\f\n\16\n\u029b\13\n\5\n\u029d\n\n\3\13\3"+
		"\13\7\13\u02a1\n\13\f\13\16\13\u02a4\13\13\3\13\3\13\7\13\u02a8\n\13\f"+
		"\13\16\13\u02ab\13\13\3\13\5\13\u02ae\n\13\3\13\7\13\u02b1\n\13\f\13\16"+
		"\13\u02b4\13\13\3\13\3\13\3\13\7\13\u02b9\n\13\f\13\16\13\u02bc\13\13"+
		"\3\13\3\13\7\13\u02c0\n\13\f\13\16\13\u02c3\13\13\3\13\6\13\u02c6\n\13"+
		"\r\13\16\13\u02c7\3\13\3\13\7\13\u02cc\n\13\f\13\16\13\u02cf\13\13\3\13"+
		"\3\13\7\13\u02d3\n\13\f\13\16\13\u02d6\13\13\3\13\6\13\u02d9\n\13\r\13"+
		"\16\13\u02da\3\13\3\13\7\13\u02df\n\13\f\13\16\13\u02e2\13\13\3\13\3\13"+
		"\7\13\u02e6\n\13\f\13\16\13\u02e9\13\13\3\13\7\13\u02ec\n\13\f\13\16\13"+
		"\u02ef\13\13\3\13\3\13\7\13\u02f3\n\13\f\13\16\13\u02f6\13\13\3\13\3\13"+
		"\7\13\u02fa\n\13\f\13\16\13\u02fd\13\13\3\13\7\13\u0300\n\13\f\13\16\13"+
		"\u0303\13\13\3\13\5\13\u0306\n\13\3\13\7\13\u0309\n\13\f\13\16\13\u030c"+
		"\13\13\3\13\5\13\u030f\n\13\3\13\6\13\u0312\n\13\r\13\16\13\u0313\3\13"+
		"\5\13\u0317\n\13\3\13\7\13\u031a\n\13\f\13\16\13\u031d\13\13\5\13\u031f"+
		"\n\13\3\f\3\f\5\f\u0323\n\f\3\f\7\f\u0326\n\f\f\f\16\f\u0329\13\f\3\f"+
		"\3\f\7\f\u032d\n\f\f\f\16\f\u0330\13\f\5\f\u0332\n\f\3\f\7\f\u0335\n\f"+
		"\f\f\16\f\u0338\13\f\3\f\3\f\6\f\u033c\n\f\r\f\16\f\u033d\3\f\7\f\u0341"+
		"\n\f\f\f\16\f\u0344\13\f\3\f\3\f\7\f\u0348\n\f\f\f\16\f\u034b\13\f\5\f"+
		"\u034d\n\f\6\f\u034f\n\f\r\f\16\f\u0350\3\r\3\r\6\r\u0355\n\r\r\r\16\r"+
		"\u0356\3\r\3\r\6\r\u035b\n\r\r\r\16\r\u035c\3\r\3\r\6\r\u0361\n\r\r\r"+
		"\16\r\u0362\3\r\5\r\u0366\n\r\3\r\7\r\u0369\n\r\f\r\16\r\u036c\13\r\3"+
		"\r\3\r\7\r\u0370\n\r\f\r\16\r\u0373\13\r\7\r\u0375\n\r\f\r\16\r\u0378"+
		"\13\r\3\r\3\r\6\r\u037c\n\r\r\r\16\r\u037d\7\r\u0380\n\r\f\r\16\r\u0383"+
		"\13\r\3\r\3\r\6\r\u0387\n\r\r\r\16\r\u0388\3\r\5\r\u038c\n\r\3\r\7\r\u038f"+
		"\n\r\f\r\16\r\u0392\13\r\5\r\u0394\n\r\3\16\3\16\7\16\u0398\n\16\f\16"+
		"\16\16\u039b\13\16\3\16\3\16\7\16\u039f\n\16\f\16\16\16\u03a2\13\16\3"+
		"\16\3\16\3\17\3\17\7\17\u03a8\n\17\f\17\16\17\u03ab\13\17\3\17\3\17\7"+
		"\17\u03af\n\17\f\17\16\17\u03b2\13\17\3\17\3\17\7\17\u03b6\n\17\f\17\16"+
		"\17\u03b9\13\17\3\17\3\17\7\17\u03bd\n\17\f\17\16\17\u03c0\13\17\3\17"+
		"\6\17\u03c3\n\17\r\17\16\17\u03c4\3\20\3\20\6\20\u03c9\n\20\r\20\16\20"+
		"\u03ca\3\20\5\20\u03ce\n\20\3\20\7\20\u03d1\n\20\f\20\16\20\u03d4\13\20"+
		"\3\20\3\20\7\20\u03d8\n\20\f\20\16\20\u03db\13\20\6\20\u03dd\n\20\r\20"+
		"\16\20\u03de\3\20\3\20\6\20\u03e3\n\20\r\20\16\20\u03e4\3\20\3\20\6\20"+
		"\u03e9\n\20\r\20\16\20\u03ea\3\20\3\20\6\20\u03ef\n\20\r\20\16\20\u03f0"+
		"\3\20\5\20\u03f4\n\20\3\20\7\20\u03f7\n\20\f\20\16\20\u03fa\13\20\3\21"+
		"\3\21\6\21\u03fe\n\21\r\21\16\21\u03ff\3\21\3\21\6\21\u0404\n\21\r\21"+
		"\16\21\u0405\3\21\3\21\6\21\u040a\n\21\r\21\16\21\u040b\3\21\5\21\u040f"+
		"\n\21\3\21\7\21\u0412\n\21\f\21\16\21\u0415\13\21\3\21\3\21\7\21\u0419"+
		"\n\21\f\21\16\21\u041c\13\21\3\21\3\21\6\21\u0420\n\21\r\21\16\21\u0421"+
		"\3\21\5\21\u0425\n\21\3\21\7\21\u0428\n\21\f\21\16\21\u042b\13\21\3\21"+
		"\3\21\7\21\u042f\n\21\f\21\16\21\u0432\13\21\6\21\u0434\n\21\r\21\16\21"+
		"\u0435\7\21\u0438\n\21\f\21\16\21\u043b\13\21\3\21\3\21\6\21\u043f\n\21"+
		"\r\21\16\21\u0440\3\21\3\21\6\21\u0445\n\21\r\21\16\21\u0446\3\21\3\21"+
		"\7\21\u044b\n\21\f\21\16\21\u044e\13\21\3\21\3\21\6\21\u0452\n\21\r\21"+
		"\16\21\u0453\3\21\5\21\u0457\n\21\3\21\7\21\u045a\n\21\f\21\16\21\u045d"+
		"\13\21\3\21\3\21\7\21\u0461\n\21\f\21\16\21\u0464\13\21\3\21\3\21\6\21"+
		"\u0468\n\21\r\21\16\21\u0469\3\21\5\21\u046d\n\21\3\21\7\21\u0470\n\21"+
		"\f\21\16\21\u0473\13\21\5\21\u0475\n\21\3\22\3\22\6\22\u0479\n\22\r\22"+
		"\16\22\u047a\3\22\3\22\7\22\u047f\n\22\f\22\16\22\u0482\13\22\3\22\3\22"+
		"\7\22\u0486\n\22\f\22\16\22\u0489\13\22\3\22\3\22\7\22\u048d\n\22\f\22"+
		"\16\22\u0490\13\22\3\22\3\22\7\22\u0494\n\22\f\22\16\22\u0497\13\22\3"+
		"\22\7\22\u049a\n\22\f\22\16\22\u049d\13\22\3\22\7\22\u04a0\n\22\f\22\16"+
		"\22\u04a3\13\22\3\22\3\22\6\22\u04a7\n\22\r\22\16\22\u04a8\3\22\5\22\u04ac"+
		"\n\22\3\22\7\22\u04af\n\22\f\22\16\22\u04b2\13\22\5\22\u04b4\n\22\3\23"+
		"\3\23\3\23\3\23\3\23\3\23\3\23\3\23\3\23\3\23\5\23\u04c0\n\23\3\24\3\24"+
		"\6\24\u04c4\n\24\r\24\16\24\u04c5\3\24\3\24\7\24\u04ca\n\24\f\24\16\24"+
		"\u04cd\13\24\3\24\5\24\u04d0\n\24\3\24\7\24\u04d3\n\24\f\24\16\24\u04d6"+
		"\13\24\3\24\3\24\7\24\u04da\n\24\f\24\16\24\u04dd\13\24\3\24\3\24\7\24"+
		"\u04e1\n\24\f\24\16\24\u04e4\13\24\3\24\3\24\7\24\u04e8\n\24\f\24\16\24"+
		"\u04eb\13\24\3\24\5\24\u04ee\n\24\3\24\7\24\u04f1\n\24\f\24\16\24\u04f4"+
		"\13\24\3\24\3\24\7\24\u04f8\n\24\f\24\16\24\u04fb\13\24\3\24\3\24\7\24"+
		"\u04ff\n\24\f\24\16\24\u0502\13\24\3\24\5\24\u0505\n\24\7\24\u0507\n\24"+
		"\f\24\16\24\u050a\13\24\5\24\u050c\n\24\3\24\7\24\u050f\n\24\f\24\16\24"+
		"\u0512\13\24\3\24\5\24\u0515\n\24\3\24\6\24\u0518\n\24\r\24\16\24\u0519"+
		"\3\24\5\24\u051d\n\24\3\24\7\24\u0520\n\24\f\24\16\24\u0523\13\24\3\24"+
		"\3\24\7\24\u0527\n\24\f\24\16\24\u052a\13\24\7\24\u052c\n\24\f\24\16\24"+
		"\u052f\13\24\3\24\3\24\6\24\u0533\n\24\r\24\16\24\u0534\3\24\5\24\u0538"+
		"\n\24\3\24\7\24\u053b\n\24\f\24\16\24\u053e\13\24\5\24\u0540\n\24\3\25"+
		"\3\25\7\25\u0544\n\25\f\25\16\25\u0547\13\25\3\25\3\25\7\25\u054b\n\25"+
		"\f\25\16\25\u054e\13\25\3\25\3\25\7\25\u0552\n\25\f\25\16\25\u0555\13"+
		"\25\3\25\3\25\6\25\u0559\n\25\r\25\16\25\u055a\3\25\5\25\u055e\n\25\3"+
		"\25\7\25\u0561\n\25\f\25\16\25\u0564\13\25\3\26\3\26\7\26\u0568\n\26\f"+
		"\26\16\26\u056b\13\26\3\26\3\26\7\26\u056f\n\26\f\26\16\26\u0572\13\26"+
		"\3\26\3\26\7\26\u0576\n\26\f\26\16\26\u0579\13\26\3\26\3\26\7\26\u057d"+
		"\n\26\f\26\16\26\u0580\13\26\3\27\3\27\7\27\u0584\n\27\f\27\16\27\u0587"+
		"\13\27\3\27\3\27\7\27\u058b\n\27\f\27\16\27\u058e\13\27\3\27\3\27\7\27"+
		"\u0592\n\27\f\27\16\27\u0595\13\27\3\27\3\27\7\27\u0599\n\27\f\27\16\27"+
		"\u059c\13\27\3\30\3\30\7\30\u05a0\n\30\f\30\16\30\u05a3\13\30\3\30\3\30"+
		"\7\30\u05a7\n\30\f\30\16\30\u05aa\13\30\3\30\3\30\7\30\u05ae\n\30\f\30"+
		"\16\30\u05b1\13\30\3\30\3\30\7\30\u05b5\n\30\f\30\16\30\u05b8\13\30\3"+
		"\31\3\31\7\31\u05bc\n\31\f\31\16\31\u05bf\13\31\3\31\3\31\7\31\u05c3\n"+
		"\31\f\31\16\31\u05c6\13\31\3\31\3\31\7\31\u05ca\n\31\f\31\16\31\u05cd"+
		"\13\31\3\31\3\31\7\31\u05d1\n\31\f\31\16\31\u05d4\13\31\3\32\3\32\7\32"+
		"\u05d8\n\32\f\32\16\32\u05db\13\32\3\32\3\32\7\32\u05df\n\32\f\32\16\32"+
		"\u05e2\13\32\3\32\3\32\7\32\u05e6\n\32\f\32\16\32\u05e9\13\32\3\32\3\32"+
		"\7\32\u05ed\n\32\f\32\16\32\u05f0\13\32\3\33\3\33\7\33\u05f4\n\33\f\33"+
		"\16\33\u05f7\13\33\3\33\3\33\7\33\u05fb\n\33\f\33\16\33\u05fe\13\33\3"+
		"\33\3\33\7\33\u0602\n\33\f\33\16\33\u0605\13\33\3\33\3\33\7\33\u0609\n"+
		"\33\f\33\16\33\u060c\13\33\3\34\3\34\7\34\u0610\n\34\f\34\16\34\u0613"+
		"\13\34\3\34\3\34\7\34\u0617\n\34\f\34\16\34\u061a\13\34\3\34\3\34\7\34"+
		"\u061e\n\34\f\34\16\34\u0621\13\34\3\34\3\34\7\34\u0625\n\34\f\34\16\34"+
		"\u0628\13\34\3\35\3\35\7\35\u062c\n\35\f\35\16\35\u062f\13\35\3\35\3\35"+
		"\7\35\u0633\n\35\f\35\16\35\u0636\13\35\3\35\3\35\7\35\u063a\n\35\f\35"+
		"\16\35\u063d\13\35\3\35\3\35\7\35\u0641\n\35\f\35\16\35\u0644\13\35\3"+
		"\36\3\36\7\36\u0648\n\36\f\36\16\36\u064b\13\36\3\36\3\36\7\36\u064f\n"+
		"\36\f\36\16\36\u0652\13\36\3\36\3\36\7\36\u0656\n\36\f\36\16\36\u0659"+
		"\13\36\3\36\3\36\7\36\u065d\n\36\f\36\16\36\u0660\13\36\3\37\3\37\7\37"+
		"\u0664\n\37\f\37\16\37\u0667\13\37\3\37\3\37\7\37\u066b\n\37\f\37\16\37"+
		"\u066e\13\37\3\37\3\37\7\37\u0672\n\37\f\37\16\37\u0675\13\37\3\37\3\37"+
		"\7\37\u0679\n\37\f\37\16\37\u067c\13\37\3 \3 \7 \u0680\n \f \16 \u0683"+
		"\13 \3 \3 \7 \u0687\n \f \16 \u068a\13 \3 \3 \7 \u068e\n \f \16 \u0691"+
		"\13 \3 \3 \7 \u0695\n \f \16 \u0698\13 \3!\3!\7!\u069c\n!\f!\16!\u069f"+
		"\13!\3!\3!\7!\u06a3\n!\f!\16!\u06a6\13!\3!\3!\7!\u06aa\n!\f!\16!\u06ad"+
		"\13!\3!\3!\7!\u06b1\n!\f!\16!\u06b4\13!\3\"\3\"\3\"\3\"\3\"\3\"\3\"\3"+
		"\"\3\"\3\"\3\"\3\"\3\"\5\"\u06c3\n\"\3\"\7\"\u06c6\n\"\f\"\16\"\u06c9"+
		"\13\"\3\"\5\"\u06cc\n\"\3#\3#\7#\u06d0\n#\f#\16#\u06d3\13#\3#\3#\7#\u06d7"+
		"\n#\f#\16#\u06da\13#\3#\3#\7#\u06de\n#\f#\16#\u06e1\13#\3#\3#\7#\u06e5"+
		"\n#\f#\16#\u06e8\13#\3$\3$\7$\u06ec\n$\f$\16$\u06ef\13$\3$\3$\7$\u06f3"+
		"\n$\f$\16$\u06f6\13$\3$\3$\7$\u06fa\n$\f$\16$\u06fd\13$\3$\3$\7$\u0701"+
		"\n$\f$\16$\u0704\13$\3$\3$\7$\u0708\n$\f$\16$\u070b\13$\3$\3$\7$\u070f"+
		"\n$\f$\16$\u0712\13$\3$\3$\7$\u0716\n$\f$\16$\u0719\13$\3$\3$\7$\u071d"+
		"\n$\f$\16$\u0720\13$\3%\3%\7%\u0724\n%\f%\16%\u0727\13%\3%\3%\7%\u072b"+
		"\n%\f%\16%\u072e\13%\3%\3%\7%\u0732\n%\f%\16%\u0735\13%\3%\3%\7%\u0739"+
		"\n%\f%\16%\u073c\13%\3%\3%\7%\u0740\n%\f%\16%\u0743\13%\3%\3%\7%\u0747"+
		"\n%\f%\16%\u074a\13%\3&\3&\7&\u074e\n&\f&\16&\u0751\13&\3&\3&\7&\u0755"+
		"\n&\f&\16&\u0758\13&\3&\3&\7&\u075c\n&\f&\16&\u075f\13&\3&\3&\7&\u0763"+
		"\n&\f&\16&\u0766\13&\3\'\3\'\7\'\u076a\n\'\f\'\16\'\u076d\13\'\3\'\3\'"+
		"\7\'\u0771\n\'\f\'\16\'\u0774\13\'\3\'\3\'\7\'\u0778\n\'\f\'\16\'\u077b"+
		"\13\'\3\'\3\'\7\'\u077f\n\'\f\'\16\'\u0782\13\'\3(\3(\7(\u0786\n(\f(\16"+
		"(\u0789\13(\3(\3(\7(\u078d\n(\f(\16(\u0790\13(\3(\3(\7(\u0794\n(\f(\16"+
		"(\u0797\13(\3(\3(\7(\u079b\n(\f(\16(\u079e\13(\3)\3)\7)\u07a2\n)\f)\16"+
		")\u07a5\13)\3)\3)\7)\u07a9\n)\f)\16)\u07ac\13)\3)\3)\7)\u07b0\n)\f)\16"+
		")\u07b3\13)\3)\3)\7)\u07b7\n)\f)\16)\u07ba\13)\3*\3*\3*\3*\3*\3*\3*\5"+
		"*\u07c3\n*\3*\7*\u07c6\n*\f*\16*\u07c9\13*\3*\5*\u07cc\n*\3+\3+\6+\u07d0"+
		"\n+\r+\16+\u07d1\3+\3+\6+\u07d6\n+\r+\16+\u07d7\3+\5+\u07db\n+\3+\7+\u07de"+
		"\n+\f+\16+\u07e1\13+\3+\3+\3+\3+\3+\3+\3+\3+\3+\3+\3+\3+\6+\u07ef\n+\r"+
		"+\16+\u07f0\3+\7+\u07f4\n+\f+\16+\u07f7\13+\3+\3+\6+\u07fb\n+\r+\16+\u07fc"+
		"\3+\5+\u0800\n+\3+\7+\u0803\n+\f+\16+\u0806\13+\5+\u0808\n+\3+\2\2,\2"+
		"\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,.\60\62\64\668:<>@BDFHJL"+
		"NPRT\2\f\3\2\5\6\3\2TU\3\289\3\2\4\6\3\2TV\3\2\20\25\4\2\17\17\22\22\3"+
		"\2\6\7\3\2UV\4\2TTVV\2\u0966\2Z\3\2\2\2\4o\3\2\2\2\6{\3\2\2\2\b}\3\2\2"+
		"\2\n\u009b\3\2\2\2\f\u01e0\3\2\2\2\16\u01e2\3\2\2\2\20\u0243\3\2\2\2\22"+
		"\u0245\3\2\2\2\24\u029e\3\2\2\2\26\u034e\3\2\2\2\30\u0352\3\2\2\2\32\u0395"+
		"\3\2\2\2\34\u03a5\3\2\2\2\36\u03c6\3\2\2\2 \u03fb\3\2\2\2\"\u0476\3\2"+
		"\2\2$\u04bf\3\2\2\2&\u04c1\3\2\2\2(\u0541\3\2\2\2*\u0565\3\2\2\2,\u0581"+
		"\3\2\2\2.\u059d\3\2\2\2\60\u05b9\3\2\2\2\62\u05d5\3\2\2\2\64\u05f1\3\2"+
		"\2\2\66\u060d\3\2\2\28\u0629\3\2\2\2:\u0645\3\2\2\2<\u0661\3\2\2\2>\u067d"+
		"\3\2\2\2@\u0699\3\2\2\2B\u06c2\3\2\2\2D\u06cd\3\2\2\2F\u06e9\3\2\2\2H"+
		"\u0721\3\2\2\2J\u074b\3\2\2\2L\u0767\3\2\2\2N\u0783\3\2\2\2P\u079f\3\2"+
		"\2\2R\u07c2\3\2\2\2T\u07cd\3\2\2\2V[\5\4\3\2W[\5T+\2X[\5&\24\2Y[\7\3\2"+
		"\2ZV\3\2\2\2ZW\3\2\2\2ZX\3\2\2\2ZY\3\2\2\2[\\\3\2\2\2\\Z\3\2\2\2\\]\3"+
		"\2\2\2]\3\3\2\2\2^c\7\34\2\2_b\5\6\4\2`b\7\3\2\2a_\3\2\2\2a`\3\2\2\2b"+
		"e\3\2\2\2ca\3\2\2\2cd\3\2\2\2df\3\2\2\2ec\3\2\2\2fp\7Y\2\2gk\7\35\2\2"+
		"hj\5\6\4\2ih\3\2\2\2jm\3\2\2\2ki\3\2\2\2kl\3\2\2\2ln\3\2\2\2mk\3\2\2\2"+
		"np\7[\2\2o^\3\2\2\2og\3\2\2\2p\5\3\2\2\2qs\7Z\2\2rq\3\2\2\2st\3\2\2\2"+
		"tr\3\2\2\2tu\3\2\2\2u|\3\2\2\2vx\7\\\2\2wv\3\2\2\2xy\3\2\2\2yw\3\2\2\2"+
		"yz\3\2\2\2z|\3\2\2\2{r\3\2\2\2{w\3\2\2\2|\7\3\2\2\2}\177\7\"\2\2~\u0080"+
		"\7\4\2\2\177~\3\2\2\2\u0080\u0081\3\2\2\2\u0081\177\3\2\2\2\u0081\u0082"+
		"\3\2\2\2\u0082\u0083\3\2\2\2\u0083\u008b\7U\2\2\u0084\u0086\7\4\2\2\u0085"+
		"\u0084\3\2\2\2\u0086\u0089\3\2\2\2\u0087\u0085\3\2\2\2\u0087\u0088\3\2"+
		"\2\2\u0088\u008a\3\2\2\2\u0089\u0087\3\2\2\2\u008a\u008c\7\27\2\2\u008b"+
		"\u0087\3\2\2\2\u008b\u008c\3\2\2\2\u008c\u008e\3\2\2\2\u008d\u008f\7\3"+
		"\2\2\u008e\u008d\3\2\2\2\u008f\u0090\3\2\2\2\u0090\u008e\3\2\2\2\u0090"+
		"\u0091\3\2\2\2\u0091\u0093\3\2\2\2\u0092\u0094\5\4\3\2\u0093\u0092\3\2"+
		"\2\2\u0093\u0094\3\2\2\2\u0094\u0098\3\2\2\2\u0095\u0097\7\3\2\2\u0096"+
		"\u0095\3\2\2\2\u0097\u009a\3\2\2\2\u0098\u0096\3\2\2\2\u0098\u0099\3\2"+
		"\2\2\u0099\t\3\2\2\2\u009a\u0098\3\2\2\2\u009b\u009d\7\36\2\2\u009c\u009e"+
		"\7\4\2\2\u009d\u009c\3\2\2\2\u009e\u009f\3\2\2\2\u009f\u009d\3\2\2\2\u009f"+
		"\u00a0\3\2\2\2\u00a0\u00a1\3\2\2\2\u00a1\u00a3\7U\2\2\u00a2\u00a4\7\4"+
		"\2\2\u00a3\u00a2\3\2\2\2\u00a4\u00a5\3\2\2\2\u00a5\u00a3\3\2\2\2\u00a5"+
		"\u00a6\3\2\2\2\u00a6\u00a7\3\2\2\2\u00a7\u00a9\7\37\2\2\u00a8\u00aa\7"+
		"\4\2\2\u00a9\u00a8\3\2\2\2\u00aa\u00ab\3\2\2\2\u00ab\u00a9\3\2\2\2\u00ab"+
		"\u00ac\3\2\2\2\u00ac\u00ad\3\2\2\2\u00ad\u00b1\7 \2\2\u00ae\u00b0\7\4"+
		"\2\2\u00af\u00ae\3\2\2\2\u00b0\u00b3\3\2\2\2\u00b1\u00af\3\2\2\2\u00b1"+
		"\u00b2\3\2\2\2\u00b2\u00b5\3\2\2\2\u00b3\u00b1\3\2\2\2\u00b4\u00b6\7\27"+
		"\2\2\u00b5\u00b4\3\2\2\2\u00b5\u00b6\3\2\2\2\u00b6\u00b8\3\2\2\2\u00b7"+
		"\u00b9\7\3\2\2\u00b8\u00b7\3\2\2\2\u00b9\u00ba\3\2\2\2\u00ba\u00b8\3\2"+
		"\2\2\u00ba\u00bb\3\2\2\2\u00bb\u00bd\3\2\2\2\u00bc\u00be\5\4\3\2\u00bd"+
		"\u00bc\3\2\2\2\u00bd\u00be\3\2\2\2\u00be\u00c2\3\2\2\2\u00bf\u00c1\7\3"+
		"\2\2\u00c0\u00bf\3\2\2\2\u00c1\u00c4\3\2\2\2\u00c2\u00c0\3\2\2\2\u00c2"+
		"\u00c3\3\2\2\2\u00c3\13\3\2\2\2\u00c4\u00c2\3\2\2\2\u00c5\u00c7\7!\2\2"+
		"\u00c6\u00c8\7\4\2\2\u00c7\u00c6\3\2\2\2\u00c8\u00c9\3\2\2\2\u00c9\u00c7"+
		"\3\2\2\2\u00c9\u00ca\3\2\2\2\u00ca\u0101\3\2\2\2\u00cb\u00e3\7V\2\2\u00cc"+
		"\u00ce\7\4\2\2\u00cd\u00cc\3\2\2\2\u00ce\u00cf\3\2\2\2\u00cf\u00cd\3\2"+
		"\2\2\u00cf\u00d0\3\2\2\2\u00d0\u00df\3\2\2\2\u00d1\u00d3\7\4\2\2\u00d2"+
		"\u00d1\3\2\2\2\u00d3\u00d6\3\2\2\2\u00d4\u00d2\3\2\2\2\u00d4\u00d5\3\2"+
		"\2\2\u00d5\u00d7\3\2\2\2\u00d6\u00d4\3\2\2\2\u00d7\u00db\t\2\2\2\u00d8"+
		"\u00da\7\4\2\2\u00d9\u00d8\3\2\2\2\u00da\u00dd\3\2\2\2\u00db\u00d9\3\2"+
		"\2\2\u00db\u00dc\3\2\2\2\u00dc\u00df\3\2\2\2\u00dd\u00db\3\2\2\2\u00de"+
		"\u00cd\3\2\2\2\u00de\u00d4\3\2\2\2\u00df\u00e0\3\2\2\2\u00e0\u00e2\7V"+
		"\2\2\u00e1\u00de\3\2\2\2\u00e2\u00e5\3\2\2\2\u00e3\u00e1\3\2\2\2\u00e3"+
		"\u00e4\3\2\2\2\u00e4\u0102\3\2\2\2\u00e5\u00e3\3\2\2\2\u00e6\u00fe\7U"+
		"\2\2\u00e7\u00e9\7\4\2\2\u00e8\u00e7\3\2\2\2\u00e9\u00ea\3\2\2\2\u00ea"+
		"\u00e8\3\2\2\2\u00ea\u00eb\3\2\2\2\u00eb\u00fa\3\2\2\2\u00ec\u00ee\7\4"+
		"\2\2\u00ed\u00ec\3\2\2\2\u00ee\u00f1\3\2\2\2\u00ef\u00ed\3\2\2\2\u00ef"+
		"\u00f0\3\2\2\2\u00f0\u00f2\3\2\2\2\u00f1\u00ef\3\2\2\2\u00f2\u00f6\7\5"+
		"\2\2\u00f3\u00f5\7\4\2\2\u00f4\u00f3\3\2\2\2\u00f5\u00f8\3\2\2\2\u00f6"+
		"\u00f4\3\2\2\2\u00f6\u00f7\3\2\2\2\u00f7\u00fa\3\2\2\2\u00f8\u00f6\3\2"+
		"\2\2\u00f9\u00e8\3\2\2\2\u00f9\u00ef\3\2\2\2\u00fa\u00fb\3\2\2\2\u00fb"+
		"\u00fd\7U\2\2\u00fc\u00f9\3\2\2\2\u00fd\u0100\3\2\2\2\u00fe\u00fc\3\2"+
		"\2\2\u00fe\u00ff\3\2\2\2\u00ff\u0102\3\2\2\2\u0100\u00fe\3\2\2\2\u0101"+
		"\u00cb\3\2\2\2\u0101\u00e6\3\2\2\2\u0102\u010a\3\2\2\2\u0103\u0105\7\4"+
		"\2\2\u0104\u0103\3\2\2\2\u0105\u0108\3\2\2\2\u0106\u0104\3\2\2\2\u0106"+
		"\u0107\3\2\2\2\u0107\u0109\3\2\2\2\u0108\u0106\3\2\2\2\u0109\u010b\7\27"+
		"\2\2\u010a\u0106\3\2\2\2\u010a\u010b\3\2\2\2\u010b\u010d\3\2\2\2\u010c"+
		"\u010e\7\3\2\2\u010d\u010c\3\2\2\2\u010e\u010f\3\2\2\2\u010f\u010d\3\2"+
		"\2\2\u010f\u0110\3\2\2\2\u0110\u0112\3\2\2\2\u0111\u0113\5\4\3\2\u0112"+
		"\u0111\3\2\2\2\u0112\u0113\3\2\2\2\u0113\u0117\3\2\2\2\u0114\u0116\7\3"+
		"\2\2\u0115\u0114\3\2\2\2\u0116\u0119\3\2\2\2\u0117\u0115\3\2\2\2\u0117"+
		"\u0118\3\2\2\2\u0118\u01e1\3\2\2\2\u0119\u0117\3\2\2\2\u011a\u011c\7!"+
		"\2\2\u011b\u011d\7\4\2\2\u011c\u011b\3\2\2\2\u011d\u011e\3\2\2\2\u011e"+
		"\u011c\3\2\2\2\u011e\u011f\3\2\2\2\u011f\u01a8\3\2\2\2\u0120\u0157\7U"+
		"\2\2\u0121\u0125\7\32\2\2\u0122\u0124\7\4\2\2\u0123\u0122\3\2\2\2\u0124"+
		"\u0127\3\2\2\2\u0125\u0123\3\2\2\2\u0125\u0126\3\2\2\2\u0126\u014e\3\2"+
		"\2\2\u0127\u0125\3\2\2\2\u0128\u0130\t\3\2\2\u0129\u012b\7\4\2\2\u012a"+
		"\u0129\3\2\2\2\u012b\u012e\3\2\2\2\u012c\u012a\3\2\2\2\u012c\u012d\3\2"+
		"\2\2\u012d\u012f\3\2\2\2\u012e\u012c\3\2\2\2\u012f\u0131\t\4\2\2\u0130"+
		"\u012c\3\2\2\2\u0130\u0131\3\2\2\2\u0131\u014b\3\2\2\2\u0132\u0134\7\4"+
		"\2\2\u0133\u0132\3\2\2\2\u0134\u0137\3\2\2\2\u0135\u0133\3\2\2\2\u0135"+
		"\u0136\3\2\2\2\u0136\u0138\3\2\2\2\u0137\u0135\3\2\2\2\u0138\u013c\7\5"+
		"\2\2\u0139\u013b\7\4\2\2\u013a\u0139\3\2\2\2\u013b\u013e\3\2\2\2\u013c"+
		"\u013a\3\2\2\2\u013c\u013d\3\2\2\2\u013d\u013f\3\2\2\2\u013e\u013c\3\2"+
		"\2\2\u013f\u0147\t\3\2\2\u0140\u0142\7\4\2\2\u0141\u0140\3\2\2\2\u0142"+
		"\u0145\3\2\2\2\u0143\u0141\3\2\2\2\u0143\u0144\3\2\2\2\u0144\u0146\3\2"+
		"\2\2\u0145\u0143\3\2\2\2\u0146\u0148\t\4\2\2\u0147\u0143\3\2\2\2\u0147"+
		"\u0148\3\2\2\2\u0148\u014a\3\2\2\2\u0149\u0135\3\2\2\2\u014a\u014d\3\2"+
		"\2\2\u014b\u0149\3\2\2\2\u014b\u014c\3\2\2\2\u014c\u014f\3\2\2\2\u014d"+
		"\u014b\3\2\2\2\u014e\u0128\3\2\2\2\u014e\u014f\3\2\2\2\u014f\u0153\3\2"+
		"\2\2\u0150\u0152\7\4\2\2\u0151\u0150\3\2\2\2\u0152\u0155\3\2\2\2\u0153"+
		"\u0151\3\2\2\2\u0153\u0154\3\2\2\2\u0154\u0156\3\2\2\2\u0155\u0153\3\2"+
		"\2\2\u0156\u0158\7\33\2\2\u0157\u0121\3\2\2\2\u0157\u0158\3\2\2\2\u0158"+
		"\u0160\3\2\2\2\u0159\u0161\7\6\2\2\u015a\u0161\7\5\2\2\u015b\u015d\7\4"+
		"\2\2\u015c\u015b\3\2\2\2\u015d\u015e\3\2\2\2\u015e\u015c\3\2\2\2\u015e"+
		"\u015f\3\2\2\2\u015f\u0161\3\2\2\2\u0160\u0159\3\2\2\2\u0160\u015a\3\2"+
		"\2\2\u0160\u015c\3\2\2\2\u0161\u0163\3\2\2\2\u0162\u0120\3\2\2\2\u0162"+
		"\u0163\3\2\2\2\u0163\u017c\3\2\2\2\u0164\u0179\7V\2\2\u0165\u0167\7\4"+
		"\2\2\u0166\u0165\3\2\2\2\u0167\u0168\3\2\2\2\u0168\u0166\3\2\2\2\u0168"+
		"\u0169\3\2\2\2\u0169\u0178\3\2\2\2\u016a\u016c\7\4\2\2\u016b\u016a\3\2"+
		"\2\2\u016c\u016f\3\2\2\2\u016d\u016b\3\2\2\2\u016d\u016e\3\2\2\2\u016e"+
		"\u0170\3\2\2\2\u016f\u016d\3\2\2\2\u0170\u0174\t\2\2\2\u0171\u0173\7\4"+
		"\2\2\u0172\u0171\3\2\2\2\u0173\u0176\3\2\2\2\u0174\u0172\3\2\2\2\u0174"+
		"\u0175\3\2\2\2\u0175\u0178\3\2\2\2\u0176\u0174\3\2\2\2\u0177\u0166\3\2"+
		"\2\2\u0177\u016d\3\2\2\2\u0178\u017b\3\2\2\2\u0179\u0177\3\2\2\2\u0179"+
		"\u017a\3\2\2\2\u017a\u017d\3\2\2\2\u017b\u0179\3\2\2\2\u017c\u0164\3\2"+
		"\2\2\u017c\u017d\3\2\2\2\u017d\u0181\3\2\2\2\u017e\u0180\7\4\2\2\u017f"+
		"\u017e\3\2\2\2\u0180\u0183\3\2\2\2\u0181\u017f\3\2\2\2\u0181\u0182\3\2"+
		"\2\2\u0182\u0184\3\2\2\2\u0183\u0181\3\2\2\2\u0184\u0188\t\5\2\2\u0185"+
		"\u0187\7\4\2\2\u0186\u0185\3\2\2\2\u0187\u018a\3\2\2\2\u0188\u0186\3\2"+
		"\2\2\u0188\u0189\3\2\2\2\u0189\u01a6\3\2\2\2\u018a\u0188\3\2\2\2\u018b"+
		"\u01a3\7U\2\2\u018c\u018e\7\4\2\2\u018d\u018c\3\2\2\2\u018e\u018f\3\2"+
		"\2\2\u018f\u018d\3\2\2\2\u018f\u0190\3\2\2\2\u0190\u019f\3\2\2\2\u0191"+
		"\u0193\7\4\2\2\u0192\u0191\3\2\2\2\u0193\u0196\3\2\2\2\u0194\u0192\3\2"+
		"\2\2\u0194\u0195\3\2\2\2\u0195\u0197\3\2\2\2\u0196\u0194\3\2\2\2\u0197"+
		"\u019b\7\5\2\2\u0198\u019a\7\4\2\2\u0199\u0198\3\2\2\2\u019a\u019d\3\2"+
		"\2\2\u019b\u0199\3\2\2\2\u019b\u019c\3\2\2\2\u019c\u019f\3\2\2\2\u019d"+
		"\u019b\3\2\2\2\u019e\u018d\3\2\2\2\u019e\u0194\3\2\2\2\u019f\u01a0\3\2"+
		"\2\2\u01a0\u01a2\7U\2\2\u01a1\u019e\3\2\2\2\u01a2\u01a5\3\2\2\2\u01a3"+
		"\u01a1\3\2\2\2\u01a3\u01a4\3\2\2\2\u01a4\u01a7\3\2\2\2\u01a5\u01a3\3\2"+
		"\2\2\u01a6\u018b\3\2\2\2\u01a6\u01a7\3\2\2\2\u01a7\u01a9\3\2\2\2\u01a8"+
		"\u0162\3\2\2\2\u01a9\u01aa\3\2\2\2\u01aa\u01a8\3\2\2\2\u01aa\u01ab\3\2"+
		"\2\2\u01ab\u01e1\3\2\2\2\u01ac\u01dc\7!\2\2\u01ad\u01af\7\4\2\2\u01ae"+
		"\u01ad\3\2\2\2\u01af\u01b0\3\2\2\2\u01b0\u01ae\3\2\2\2\u01b0\u01b1\3\2"+
		"\2\2\u01b1\u01c0\3\2\2\2\u01b2\u01b4\7\4\2\2\u01b3\u01b2\3\2\2\2\u01b4"+
		"\u01b7\3\2\2\2\u01b5\u01b3\3\2\2\2\u01b5\u01b6\3\2\2\2\u01b6\u01b8\3\2"+
		"\2\2\u01b7\u01b5\3\2\2\2\u01b8\u01bc\7\5\2\2\u01b9\u01bb\7\4\2\2\u01ba"+
		"\u01b9\3\2\2\2\u01bb\u01be\3\2\2\2\u01bc\u01ba\3\2\2\2\u01bc\u01bd\3\2"+
		"\2\2\u01bd\u01c0\3\2\2\2\u01be\u01bc\3\2\2\2\u01bf\u01ae\3\2\2\2\u01bf"+
		"\u01b5\3\2\2\2\u01c0\u01c3\3\2\2\2\u01c1\u01c4\5B\"\2\u01c2\u01c4\5R*"+
		"\2\u01c3\u01c1\3\2\2\2\u01c3\u01c2\3\2\2\2\u01c4\u01dd\3\2\2\2\u01c5\u01c7"+
		"\7\4\2\2\u01c6\u01c5\3\2\2\2\u01c7\u01c8\3\2\2\2\u01c8\u01c6\3\2\2\2\u01c8"+
		"\u01c9\3\2\2\2\u01c9\u01d8\3\2\2\2\u01ca\u01cc\7\4\2\2\u01cb\u01ca\3\2"+
		"\2\2\u01cc\u01cf\3\2\2\2\u01cd\u01cb\3\2\2\2\u01cd\u01ce\3\2\2\2\u01ce"+
		"\u01d0\3\2\2\2\u01cf\u01cd\3\2\2\2\u01d0\u01d4\7\5\2\2\u01d1\u01d3\7\4"+
		"\2\2\u01d2\u01d1\3\2\2\2\u01d3\u01d6\3\2\2\2\u01d4\u01d2\3\2\2\2\u01d4"+
		"\u01d5\3\2\2\2\u01d5\u01d8\3\2\2\2\u01d6\u01d4\3\2\2\2\u01d7\u01c6\3\2"+
		"\2\2\u01d7\u01cd\3\2\2\2\u01d8\u01da\3\2\2\2\u01d9\u01db\t\6\2\2\u01da"+
		"\u01d9\3\2\2\2\u01da\u01db\3\2\2\2\u01db\u01dd\3\2\2\2\u01dc\u01bf\3\2"+
		"\2\2\u01dc\u01d7\3\2\2\2\u01dd\u01de\3\2\2\2\u01de\u01dc\3\2\2\2\u01de"+
		"\u01df\3\2\2\2\u01df\u01e1\3\2\2\2\u01e0\u00c5\3\2\2\2\u01e0\u011a\3\2"+
		"\2\2\u01e0\u01ac\3\2\2\2\u01e1\r\3\2\2\2\u01e2\u01e4\7#\2\2\u01e3\u01e5"+
		"\7\4\2\2\u01e4\u01e3\3\2\2\2\u01e5\u01e6\3\2\2\2\u01e6\u01e4\3\2\2\2\u01e6"+
		"\u01e7\3\2\2\2\u01e7\u01e8\3\2\2\2\u01e8\u01ec\t\6\2\2\u01e9\u01eb\7\4"+
		"\2\2\u01ea\u01e9\3\2\2\2\u01eb\u01ee\3\2\2\2\u01ec\u01ea\3\2\2\2\u01ec"+
		"\u01ed\3\2\2\2\u01ed\u01ef\3\2\2\2\u01ee\u01ec\3\2\2\2\u01ef\u01f3\5\20"+
		"\t\2\u01f0\u01f2\7\4\2\2\u01f1\u01f0\3\2\2\2\u01f2\u01f5\3\2\2\2\u01f3"+
		"\u01f1\3\2\2\2\u01f3\u01f4\3\2\2\2\u01f4\u01f6\3\2\2\2\u01f5\u01f3\3\2"+
		"\2\2\u01f6\u01f8\t\6\2\2\u01f7\u01f9\7\4\2\2\u01f8\u01f7\3\2\2\2\u01f9"+
		"\u01fa\3\2\2\2\u01fa\u01f8\3\2\2\2\u01fa\u01fb\3\2\2\2\u01fb\u01fc\3\2"+
		"\2\2\u01fc\u01fe\7$\2\2\u01fd\u01ff\7\3\2\2\u01fe\u01fd\3\2\2\2\u01ff"+
		"\u0200\3\2\2\2\u0200\u01fe\3\2\2\2\u0200\u0201\3\2\2\2\u0201\u0203\3\2"+
		"\2\2\u0202\u0204\5\4\3\2\u0203\u0202\3\2\2\2\u0203\u0204\3\2\2\2\u0204"+
		"\u0208\3\2\2\2\u0205\u0207\7\3\2\2\u0206\u0205\3\2\2\2\u0207\u020a\3\2"+
		"\2\2\u0208\u0206\3\2\2\2\u0208\u0209\3\2\2\2\u0209\u020c\3\2\2\2\u020a"+
		"\u0208\3\2\2\2\u020b\u020d\5$\23\2\u020c\u020b\3\2\2\2\u020d\u020e\3\2"+
		"\2\2\u020e\u020c\3\2\2\2\u020e\u020f\3\2\2\2\u020f\u0213\3\2\2\2\u0210"+
		"\u0212\7\3\2\2\u0211\u0210\3\2\2\2\u0212\u0215\3\2\2\2\u0213\u0211\3\2"+
		"\2\2\u0213\u0214\3\2\2\2\u0214\u0230\3\2\2\2\u0215\u0213\3\2\2\2\u0216"+
		"\u0218\7%\2\2\u0217\u0219\7\3\2\2\u0218\u0217\3\2\2\2\u0219\u021a\3\2"+
		"\2\2\u021a\u0218\3\2\2\2\u021a\u021b\3\2\2\2\u021b\u021d\3\2\2\2\u021c"+
		"\u021e\5\4\3\2\u021d\u021c\3\2\2\2\u021d\u021e\3\2\2\2\u021e\u0222\3\2"+
		"\2\2\u021f\u0221\7\3\2\2\u0220\u021f\3\2\2\2\u0221\u0224\3\2\2\2\u0222"+
		"\u0220\3\2\2\2\u0222\u0223\3\2\2\2\u0223\u0226\3\2\2\2\u0224\u0222\3\2"+
		"\2\2\u0225\u0227\5$\23\2\u0226\u0225\3\2\2\2\u0227\u0228\3\2\2\2\u0228"+
		"\u0226\3\2\2\2\u0228\u0229\3\2\2\2\u0229\u022d\3\2\2\2\u022a\u022c\7\3"+
		"\2\2\u022b\u022a\3\2\2\2\u022c\u022f\3\2\2\2\u022d\u022b\3\2\2\2\u022d"+
		"\u022e\3\2\2\2\u022e\u0231\3\2\2\2\u022f\u022d\3\2\2\2\u0230\u0216\3\2"+
		"\2\2\u0230\u0231\3\2\2\2\u0231\u0232\3\2\2\2\u0232\u0241\7&\2\2\u0233"+
		"\u0235\7\3\2\2\u0234\u0233\3\2\2\2\u0235\u0236\3\2\2\2\u0236\u0234\3\2"+
		"\2\2\u0236\u0237\3\2\2\2\u0237\u0239\3\2\2\2\u0238\u023a\5\4\3\2\u0239"+
		"\u0238\3\2\2\2\u0239\u023a\3\2\2\2\u023a\u023e\3\2\2\2\u023b\u023d\7\3"+
		"\2\2\u023c\u023b\3\2\2\2\u023d\u0240\3\2\2\2\u023e\u023c\3\2\2\2\u023e"+
		"\u023f\3\2\2\2\u023f\u0242\3\2\2\2\u0240\u023e\3\2\2\2\u0241\u0234\3\2"+
		"\2\2\u0241\u0242\3\2\2\2\u0242\17\3\2\2\2\u0243\u0244\t\7\2\2\u0244\21"+
		"\3\2\2\2\u0245\u0247\7\'\2\2\u0246\u0248\7\4\2\2\u0247\u0246\3\2\2\2\u0248"+
		"\u0249\3\2\2\2\u0249\u0247\3\2\2\2\u0249\u024a\3\2\2\2\u024a\u024b\3\2"+
		"\2\2\u024b\u024f\5\24\13\2\u024c\u024e\7\4\2\2\u024d\u024c\3\2\2\2\u024e"+
		"\u0251\3\2\2\2\u024f\u024d\3\2\2\2\u024f\u0250\3\2\2\2\u0250\u0252\3\2"+
		"\2\2\u0251\u024f\3\2\2\2\u0252\u0254\7(\2\2\u0253\u0255\7\4\2\2\u0254"+
		"\u0253\3\2\2\2\u0255\u0256\3\2\2\2\u0256\u0254\3\2\2\2\u0256\u0257\3\2"+
		"\2\2\u0257\u0258\3\2\2\2\u0258\u025a\7T\2\2\u0259\u025b\7\4\2\2\u025a"+
		"\u0259\3\2\2\2\u025b\u025c\3\2\2\2\u025c\u025a\3\2\2\2\u025c\u025d\3\2"+
		"\2\2\u025d\u0272\3\2\2\2\u025e\u0273\7)\2\2\u025f\u0261\7*\2\2\u0260\u0262"+
		"\7\4\2\2\u0261\u0260\3\2\2\2\u0262\u0263\3\2\2\2\u0263\u0261\3\2\2\2\u0263"+
		"\u0264\3\2\2\2\u0264\u0265\3\2\2\2\u0265\u0267\7+\2\2\u0266\u0268\7\4"+
		"\2\2\u0267\u0266\3\2\2\2\u0268\u0269\3\2\2\2\u0269\u0267\3\2\2\2\u0269"+
		"\u026a\3\2\2\2\u026a\u026b\3\2\2\2\u026b\u026d\7,\2\2\u026c\u026e\7\4"+
		"\2\2\u026d\u026c\3\2\2\2\u026e\u026f\3\2\2\2\u026f\u026d\3\2\2\2\u026f"+
		"\u0270\3\2\2\2\u0270\u0271\3\2\2\2\u0271\u0273\7)\2\2\u0272\u025e\3\2"+
		"\2\2\u0272\u025f\3\2\2\2\u0273\u0275\3\2\2\2\u0274\u0276\7\3\2\2\u0275"+
		"\u0274\3\2\2\2\u0276\u0277\3\2\2\2\u0277\u0275\3\2\2\2\u0277\u0278\3\2"+
		"\2\2\u0278\u027a\3\2\2\2\u0279\u027b\5\4\3\2\u027a\u0279\3\2\2\2\u027a"+
		"\u027b\3\2\2\2\u027b\u027f\3\2\2\2\u027c\u027e\7\3\2\2\u027d\u027c\3\2"+
		"\2\2\u027e\u0281\3\2\2\2\u027f\u027d\3\2\2\2\u027f\u0280\3\2\2\2\u0280"+
		"\u0283\3\2\2\2\u0281\u027f\3\2\2\2\u0282\u0284\5$\23\2\u0283\u0282\3\2"+
		"\2\2\u0284\u0285\3\2\2\2\u0285\u0283\3\2\2\2\u0285\u0286\3\2\2\2\u0286"+
		"\u028a\3\2\2\2\u0287\u0289\7\3\2\2\u0288\u0287\3\2\2\2\u0289\u028c\3\2"+
		"\2\2\u028a\u0288\3\2\2\2\u028a\u028b\3\2\2\2\u028b\u028d\3\2\2\2\u028c"+
		"\u028a\3\2\2\2\u028d\u029c\7-\2\2\u028e\u0290\7\3\2\2\u028f\u028e\3\2"+
		"\2\2\u0290\u0291\3\2\2\2\u0291\u028f\3\2\2\2\u0291\u0292\3\2\2\2\u0292"+
		"\u0294\3\2\2\2\u0293\u0295\5\4\3\2\u0294\u0293\3\2\2\2\u0294\u0295\3\2"+
		"\2\2\u0295\u0299\3\2\2\2\u0296\u0298\7\3\2\2\u0297\u0296\3\2\2\2\u0298"+
		"\u029b\3\2\2\2\u0299\u0297\3\2\2\2\u0299\u029a\3\2\2\2\u029a\u029d\3\2"+
		"\2\2\u029b\u0299\3\2\2\2\u029c\u028f\3\2\2\2\u029c\u029d\3\2\2\2\u029d"+
		"\23\3\2\2\2\u029e\u02a2\7U\2\2\u029f\u02a1\7\4\2\2\u02a0\u029f\3\2\2\2"+
		"\u02a1\u02a4\3\2\2\2\u02a2\u02a0\3\2\2\2\u02a2\u02a3\3\2\2\2\u02a3\u02a5"+
		"\3\2\2\2\u02a4\u02a2\3\2\2\2\u02a5\u02a9\t\b\2\2\u02a6\u02a8\7\4\2\2\u02a7"+
		"\u02a6\3\2\2\2\u02a8\u02ab\3\2\2\2\u02a9\u02a7\3\2\2\2\u02a9\u02aa\3\2"+
		"\2\2\u02aa\u02ad\3\2\2\2\u02ab\u02a9\3\2\2\2\u02ac\u02ae\7\32\2\2\u02ad"+
		"\u02ac\3\2\2\2\u02ad\u02ae\3\2\2\2\u02ae\u02b2\3\2\2\2\u02af\u02b1\7\4"+
		"\2\2\u02b0\u02af\3\2\2\2\u02b1\u02b4\3\2\2\2\u02b2\u02b0\3\2\2\2\u02b2"+
		"\u02b3\3\2\2\2\u02b3\u0305\3\2\2\2\u02b4\u02b2\3\2\2\2\u02b5\u0306\7U"+
		"\2\2\u02b6\u02ba\7U\2\2\u02b7\u02b9\7\4\2\2\u02b8\u02b7\3\2\2\2\u02b9"+
		"\u02bc\3\2\2\2\u02ba\u02b8\3\2\2\2\u02ba\u02bb\3\2\2\2\u02bb\u02c5\3\2"+
		"\2\2\u02bc\u02ba\3\2\2\2\u02bd\u02c1\t\t\2\2\u02be\u02c0\7\4\2\2\u02bf"+
		"\u02be\3\2\2\2\u02c0\u02c3\3\2\2\2\u02c1\u02bf\3\2\2\2\u02c1\u02c2\3\2"+
		"\2\2\u02c2\u02c4\3\2\2\2\u02c3\u02c1\3\2\2\2\u02c4\u02c6\7T\2\2\u02c5"+
		"\u02bd\3\2\2\2\u02c6\u02c7\3\2\2\2\u02c7\u02c5\3\2\2\2\u02c7\u02c8\3\2"+
		"\2\2\u02c8\u0306\3\2\2\2\u02c9\u02cd\7U\2\2\u02ca\u02cc\7\4\2\2\u02cb"+
		"\u02ca\3\2\2\2\u02cc\u02cf\3\2\2\2\u02cd\u02cb\3\2\2\2\u02cd\u02ce\3\2"+
		"\2\2\u02ce\u02d8\3\2\2\2\u02cf\u02cd\3\2\2\2\u02d0\u02d4\7\6\2\2\u02d1"+
		"\u02d3\7\4\2\2\u02d2\u02d1\3\2\2\2\u02d3\u02d6\3\2\2\2\u02d4\u02d2\3\2"+
		"\2\2\u02d4\u02d5\3\2\2\2\u02d5\u02d7\3\2\2\2\u02d6\u02d4\3\2\2\2\u02d7"+
		"\u02d9\t\n\2\2\u02d8\u02d0\3\2\2\2\u02d9\u02da\3\2\2\2\u02da\u02d8\3\2"+
		"\2\2\u02da\u02db\3\2\2\2\u02db\u0306\3\2\2\2\u02dc\u02e0\7T\2\2\u02dd"+
		"\u02df\7\4\2\2\u02de\u02dd\3\2\2\2\u02df\u02e2\3\2\2\2\u02e0\u02de\3\2"+
		"\2\2\u02e0\u02e1\3\2\2\2\u02e1\u02ed\3\2\2\2\u02e2\u02e0\3\2\2\2\u02e3"+
		"\u02e7\t\t\2\2\u02e4\u02e6\7\4\2\2\u02e5\u02e4\3\2\2\2\u02e6\u02e9\3\2"+
		"\2\2\u02e7\u02e5\3\2\2\2\u02e7\u02e8\3\2\2\2\u02e8\u02ea\3\2\2\2\u02e9"+
		"\u02e7\3\2\2\2\u02ea\u02ec\7T\2\2\u02eb\u02e3\3\2\2\2\u02ec\u02ef\3\2"+
		"\2\2\u02ed\u02eb\3\2\2\2\u02ed\u02ee\3\2\2\2\u02ee\u0306\3\2\2\2\u02ef"+
		"\u02ed\3\2\2\2\u02f0\u02f4\7V\2\2\u02f1\u02f3\7\4\2\2\u02f2\u02f1\3\2"+
		"\2\2\u02f3\u02f6\3\2\2\2\u02f4\u02f2\3\2\2\2\u02f4\u02f5\3\2\2\2\u02f5"+
		"\u0301\3\2\2\2\u02f6\u02f4\3\2\2\2\u02f7\u02fb\7\6\2\2\u02f8\u02fa\7\4"+
		"\2\2\u02f9\u02f8\3\2\2\2\u02fa\u02fd\3\2\2\2\u02fb\u02f9\3\2\2\2\u02fb"+
		"\u02fc\3\2\2\2\u02fc\u02fe\3\2\2\2\u02fd\u02fb\3\2\2\2\u02fe\u0300\7V"+
		"\2\2\u02ff\u02f7\3\2\2\2\u0300\u0303\3\2\2\2\u0301\u02ff\3\2\2\2\u0301"+
		"\u0302\3\2\2\2\u0302\u0306\3\2\2\2\u0303\u0301\3\2\2\2\u0304\u0306\5\26"+
		"\f\2\u0305\u02b5\3\2\2\2\u0305\u02b6\3\2\2\2\u0305\u02c9\3\2\2\2\u0305"+
		"\u02dc\3\2\2\2\u0305\u02f0\3\2\2\2\u0305\u0304\3\2\2\2\u0306\u030a\3\2"+
		"\2\2\u0307\u0309\7\4\2\2\u0308\u0307\3\2\2\2\u0309\u030c\3\2\2\2\u030a"+
		"\u0308\3\2\2\2\u030a\u030b\3\2\2\2\u030b\u030e\3\2\2\2\u030c\u030a\3\2"+
		"\2\2\u030d\u030f\7\33\2\2\u030e\u030d\3\2\2\2\u030e\u030f\3\2\2\2\u030f"+
		"\u031e\3\2\2\2\u0310\u0312\7\3\2\2\u0311\u0310\3\2\2\2\u0312\u0313\3\2"+
		"\2\2\u0313\u0311\3\2\2\2\u0313\u0314\3\2\2\2\u0314\u0316\3\2\2\2\u0315"+
		"\u0317\5\4\3\2\u0316\u0315\3\2\2\2\u0316\u0317\3\2\2\2\u0317\u031b\3\2"+
		"\2\2\u0318\u031a\7\3\2\2\u0319\u0318\3\2\2\2\u031a\u031d\3\2\2\2\u031b"+
		"\u0319\3\2\2\2\u031b\u031c\3\2\2\2\u031c\u031f\3\2\2\2\u031d\u031b\3\2"+
		"\2\2\u031e\u0311\3\2\2\2\u031e\u031f\3\2\2\2\u031f\25\3\2\2\2\u0320\u0323"+
		"\5R*\2\u0321\u0323\5B\"\2\u0322\u0320\3\2\2\2\u0322\u0321\3\2\2\2\u0323"+
		"\u0331\3\2\2\2\u0324\u0326\7\4\2\2\u0325\u0324\3\2\2\2\u0326\u0329\3\2"+
		"\2\2\u0327\u0325\3\2\2\2\u0327\u0328\3\2\2\2\u0328\u032a\3\2\2\2\u0329"+
		"\u0327\3\2\2\2\u032a\u032e\7\6\2\2\u032b\u032d\7\4\2\2\u032c\u032b\3\2"+
		"\2\2\u032d\u0330\3\2\2\2\u032e\u032c\3\2\2\2\u032e\u032f\3\2\2\2\u032f"+
		"\u0332\3\2\2\2\u0330\u032e\3\2\2\2\u0331\u0327\3\2\2\2\u0331\u0332\3\2"+
		"\2\2\u0332\u034f\3\2\2\2\u0333\u0335\7\4\2\2\u0334\u0333\3\2\2\2\u0335"+
		"\u0338\3\2\2\2\u0336\u0334\3\2\2\2\u0336\u0337\3\2\2\2\u0337\u0339\3\2"+
		"\2\2\u0338\u0336\3\2\2\2\u0339\u034c\t\3\2\2\u033a\u033c\7\4\2\2\u033b"+
		"\u033a\3\2\2\2\u033c\u033d\3\2\2\2\u033d\u033b\3\2\2\2\u033d\u033e\3\2"+
		"\2\2\u033e\u034d\3\2\2\2\u033f\u0341\7\4\2\2\u0340\u033f\3\2\2\2\u0341"+
		"\u0344\3\2\2\2\u0342\u0340\3\2\2\2\u0342\u0343\3\2\2\2\u0343\u0345\3\2"+
		"\2\2\u0344\u0342\3\2\2\2\u0345\u0349\7\6\2\2\u0346\u0348\7\4\2\2\u0347"+
		"\u0346\3\2\2\2\u0348\u034b\3\2\2\2\u0349\u0347\3\2\2\2\u0349\u034a\3\2"+
		"\2\2\u034a\u034d\3\2\2\2\u034b\u0349\3\2\2\2\u034c\u033b\3\2\2\2\u034c"+
		"\u0342\3\2\2\2\u034c\u034d\3\2\2\2\u034d\u034f\3\2\2\2\u034e\u0322\3\2"+
		"\2\2\u034e\u0336\3\2\2\2\u034f\u0350\3\2\2\2\u0350\u034e\3\2\2\2\u0350"+
		"\u0351\3\2\2\2\u0351\27\3\2\2\2\u0352\u0354\7.\2\2\u0353\u0355\7\4\2\2"+
		"\u0354\u0353\3\2\2\2\u0355\u0356\3\2\2\2\u0356\u0354\3\2\2\2\u0356\u0357"+
		"\3\2\2\2\u0357\u0358\3\2\2\2\u0358\u035a\5\32\16\2\u0359\u035b\7\4\2\2"+
		"\u035a\u0359\3\2\2\2\u035b\u035c\3\2\2\2\u035c\u035a\3\2\2\2\u035c\u035d"+
		"\3\2\2\2\u035d\u035e\3\2\2\2\u035e\u0360\7)\2\2\u035f\u0361\7\3\2\2\u0360"+
		"\u035f\3\2\2\2\u0361\u0362\3\2\2\2\u0362\u0360\3\2\2\2\u0362\u0363\3\2"+
		"\2\2\u0363\u0365\3\2\2\2\u0364\u0366\5\4\3\2\u0365\u0364\3\2\2\2\u0365"+
		"\u0366\3\2\2\2\u0366\u036a\3\2\2\2\u0367\u0369\7\3\2\2\u0368\u0367\3\2"+
		"\2\2\u0369\u036c\3\2\2\2\u036a\u0368\3\2\2\2\u036a\u036b\3\2\2\2\u036b"+
		"\u0376\3\2\2\2\u036c\u036a\3\2\2\2\u036d\u0371\5$\23\2\u036e\u0370\7\3"+
		"\2\2\u036f\u036e\3\2\2\2\u0370\u0373\3\2\2\2\u0371\u036f\3\2\2\2\u0371"+
		"\u0372\3\2\2\2\u0372\u0375\3\2\2\2\u0373\u0371\3\2\2\2\u0374\u036d\3\2"+
		"\2\2\u0375\u0378\3\2\2\2\u0376\u0374\3\2\2\2\u0376\u0377\3\2\2\2\u0377"+
		"\u0381\3\2\2\2\u0378\u0376\3\2\2\2\u0379\u037b\5\34\17\2\u037a\u037c\7"+
		"\3\2\2\u037b\u037a\3\2\2\2\u037c\u037d\3\2\2\2\u037d\u037b\3\2\2\2\u037d"+
		"\u037e\3\2\2\2\u037e\u0380\3\2\2\2\u037f\u0379\3\2\2\2\u0380\u0383\3\2"+
		"\2\2\u0381\u037f\3\2\2\2\u0381\u0382\3\2\2\2\u0382\u0384\3\2\2\2\u0383"+
		"\u0381\3\2\2\2\u0384\u0393\7/\2\2\u0385\u0387\7\3\2\2\u0386\u0385\3\2"+
		"\2\2\u0387\u0388\3\2\2\2\u0388\u0386\3\2\2\2\u0388\u0389\3\2\2\2\u0389"+
		"\u038b\3\2\2\2\u038a\u038c\5\4\3\2\u038b\u038a\3\2\2\2\u038b\u038c\3\2"+
		"\2\2\u038c\u0390\3\2\2\2\u038d\u038f\7\3\2\2\u038e\u038d\3\2\2\2\u038f"+
		"\u0392\3\2\2\2\u0390\u038e\3\2\2\2\u0390\u0391\3\2\2\2\u0391\u0394\3\2"+
		"\2\2\u0392\u0390\3\2\2\2\u0393\u0386\3\2\2\2\u0393\u0394\3\2\2\2\u0394"+
		"\31\3\2\2\2\u0395\u0399\7U\2\2\u0396\u0398\7\4\2\2\u0397\u0396\3\2\2\2"+
		"\u0398\u039b\3\2\2\2\u0399\u0397\3\2\2\2\u0399\u039a\3\2\2\2\u039a\u039c"+
		"\3\2\2\2\u039b\u0399\3\2\2\2\u039c\u03a0\5\20\t\2\u039d\u039f\7\4\2\2"+
		"\u039e\u039d\3\2\2\2\u039f\u03a2\3\2\2\2\u03a0\u039e\3\2\2\2\u03a0\u03a1"+
		"\3\2\2\2\u03a1\u03a3\3\2\2\2\u03a2\u03a0\3\2\2\2\u03a3\u03a4\t\3\2\2\u03a4"+
		"\33\3\2\2\2\u03a5\u03a9\7U\2\2\u03a6\u03a8\7\4\2\2\u03a7\u03a6\3\2\2\2"+
		"\u03a8\u03ab\3\2\2\2\u03a9\u03a7\3\2\2\2\u03a9\u03aa\3\2\2\2\u03aa\u03ac"+
		"\3\2\2\2\u03ab\u03a9\3\2\2\2\u03ac\u03b0\7\17\2\2\u03ad\u03af\7\4\2\2"+
		"\u03ae\u03ad\3\2\2\2\u03af\u03b2\3\2\2\2\u03b0\u03ae\3\2\2\2\u03b0\u03b1"+
		"\3\2\2\2\u03b1\u03b3\3\2\2\2\u03b2\u03b0\3\2\2\2\u03b3\u03b7\7U\2\2\u03b4"+
		"\u03b6\7\4\2\2\u03b5\u03b4\3\2\2\2\u03b6\u03b9\3\2\2\2\u03b7\u03b5\3\2"+
		"\2\2\u03b7\u03b8\3\2\2\2\u03b8\u03c2\3\2\2\2\u03b9\u03b7\3\2\2\2\u03ba"+
		"\u03be\t\t\2\2\u03bb\u03bd\7\4\2\2\u03bc\u03bb\3\2\2\2\u03bd\u03c0\3\2"+
		"\2\2\u03be\u03bc\3\2\2\2\u03be\u03bf\3\2\2\2\u03bf\u03c1\3\2\2\2\u03c0"+
		"\u03be\3\2\2\2\u03c1\u03c3\7T\2\2\u03c2\u03ba\3\2\2\2\u03c3\u03c4\3\2"+
		"\2\2\u03c4\u03c2\3\2\2\2\u03c4\u03c5\3\2\2\2\u03c5\35\3\2\2\2\u03c6\u03c8"+
		"\7\60\2\2\u03c7\u03c9\7\3\2\2\u03c8\u03c7\3\2\2\2\u03c9\u03ca\3\2\2\2"+
		"\u03ca\u03c8\3\2\2\2\u03ca\u03cb\3\2\2\2\u03cb\u03cd\3\2\2\2\u03cc\u03ce"+
		"\5\4\3\2\u03cd\u03cc\3\2\2\2\u03cd\u03ce\3\2\2\2\u03ce\u03d2\3\2\2\2\u03cf"+
		"\u03d1\7\3\2\2\u03d0\u03cf\3\2\2\2\u03d1\u03d4\3\2\2\2\u03d2\u03d0\3\2"+
		"\2\2\u03d2\u03d3\3\2\2\2\u03d3\u03dc\3\2\2\2\u03d4\u03d2\3\2\2\2\u03d5"+
		"\u03d9\5$\23\2\u03d6\u03d8\7\3\2\2\u03d7\u03d6\3\2\2\2\u03d8\u03db\3\2"+
		"\2\2\u03d9\u03d7\3\2\2\2\u03d9\u03da\3\2\2\2\u03da\u03dd\3\2\2\2\u03db"+
		"\u03d9\3\2\2\2\u03dc\u03d5\3\2\2\2\u03dd\u03de\3\2\2\2\u03de\u03dc\3\2"+
		"\2\2\u03de\u03df\3\2\2\2\u03df\u03e0\3\2\2\2\u03e0\u03e2\7(\2\2\u03e1"+
		"\u03e3\7\4\2\2\u03e2\u03e1\3\2\2\2\u03e3\u03e4\3\2\2\2\u03e4\u03e2\3\2"+
		"\2\2\u03e4\u03e5\3\2\2\2\u03e5\u03e6\3\2\2\2\u03e6\u03e8\7\61\2\2\u03e7"+
		"\u03e9\7\4\2\2\u03e8\u03e7\3\2\2\2\u03e9\u03ea\3\2\2\2\u03ea\u03e8\3\2"+
		"\2\2\u03ea\u03eb\3\2\2\2\u03eb\u03ec\3\2\2\2\u03ec\u03ee\5\32\16\2\u03ed"+
		"\u03ef\7\3\2\2\u03ee\u03ed\3\2\2\2\u03ef\u03f0\3\2\2\2\u03f0\u03ee\3\2"+
		"\2\2\u03f0\u03f1\3\2\2\2\u03f1\u03f3\3\2\2\2\u03f2\u03f4\5\4\3\2\u03f3"+
		"\u03f2\3\2\2\2\u03f3\u03f4\3\2\2\2\u03f4\u03f8\3\2\2\2\u03f5\u03f7\7\3"+
		"\2\2\u03f6\u03f5\3\2\2\2\u03f7\u03fa\3\2\2\2\u03f8\u03f6\3\2\2\2\u03f8"+
		"\u03f9\3\2\2\2\u03f9\37\3\2\2\2\u03fa\u03f8\3\2\2\2\u03fb\u03fd\7\62\2"+
		"\2\u03fc\u03fe\7\4\2\2\u03fd\u03fc\3\2\2\2\u03fe\u03ff\3\2\2\2\u03ff\u03fd"+
		"\3\2\2\2\u03ff\u0400\3\2\2\2\u0400\u0401\3\2\2\2\u0401\u0403\7U\2\2\u0402"+
		"\u0404\7\4\2\2\u0403\u0402\3\2\2\2\u0404\u0405\3\2\2\2\u0405\u0403\3\2"+
		"\2\2\u0405\u0406\3\2\2\2\u0406\u0407\3\2\2\2\u0407\u0409\7)\2\2\u0408"+
		"\u040a\7\3\2\2\u0409\u0408\3\2\2\2\u040a\u040b\3\2\2\2\u040b\u0409\3\2"+
		"\2\2\u040b\u040c\3\2\2\2\u040c\u040e\3\2\2\2\u040d\u040f\5\4\3\2\u040e"+
		"\u040d\3\2\2\2\u040e\u040f\3\2\2\2\u040f\u0413\3\2\2\2\u0410\u0412\7\3"+
		"\2\2\u0411\u0410\3\2\2\2\u0412\u0415\3\2\2\2\u0413\u0411\3\2\2\2\u0413"+
		"\u0414\3\2\2\2\u0414\u0439\3\2\2\2\u0415\u0413\3\2\2\2\u0416\u041a\t\13"+
		"\2\2\u0417\u0419\7\4\2\2\u0418\u0417\3\2\2\2\u0419\u041c\3\2\2\2\u041a"+
		"\u0418\3\2\2\2\u041a\u041b\3\2\2\2\u041b\u041d\3\2\2\2\u041c\u041a\3\2"+
		"\2\2\u041d\u041f\7\26\2\2\u041e\u0420\7\3\2\2\u041f\u041e\3\2\2\2\u0420"+
		"\u0421\3\2\2\2\u0421\u041f\3\2\2\2\u0421\u0422\3\2\2\2\u0422\u0424\3\2"+
		"\2\2\u0423\u0425\5\4\3\2\u0424\u0423\3\2\2\2\u0424\u0425\3\2\2\2\u0425"+
		"\u0429\3\2\2\2\u0426\u0428\7\3\2\2\u0427\u0426\3\2\2\2\u0428\u042b\3\2"+
		"\2\2\u0429\u0427\3\2\2\2\u0429\u042a\3\2\2\2\u042a\u0433\3\2\2\2\u042b"+
		"\u0429\3\2\2\2\u042c\u0430\5$\23\2\u042d\u042f\7\3\2\2\u042e\u042d\3\2"+
		"\2\2\u042f\u0432\3\2\2\2\u0430\u042e\3\2\2\2\u0430\u0431\3\2\2\2\u0431"+
		"\u0434\3\2\2\2\u0432\u0430\3\2\2\2\u0433\u042c\3\2\2\2\u0434\u0435\3\2"+
		"\2\2\u0435\u0433\3\2\2\2\u0435\u0436\3\2\2\2\u0436\u0438\3\2\2\2\u0437"+
		"\u0416\3\2\2\2\u0438\u043b\3\2\2\2\u0439\u0437\3\2\2\2\u0439\u043a\3\2"+
		"\2\2\u043a\u043c\3\2\2\2\u043b\u0439\3\2\2\2\u043c\u043e\7\63\2\2\u043d"+
		"\u043f\7\4\2\2\u043e\u043d\3\2\2\2\u043f\u0440\3\2\2\2\u0440\u043e\3\2"+
		"\2\2\u0440\u0441\3\2\2\2\u0441\u0442\3\2\2\2\u0442\u0444\7\64\2\2\u0443"+
		"\u0445\7\4\2\2\u0444\u0443\3\2\2\2\u0445\u0446\3\2\2\2\u0446\u0444\3\2"+
		"\2\2\u0446\u0447\3\2\2\2\u0447\u0448\3\2\2\2\u0448\u044c\7\65\2\2\u0449"+
		"\u044b\7\4\2\2\u044a\u0449\3\2\2\2\u044b\u044e\3\2\2\2\u044c\u044a\3\2"+
		"\2\2\u044c\u044d\3\2\2\2\u044d\u044f\3\2\2\2\u044e\u044c\3\2\2\2\u044f"+
		"\u0451\7\26\2\2\u0450\u0452\7\3\2\2\u0451\u0450\3\2\2\2\u0452\u0453\3"+
		"\2\2\2\u0453\u0451\3\2\2\2\u0453\u0454\3\2\2\2\u0454\u0456\3\2\2\2\u0455"+
		"\u0457\5\4\3\2\u0456\u0455\3\2\2\2\u0456\u0457\3\2\2\2\u0457\u045b\3\2"+
		"\2\2\u0458\u045a\7\3\2\2\u0459\u0458\3\2\2\2\u045a\u045d\3\2\2\2\u045b"+
		"\u0459\3\2\2\2\u045b\u045c\3\2\2\2\u045c\u045e\3\2\2\2\u045d\u045b\3\2"+
		"\2\2\u045e\u0462\5$\23\2\u045f\u0461\7\3\2\2\u0460\u045f\3\2\2\2\u0461"+
		"\u0464\3\2\2\2\u0462\u0460\3\2\2\2\u0462\u0463\3\2\2\2\u0463\u0465\3\2"+
		"\2\2\u0464\u0462\3\2\2\2\u0465\u0474\7\66\2\2\u0466\u0468\7\3\2\2\u0467"+
		"\u0466\3\2\2\2\u0468\u0469\3\2\2\2\u0469\u0467\3\2\2\2\u0469\u046a\3\2"+
		"\2\2\u046a\u046c\3\2\2\2\u046b\u046d\5\4\3\2\u046c\u046b\3\2\2\2\u046c"+
		"\u046d\3\2\2\2\u046d\u0471\3\2\2\2\u046e\u0470\7\3\2\2\u046f\u046e\3\2"+
		"\2\2\u0470\u0473\3\2\2\2\u0471\u046f\3\2\2\2\u0471\u0472\3\2\2\2\u0472"+
		"\u0475\3\2\2\2\u0473\u0471\3\2\2\2\u0474\u0467\3\2\2\2\u0474\u0475\3\2"+
		"\2\2\u0475!\3\2\2\2\u0476\u0478\7;\2\2\u0477\u0479\7\4\2\2\u0478\u0477"+
		"\3\2\2\2\u0479\u047a\3\2\2\2\u047a\u0478\3\2\2\2\u047a\u047b\3\2\2\2\u047b"+
		"\u047c\3\2\2\2\u047c\u0480\7U\2\2\u047d\u047f\7\4\2\2\u047e\u047d\3\2"+
		"\2\2\u047f\u0482\3\2\2\2\u0480\u047e\3\2\2\2\u0480\u0481\3\2\2\2\u0481"+
		"\u0483\3\2\2\2\u0482\u0480\3\2\2\2\u0483\u0487\7\30\2\2\u0484\u0486\7"+
		"\4\2\2\u0485\u0484\3\2\2\2\u0486\u0489\3\2\2\2\u0487\u0485\3\2\2\2\u0487"+
		"\u0488\3\2\2\2\u0488\u048a\3\2\2\2\u0489\u0487\3\2\2\2\u048a\u048e\t\3"+
		"\2\2\u048b\u048d\7\4\2\2\u048c\u048b\3\2\2\2\u048d\u0490\3\2\2\2\u048e"+
		"\u048c\3\2\2\2\u048e\u048f\3\2\2\2\u048f\u049b\3\2\2\2\u0490\u048e\3\2"+
		"\2\2\u0491\u0495\7\5\2\2\u0492\u0494\7\4\2\2\u0493\u0492\3\2\2\2\u0494"+
		"\u0497\3\2\2\2\u0495\u0493\3\2\2\2\u0495\u0496\3\2\2\2\u0496\u0498\3\2"+
		"\2\2\u0497\u0495\3\2\2\2\u0498\u049a\t\3\2\2\u0499\u0491\3\2\2\2\u049a"+
		"\u049d\3\2\2\2\u049b\u0499\3\2\2\2\u049b\u049c\3\2\2\2\u049c\u04a1\3\2"+
		"\2\2\u049d\u049b\3\2\2\2\u049e\u04a0\7\4\2\2\u049f\u049e\3\2\2\2\u04a0"+
		"\u04a3\3\2\2\2\u04a1\u049f\3\2\2\2\u04a1\u04a2\3\2\2\2\u04a2\u04a4\3\2"+
		"\2\2\u04a3\u04a1\3\2\2\2\u04a4\u04b3\7\31\2\2\u04a5\u04a7\7\3\2\2\u04a6"+
		"\u04a5\3\2\2\2\u04a7\u04a8\3\2\2\2\u04a8\u04a6\3\2\2\2\u04a8\u04a9\3\2"+
		"\2\2\u04a9\u04ab\3\2\2\2\u04aa\u04ac\5\4\3\2\u04ab\u04aa\3\2\2\2\u04ab"+
		"\u04ac\3\2\2\2\u04ac\u04b0\3\2\2\2\u04ad\u04af\7\3\2\2\u04ae\u04ad\3\2"+
		"\2\2\u04af\u04b2\3\2\2\2\u04b0\u04ae\3\2\2\2\u04b0\u04b1\3\2\2\2\u04b1"+
		"\u04b4\3\2\2\2\u04b2\u04b0\3\2\2\2\u04b3\u04a6\3\2\2\2\u04b3\u04b4\3\2"+
		"\2\2\u04b4#\3\2\2\2\u04b5\u04c0\5\24\13\2\u04b6\u04c0\5\b\5\2\u04b7\u04c0"+
		"\5\n\6\2\u04b8\u04c0\5\f\7\2\u04b9\u04c0\5\16\b\2\u04ba\u04c0\5\22\n\2"+
		"\u04bb\u04c0\5\30\r\2\u04bc\u04c0\5\36\20\2\u04bd\u04c0\5 \21\2\u04be"+
		"\u04c0\5\"\22\2\u04bf\u04b5\3\2\2\2\u04bf\u04b6\3\2\2\2\u04bf\u04b7\3"+
		"\2\2\2\u04bf\u04b8\3\2\2\2\u04bf\u04b9\3\2\2\2\u04bf\u04ba\3\2\2\2\u04bf"+
		"\u04bb\3\2\2\2\u04bf\u04bc\3\2\2\2\u04bf\u04bd\3\2\2\2\u04bf\u04be\3\2"+
		"\2\2\u04c0%\3\2\2\2\u04c1\u04c3\7\67\2\2\u04c2\u04c4\7\4\2\2\u04c3\u04c2"+
		"\3\2\2\2\u04c4\u04c5\3\2\2\2\u04c5\u04c3\3\2\2\2\u04c5\u04c6\3\2\2\2\u04c6"+
		"\u04cf\3\2\2\2\u04c7\u04cb\7U\2\2\u04c8\u04ca\7\4\2\2\u04c9\u04c8\3\2"+
		"\2\2\u04ca\u04cd\3\2\2\2\u04cb\u04c9\3\2\2\2\u04cb\u04cc\3\2\2\2\u04cc"+
		"\u04ce\3\2\2\2\u04cd\u04cb\3\2\2\2\u04ce\u04d0\7\17\2\2\u04cf\u04c7\3"+
		"\2\2\2\u04cf\u04d0\3\2\2\2\u04d0\u04d4\3\2\2\2\u04d1\u04d3\7\4\2\2\u04d2"+
		"\u04d1\3\2\2\2\u04d3\u04d6\3\2\2\2\u04d4\u04d2\3\2\2\2\u04d4\u04d5\3\2"+
		"\2\2\u04d5\u04d7\3\2\2\2\u04d6\u04d4\3\2\2\2\u04d7\u04db\7U\2\2\u04d8"+
		"\u04da\7\4\2\2\u04d9\u04d8\3\2\2\2\u04da\u04dd\3\2\2\2\u04db\u04d9\3\2"+
		"\2\2\u04db\u04dc\3\2\2\2\u04dc\u0514\3\2\2\2\u04dd\u04db\3\2\2\2\u04de"+
		"\u04e2\7\32\2\2\u04df\u04e1\7\4\2\2\u04e0\u04df\3\2\2\2\u04e1\u04e4\3"+
		"\2\2\2\u04e2\u04e0\3\2\2\2\u04e2\u04e3\3\2\2\2\u04e3\u050b\3\2\2\2\u04e4"+
		"\u04e2\3\2\2\2\u04e5\u04ed\t\3\2\2\u04e6\u04e8\7\4\2\2\u04e7\u04e6\3\2"+
		"\2\2\u04e8\u04eb\3\2\2\2\u04e9\u04e7\3\2\2\2\u04e9\u04ea\3\2\2\2\u04ea"+
		"\u04ec\3\2\2\2\u04eb\u04e9\3\2\2\2\u04ec\u04ee\t\4\2\2\u04ed\u04e9\3\2"+
		"\2\2\u04ed\u04ee\3\2\2\2\u04ee\u0508\3\2\2\2\u04ef\u04f1\7\4\2\2\u04f0"+
		"\u04ef\3\2\2\2\u04f1\u04f4\3\2\2\2\u04f2\u04f0\3\2\2\2\u04f2\u04f3\3\2"+
		"\2\2\u04f3\u04f5\3\2\2\2\u04f4\u04f2\3\2\2\2\u04f5\u04f9\7\5\2\2\u04f6"+
		"\u04f8\7\4\2\2\u04f7\u04f6\3\2\2\2\u04f8\u04fb\3\2\2\2\u04f9\u04f7\3\2"+
		"\2\2\u04f9\u04fa\3\2\2\2\u04fa\u04fc\3\2\2\2\u04fb\u04f9\3\2\2\2\u04fc"+
		"\u0504\t\3\2\2\u04fd\u04ff\7\4\2\2\u04fe\u04fd\3\2\2\2\u04ff\u0502\3\2"+
		"\2\2\u0500\u04fe\3\2\2\2\u0500\u0501\3\2\2\2\u0501\u0503\3\2\2\2\u0502"+
		"\u0500\3\2\2\2\u0503\u0505\t\4\2\2\u0504\u0500\3\2\2\2\u0504\u0505\3\2"+
		"\2\2\u0505\u0507\3\2\2\2\u0506\u04f2\3\2\2\2\u0507\u050a\3\2\2\2\u0508"+
		"\u0506\3\2\2\2\u0508\u0509\3\2\2\2\u0509\u050c\3\2\2\2\u050a\u0508\3\2"+
		"\2\2\u050b\u04e5\3\2\2\2\u050b\u050c\3\2\2\2\u050c\u0510\3\2\2\2\u050d"+
		"\u050f\7\4\2\2\u050e\u050d\3\2\2\2\u050f\u0512\3\2\2\2\u0510\u050e\3\2"+
		"\2\2\u0510\u0511\3\2\2\2\u0511\u0513\3\2\2\2\u0512\u0510\3\2\2\2\u0513"+
		"\u0515\7\33\2\2\u0514\u04de\3\2\2\2\u0514\u0515\3\2\2\2\u0515\u0517\3"+
		"\2\2\2\u0516\u0518\7\3\2\2\u0517\u0516\3\2\2\2\u0518\u0519\3\2\2\2\u0519"+
		"\u0517\3\2\2\2\u0519\u051a\3\2\2\2\u051a\u051c\3\2\2\2\u051b\u051d\5\4"+
		"\3\2\u051c\u051b\3\2\2\2\u051c\u051d\3\2\2\2\u051d\u0521\3\2\2\2\u051e"+
		"\u0520\7\3\2\2\u051f\u051e\3\2\2\2\u0520\u0523\3\2\2\2\u0521\u051f\3\2"+
		"\2\2\u0521\u0522\3\2\2\2\u0522\u052d\3\2\2\2\u0523\u0521\3\2\2\2\u0524"+
		"\u0528\5$\23\2\u0525\u0527\7\3\2\2\u0526\u0525\3\2\2\2\u0527\u052a\3\2"+
		"\2\2\u0528\u0526\3\2\2\2\u0528\u0529\3\2\2\2\u0529\u052c\3\2\2\2\u052a"+
		"\u0528\3\2\2\2\u052b\u0524\3\2\2\2\u052c\u052f\3\2\2\2\u052d\u052b\3\2"+
		"\2\2\u052d\u052e\3\2\2\2\u052e\u0530\3\2\2\2\u052f\u052d\3\2\2\2\u0530"+
		"\u053f\7:\2\2\u0531\u0533\7\3\2\2\u0532\u0531\3\2\2\2\u0533\u0534\3\2"+
		"\2\2\u0534\u0532\3\2\2\2\u0534\u0535\3\2\2\2\u0535\u0537\3\2\2\2\u0536"+
		"\u0538\5\4\3\2\u0537\u0536\3\2\2\2\u0537\u0538\3\2\2\2\u0538\u053c\3\2"+
		"\2\2\u0539\u053b\7\3\2\2\u053a\u0539\3\2\2\2\u053b\u053e\3\2\2\2\u053c"+
		"\u053a\3\2\2\2\u053c\u053d\3\2\2\2\u053d\u0540\3\2\2\2\u053e\u053c\3\2"+
		"\2\2\u053f\u0532\3\2\2\2\u053f\u0540\3\2\2\2\u0540\'\3\2\2\2\u0541\u0545"+
		"\7<\2\2\u0542\u0544\7\4\2\2\u0543\u0542\3\2\2\2\u0544\u0547\3\2\2\2\u0545"+
		"\u0543\3\2\2\2\u0545\u0546\3\2\2\2\u0546\u0548\3\2\2\2\u0547\u0545\3\2"+
		"\2\2\u0548\u054c\7\32\2\2\u0549\u054b\7\4\2\2\u054a\u0549\3\2\2\2\u054b"+
		"\u054e\3\2\2\2\u054c\u054a\3\2\2\2\u054c\u054d\3\2\2\2\u054d\u054f\3\2"+
		"\2\2\u054e\u054c\3\2\2\2\u054f\u0553\t\3\2\2\u0550\u0552\7\4\2\2\u0551"+
		"\u0550\3\2\2\2\u0552\u0555\3\2\2\2\u0553\u0551\3\2\2\2\u0553\u0554\3\2"+
		"\2\2\u0554\u0556\3\2\2\2\u0555\u0553\3\2\2\2\u0556\u0558\7\33\2\2\u0557"+
		"\u0559\7\3\2\2\u0558\u0557\3\2\2\2\u0559\u055a\3\2\2\2\u055a\u0558\3\2"+
		"\2\2\u055a\u055b\3\2\2\2\u055b\u055d\3\2\2\2\u055c\u055e\5\4\3\2\u055d"+
		"\u055c\3\2\2\2\u055d\u055e\3\2\2\2\u055e\u0562\3\2\2\2\u055f\u0561\7\3"+
		"\2\2\u0560\u055f\3\2\2\2\u0561\u0564\3\2\2\2\u0562\u0560\3\2\2\2\u0562"+
		"\u0563\3\2\2\2\u0563)\3\2\2\2\u0564\u0562\3\2\2\2\u0565\u0569\7=\2\2\u0566"+
		"\u0568\7\4\2\2\u0567\u0566\3\2\2\2\u0568\u056b\3\2\2\2\u0569\u0567\3\2"+
		"\2\2\u0569\u056a\3\2\2\2\u056a\u056c\3\2\2\2\u056b\u0569\3\2\2\2\u056c"+
		"\u0570\7\32\2\2\u056d\u056f\7\4\2\2\u056e\u056d\3\2\2\2\u056f\u0572\3"+
		"\2\2\2\u0570\u056e\3\2\2\2\u0570\u0571\3\2\2\2\u0571\u0573\3\2\2\2\u0572"+
		"\u0570\3\2\2\2\u0573\u0577\t\3\2\2\u0574\u0576\7\4\2\2\u0575\u0574\3\2"+
		"\2\2\u0576\u0579\3\2\2\2\u0577\u0575\3\2\2\2\u0577\u0578\3\2\2\2\u0578"+
		"\u057a\3\2\2\2\u0579\u0577\3\2\2\2\u057a\u057e\7\33\2\2\u057b\u057d\7"+
		"\3\2\2\u057c\u057b\3\2\2\2\u057d\u0580\3\2\2\2\u057e\u057c\3\2\2\2\u057e"+
		"\u057f\3\2\2\2\u057f+\3\2\2\2\u0580\u057e\3\2\2\2\u0581\u0585\7>\2\2\u0582"+
		"\u0584\7\4\2\2\u0583\u0582\3\2\2\2\u0584\u0587\3\2\2\2\u0585\u0583\3\2"+
		"\2\2\u0585\u0586\3\2\2\2\u0586\u0588\3\2\2\2\u0587\u0585\3\2\2\2\u0588"+
		"\u058c\7\32\2\2\u0589\u058b\7\4\2\2\u058a\u0589\3\2\2\2\u058b\u058e\3"+
		"\2\2\2\u058c\u058a\3\2\2\2\u058c\u058d\3\2\2\2\u058d\u058f\3\2\2\2\u058e"+
		"\u058c\3\2\2\2\u058f\u0593\t\3\2\2\u0590\u0592\7\4\2\2\u0591\u0590\3\2"+
		"\2\2\u0592\u0595\3\2\2\2\u0593\u0591\3\2\2\2\u0593\u0594\3\2\2\2\u0594"+
		"\u0596\3\2\2\2\u0595\u0593\3\2\2\2\u0596\u059a\7\33\2\2\u0597\u0599\7"+
		"\3\2\2\u0598\u0597\3\2\2\2\u0599\u059c\3\2\2\2\u059a\u0598\3\2\2\2\u059a"+
		"\u059b\3\2\2\2\u059b-\3\2\2\2\u059c\u059a\3\2\2\2\u059d\u05a1\7?\2\2\u059e"+
		"\u05a0\7\4\2\2\u059f\u059e\3\2\2\2\u05a0\u05a3\3\2\2\2\u05a1\u059f\3\2"+
		"\2\2\u05a1\u05a2\3\2\2\2\u05a2\u05a4\3\2\2\2\u05a3\u05a1\3\2\2\2\u05a4"+
		"\u05a8\7\32\2\2\u05a5\u05a7\7\4\2\2\u05a6\u05a5\3\2\2\2\u05a7\u05aa\3"+
		"\2\2\2\u05a8\u05a6\3\2\2\2\u05a8\u05a9\3\2\2\2\u05a9\u05ab\3\2\2\2\u05aa"+
		"\u05a8\3\2\2\2\u05ab\u05af\t\3\2\2\u05ac\u05ae\7\4\2\2\u05ad\u05ac\3\2"+
		"\2\2\u05ae\u05b1\3\2\2\2\u05af\u05ad\3\2\2\2\u05af\u05b0\3\2\2\2\u05b0"+
		"\u05b2\3\2\2\2\u05b1\u05af\3\2\2\2\u05b2\u05b6\7\33\2\2\u05b3\u05b5\7"+
		"\3\2\2\u05b4\u05b3\3\2\2\2\u05b5\u05b8\3\2\2\2\u05b6\u05b4\3\2\2\2\u05b6"+
		"\u05b7\3\2\2\2\u05b7/\3\2\2\2\u05b8\u05b6\3\2\2\2\u05b9\u05bd\7@\2\2\u05ba"+
		"\u05bc\7\4\2\2\u05bb\u05ba\3\2\2\2\u05bc\u05bf\3\2\2\2\u05bd\u05bb\3\2"+
		"\2\2\u05bd\u05be\3\2\2\2\u05be\u05c0\3\2\2\2\u05bf\u05bd\3\2\2\2\u05c0"+
		"\u05c4\7\32\2\2\u05c1\u05c3\7\4\2\2\u05c2\u05c1\3\2\2\2\u05c3\u05c6\3"+
		"\2\2\2\u05c4\u05c2\3\2\2\2\u05c4\u05c5\3\2\2\2\u05c5\u05c7\3\2\2\2\u05c6"+
		"\u05c4\3\2\2\2\u05c7\u05cb\t\3\2\2\u05c8\u05ca\7\4\2\2\u05c9\u05c8\3\2"+
		"\2\2\u05ca\u05cd\3\2\2\2\u05cb\u05c9\3\2\2\2\u05cb\u05cc\3\2\2\2\u05cc"+
		"\u05ce\3\2\2\2\u05cd\u05cb\3\2\2\2\u05ce\u05d2\7\33\2\2\u05cf\u05d1\7"+
		"\3\2\2\u05d0\u05cf\3\2\2\2\u05d1\u05d4\3\2\2\2\u05d2\u05d0\3\2\2\2\u05d2"+
		"\u05d3\3\2\2\2\u05d3\61\3\2\2\2\u05d4\u05d2\3\2\2\2\u05d5\u05d9\7A\2\2"+
		"\u05d6\u05d8\7\4\2\2\u05d7\u05d6\3\2\2\2\u05d8\u05db\3\2\2\2\u05d9\u05d7"+
		"\3\2\2\2\u05d9\u05da\3\2\2\2\u05da\u05dc\3\2\2\2\u05db\u05d9\3\2\2\2\u05dc"+
		"\u05e0\7\32\2\2\u05dd\u05df\7\4\2\2\u05de\u05dd\3\2\2\2\u05df\u05e2\3"+
		"\2\2\2\u05e0\u05de\3\2\2\2\u05e0\u05e1\3\2\2\2\u05e1\u05e3\3\2\2\2\u05e2"+
		"\u05e0\3\2\2\2\u05e3\u05e7\t\3\2\2\u05e4\u05e6\7\4\2\2\u05e5\u05e4\3\2"+
		"\2\2\u05e6\u05e9\3\2\2\2\u05e7\u05e5\3\2\2\2\u05e7\u05e8\3\2\2\2\u05e8"+
		"\u05ea\3\2\2\2\u05e9\u05e7\3\2\2\2\u05ea\u05ee\7\33\2\2\u05eb\u05ed\7"+
		"\3\2\2\u05ec\u05eb\3\2\2\2\u05ed\u05f0\3\2\2\2\u05ee\u05ec\3\2\2\2\u05ee"+
		"\u05ef\3\2\2\2\u05ef\63\3\2\2\2\u05f0\u05ee\3\2\2\2\u05f1\u05f5\7B\2\2"+
		"\u05f2\u05f4\7\4\2\2\u05f3\u05f2\3\2\2\2\u05f4\u05f7\3\2\2\2\u05f5\u05f3"+
		"\3\2\2\2\u05f5\u05f6\3\2\2\2\u05f6\u05f8\3\2\2\2\u05f7\u05f5\3\2\2\2\u05f8"+
		"\u05fc\7\32\2\2\u05f9\u05fb\7\4\2\2\u05fa\u05f9\3\2\2\2\u05fb\u05fe\3"+
		"\2\2\2\u05fc\u05fa\3\2\2\2\u05fc\u05fd\3\2\2\2\u05fd\u05ff\3\2\2\2\u05fe"+
		"\u05fc\3\2\2\2\u05ff\u0603\t\3\2\2\u0600\u0602\7\4\2\2\u0601\u0600\3\2"+
		"\2\2\u0602\u0605\3\2\2\2\u0603\u0601\3\2\2\2\u0603\u0604\3\2\2\2\u0604"+
		"\u0606\3\2\2\2\u0605\u0603\3\2\2\2\u0606\u060a\7\33\2\2\u0607\u0609\7"+
		"\3\2\2\u0608\u0607\3\2\2\2\u0609\u060c\3\2\2\2\u060a\u0608\3\2\2\2\u060a"+
		"\u060b\3\2\2\2\u060b\65\3\2\2\2\u060c\u060a\3\2\2\2\u060d\u0611\7C\2\2"+
		"\u060e\u0610\7\4\2\2\u060f\u060e\3\2\2\2\u0610\u0613\3\2\2\2\u0611\u060f"+
		"\3\2\2\2\u0611\u0612\3\2\2\2\u0612\u0614\3\2\2\2\u0613\u0611\3\2\2\2\u0614"+
		"\u0618\7\32\2\2\u0615\u0617\7\4\2\2\u0616\u0615\3\2\2\2\u0617\u061a\3"+
		"\2\2\2\u0618\u0616\3\2\2\2\u0618\u0619\3\2\2\2\u0619\u061b\3\2\2\2\u061a"+
		"\u0618\3\2\2\2\u061b\u061f\t\3\2\2\u061c\u061e\7\4\2\2\u061d\u061c\3\2"+
		"\2\2\u061e\u0621\3\2\2\2\u061f\u061d\3\2\2\2\u061f\u0620\3\2\2\2\u0620"+
		"\u0622\3\2\2\2\u0621\u061f\3\2\2\2\u0622\u0626\7\33\2\2\u0623\u0625\7"+
		"\3\2\2\u0624\u0623\3\2\2\2\u0625\u0628\3\2\2\2\u0626\u0624\3\2\2\2\u0626"+
		"\u0627\3\2\2\2\u0627\67\3\2\2\2\u0628\u0626\3\2\2\2\u0629\u062d\7D\2\2"+
		"\u062a\u062c\7\4\2\2\u062b\u062a\3\2\2\2\u062c\u062f\3\2\2\2\u062d\u062b"+
		"\3\2\2\2\u062d\u062e\3\2\2\2\u062e\u0630\3\2\2\2\u062f\u062d\3\2\2\2\u0630"+
		"\u0634\7\32\2\2\u0631\u0633\7\4\2\2\u0632\u0631\3\2\2\2\u0633\u0636\3"+
		"\2\2\2\u0634\u0632\3\2\2\2\u0634\u0635\3\2\2\2\u0635\u0637\3\2\2\2\u0636"+
		"\u0634\3\2\2\2\u0637\u063b\t\3\2\2\u0638\u063a\7\4\2\2\u0639\u0638\3\2"+
		"\2\2\u063a\u063d\3\2\2\2\u063b\u0639\3\2\2\2\u063b\u063c\3\2\2\2\u063c"+
		"\u063e\3\2\2\2\u063d\u063b\3\2\2\2\u063e\u0642\7\33\2\2\u063f\u0641\7"+
		"\3\2\2\u0640\u063f\3\2\2\2\u0641\u0644\3\2\2\2\u0642\u0640\3\2\2\2\u0642"+
		"\u0643\3\2\2\2\u06439\3\2\2\2\u0644\u0642\3\2\2\2\u0645\u0649\7E\2\2\u0646"+
		"\u0648\7\4\2\2\u0647\u0646\3\2\2\2\u0648\u064b\3\2\2\2\u0649\u0647\3\2"+
		"\2\2\u0649\u064a\3\2\2\2\u064a\u064c\3\2\2\2\u064b\u0649\3\2\2\2\u064c"+
		"\u0650\7\32\2\2\u064d\u064f\7\4\2\2\u064e\u064d\3\2\2\2\u064f\u0652\3"+
		"\2\2\2\u0650\u064e\3\2\2\2\u0650\u0651\3\2\2\2\u0651\u0653\3\2\2\2\u0652"+
		"\u0650\3\2\2\2\u0653\u0657\t\3\2\2\u0654\u0656\7\4\2\2\u0655\u0654\3\2"+
		"\2\2\u0656\u0659\3\2\2\2\u0657\u0655\3\2\2\2\u0657\u0658\3\2\2\2\u0658"+
		"\u065a\3\2\2\2\u0659\u0657\3\2\2\2\u065a\u065e\7\33\2\2\u065b\u065d\7"+
		"\3\2\2\u065c\u065b\3\2\2\2\u065d\u0660\3\2\2\2\u065e\u065c\3\2\2\2\u065e"+
		"\u065f\3\2\2\2\u065f;\3\2\2\2\u0660\u065e\3\2\2\2\u0661\u0665\7F\2\2\u0662"+
		"\u0664\7\4\2\2\u0663\u0662\3\2\2\2\u0664\u0667\3\2\2\2\u0665\u0663\3\2"+
		"\2\2\u0665\u0666\3\2\2\2\u0666\u0668\3\2\2\2\u0667\u0665\3\2\2\2\u0668"+
		"\u066c\7\32\2\2\u0669\u066b\7\4\2\2\u066a\u0669\3\2\2\2\u066b\u066e\3"+
		"\2\2\2\u066c\u066a\3\2\2\2\u066c\u066d\3\2\2\2\u066d\u066f\3\2\2\2\u066e"+
		"\u066c\3\2\2\2\u066f\u0673\t\3\2\2\u0670\u0672\7\4\2\2\u0671\u0670\3\2"+
		"\2\2\u0672\u0675\3\2\2\2\u0673\u0671\3\2\2\2\u0673\u0674\3\2\2\2\u0674"+
		"\u0676\3\2\2\2\u0675\u0673\3\2\2\2\u0676\u067a\7\33\2\2\u0677\u0679\7"+
		"\3\2\2\u0678\u0677\3\2\2\2\u0679\u067c\3\2\2\2\u067a\u0678\3\2\2\2\u067a"+
		"\u067b\3\2\2\2\u067b=\3\2\2\2\u067c\u067a\3\2\2\2\u067d\u0681\7G\2\2\u067e"+
		"\u0680\7\4\2\2\u067f\u067e\3\2\2\2\u0680\u0683\3\2\2\2\u0681\u067f\3\2"+
		"\2\2\u0681\u0682\3\2\2\2\u0682\u0684\3\2\2\2\u0683\u0681\3\2\2\2\u0684"+
		"\u0688\7\32\2\2\u0685\u0687\7\4\2\2\u0686\u0685\3\2\2\2\u0687\u068a\3"+
		"\2\2\2\u0688\u0686\3\2\2\2\u0688\u0689\3\2\2\2\u0689\u068b\3\2\2\2\u068a"+
		"\u0688\3\2\2\2\u068b\u068f\t\3\2\2\u068c\u068e\7\4\2\2\u068d\u068c\3\2"+
		"\2\2\u068e\u0691\3\2\2\2\u068f\u068d\3\2\2\2\u068f\u0690\3\2\2\2\u0690"+
		"\u0692\3\2\2\2\u0691\u068f\3\2\2\2\u0692\u0696\7\33\2\2\u0693\u0695\7"+
		"\3\2\2\u0694\u0693\3\2\2\2\u0695\u0698\3\2\2\2\u0696\u0694\3\2\2\2\u0696"+
		"\u0697\3\2\2\2\u0697?\3\2\2\2\u0698\u0696\3\2\2\2\u0699\u069d\7H\2\2\u069a"+
		"\u069c\7\4\2\2\u069b\u069a\3\2\2\2\u069c\u069f\3\2\2\2\u069d\u069b\3\2"+
		"\2\2\u069d\u069e\3\2\2\2\u069e\u06a0\3\2\2\2\u069f\u069d\3\2\2\2\u06a0"+
		"\u06a4\7\32\2\2\u06a1\u06a3\7\4\2\2\u06a2\u06a1\3\2\2\2\u06a3\u06a6\3"+
		"\2\2\2\u06a4\u06a2\3\2\2\2\u06a4\u06a5\3\2\2\2\u06a5\u06a7\3\2\2\2\u06a6"+
		"\u06a4\3\2\2\2\u06a7\u06ab\t\3\2\2\u06a8\u06aa\7\4\2\2\u06a9\u06a8\3\2"+
		"\2\2\u06aa\u06ad\3\2\2\2\u06ab\u06a9\3\2\2\2\u06ab\u06ac\3\2\2\2\u06ac"+
		"\u06ae\3\2\2\2\u06ad\u06ab\3\2\2\2\u06ae\u06b2\7\33\2\2\u06af\u06b1\7"+
		"\3\2\2\u06b0\u06af\3\2\2\2\u06b1\u06b4\3\2\2\2\u06b2\u06b0\3\2\2\2\u06b2"+
		"\u06b3\3\2\2\2\u06b3A\3\2\2\2\u06b4\u06b2\3\2\2\2\u06b5\u06c3\5(\25\2"+
		"\u06b6\u06c3\5*\26\2\u06b7\u06c3\5,\27\2\u06b8\u06c3\5.\30\2\u06b9\u06c3"+
		"\5\60\31\2\u06ba\u06c3\5\62\32\2\u06bb\u06c3\5\64\33\2\u06bc\u06c3\5\66"+
		"\34\2\u06bd\u06c3\58\35\2\u06be\u06c3\5:\36\2\u06bf\u06c3\5<\37\2\u06c0"+
		"\u06c3\5> \2\u06c1\u06c3\5@!\2\u06c2\u06b5\3\2\2\2\u06c2\u06b6\3\2\2\2"+
		"\u06c2\u06b7\3\2\2\2\u06c2\u06b8\3\2\2\2\u06c2\u06b9\3\2\2\2\u06c2\u06ba"+
		"\3\2\2\2\u06c2\u06bb\3\2\2\2\u06c2\u06bc\3\2\2\2\u06c2\u06bd\3\2\2\2\u06c2"+
		"\u06be\3\2\2\2\u06c2\u06bf\3\2\2\2\u06c2\u06c0\3\2\2\2\u06c2\u06c1\3\2"+
		"\2\2\u06c3\u06cb\3\2\2\2\u06c4\u06c6\7\4\2\2\u06c5\u06c4\3\2\2\2\u06c6"+
		"\u06c9\3\2\2\2\u06c7\u06c5\3\2\2\2\u06c7\u06c8\3\2\2\2\u06c8\u06ca\3\2"+
		"\2\2\u06c9\u06c7\3\2\2\2\u06ca\u06cc\7\27\2\2\u06cb\u06c7\3\2\2\2\u06cb"+
		"\u06cc\3\2\2\2\u06ccC\3\2\2\2\u06cd\u06d1\7I\2\2\u06ce\u06d0\7\4\2\2\u06cf"+
		"\u06ce\3\2\2\2\u06d0\u06d3\3\2\2\2\u06d1\u06cf\3\2\2\2\u06d1\u06d2\3\2"+
		"\2\2\u06d2\u06d4\3\2\2\2\u06d3\u06d1\3\2\2\2\u06d4\u06d8\7\32\2\2\u06d5"+
		"\u06d7\7\4\2\2\u06d6\u06d5\3\2\2\2\u06d7\u06da\3\2\2\2\u06d8\u06d6\3\2"+
		"\2\2\u06d8\u06d9\3\2\2\2\u06d9\u06db\3\2\2\2\u06da\u06d8\3\2\2\2\u06db"+
		"\u06df\t\3\2\2\u06dc\u06de\7\4\2\2\u06dd\u06dc\3\2\2\2\u06de\u06e1\3\2"+
		"\2\2\u06df\u06dd\3\2\2\2\u06df\u06e0\3\2\2\2\u06e0\u06e2\3\2\2\2\u06e1"+
		"\u06df\3\2\2\2\u06e2\u06e6\7\33\2\2\u06e3\u06e5\7\3\2\2\u06e4\u06e3\3"+
		"\2\2\2\u06e5\u06e8\3\2\2\2\u06e6\u06e4\3\2\2\2\u06e6\u06e7\3\2\2\2\u06e7"+
		"E\3\2\2\2\u06e8\u06e6\3\2\2\2\u06e9\u06ed\7J\2\2\u06ea\u06ec\7\4\2\2\u06eb"+
		"\u06ea\3\2\2\2\u06ec\u06ef\3\2\2\2\u06ed\u06eb\3\2\2\2\u06ed\u06ee\3\2"+
		"\2\2\u06ee\u06f0\3\2\2\2\u06ef\u06ed\3\2\2\2\u06f0\u06f4\7\32\2\2\u06f1"+
		"\u06f3\7\4\2\2\u06f2\u06f1\3\2\2\2\u06f3\u06f6\3\2\2\2\u06f4\u06f2\3\2"+
		"\2\2\u06f4\u06f5\3\2\2\2\u06f5\u06f7\3\2\2\2\u06f6\u06f4\3\2\2\2\u06f7"+
		"\u06fb\t\n\2\2\u06f8\u06fa\7\4\2\2\u06f9\u06f8\3\2\2\2\u06fa\u06fd\3\2"+
		"\2\2\u06fb\u06f9\3\2\2\2\u06fb\u06fc\3\2\2\2\u06fc\u06fe\3\2\2\2\u06fd"+
		"\u06fb\3\2\2\2\u06fe\u0702\7\5\2\2\u06ff\u0701\7\4\2\2\u0700\u06ff\3\2"+
		"\2\2\u0701\u0704\3\2\2\2\u0702\u0700\3\2\2\2\u0702\u0703\3\2\2\2\u0703"+
		"\u0705\3\2\2\2\u0704\u0702\3\2\2\2\u0705\u0709\t\3\2\2\u0706\u0708\7\4"+
		"\2\2\u0707\u0706\3\2\2\2\u0708\u070b\3\2\2\2\u0709\u0707\3\2\2\2\u0709"+
		"\u070a\3\2\2\2\u070a\u070c\3\2\2\2\u070b\u0709\3\2\2\2\u070c\u0710\7\5"+
		"\2\2\u070d\u070f\7\4\2\2\u070e\u070d\3\2\2\2\u070f\u0712\3\2\2\2\u0710"+
		"\u070e\3\2\2\2\u0710\u0711\3\2\2\2\u0711\u0713\3\2\2\2\u0712\u0710\3\2"+
		"\2\2\u0713\u0717\t\3\2\2\u0714\u0716\7\4\2\2\u0715\u0714\3\2\2\2\u0716"+
		"\u0719\3\2\2\2\u0717\u0715\3\2\2\2\u0717\u0718\3\2\2\2\u0718\u071a\3\2"+
		"\2\2\u0719\u0717\3\2\2\2\u071a\u071e\7\33\2\2\u071b\u071d\7\3\2\2\u071c"+
		"\u071b\3\2\2\2\u071d\u0720\3\2\2\2\u071e\u071c\3\2\2\2\u071e\u071f\3\2"+
		"\2\2\u071fG\3\2\2\2\u0720\u071e\3\2\2\2\u0721\u0725\7K\2\2\u0722\u0724"+
		"\7\4\2\2\u0723\u0722\3\2\2\2\u0724\u0727\3\2\2\2\u0725\u0723\3\2\2\2\u0725"+
		"\u0726\3\2\2\2\u0726\u0728\3\2\2\2\u0727\u0725\3\2\2\2\u0728\u072c\7\32"+
		"\2\2\u0729\u072b\7\4\2\2\u072a\u0729\3\2\2\2\u072b\u072e\3\2\2\2\u072c"+
		"\u072a\3\2\2\2\u072c\u072d\3\2\2\2\u072d\u072f\3\2\2\2\u072e\u072c\3\2"+
		"\2\2\u072f\u0733\t\n\2\2\u0730\u0732\7\4\2\2\u0731\u0730\3\2\2\2\u0732"+
		"\u0735\3\2\2\2\u0733\u0731\3\2\2\2\u0733\u0734\3\2\2\2\u0734\u0736\3\2"+
		"\2\2\u0735\u0733\3\2\2\2\u0736\u073a\7\5\2\2\u0737\u0739\7\4\2\2\u0738"+
		"\u0737\3\2\2\2\u0739\u073c\3\2\2\2\u073a\u0738\3\2\2\2\u073a\u073b\3\2"+
		"\2\2\u073b\u073d\3\2\2\2\u073c\u073a\3\2\2\2\u073d\u0741\t\n\2\2\u073e"+
		"\u0740\7\4\2\2\u073f\u073e\3\2\2\2\u0740\u0743\3\2\2\2\u0741\u073f\3\2"+
		"\2\2\u0741\u0742\3\2\2\2\u0742\u0744\3\2\2\2\u0743\u0741\3\2\2\2\u0744"+
		"\u0748\7\33\2\2\u0745\u0747\7\3\2\2\u0746\u0745\3\2\2\2\u0747\u074a\3"+
		"\2\2\2\u0748\u0746\3\2\2\2\u0748\u0749\3\2\2\2\u0749I\3\2\2\2\u074a\u0748"+
		"\3\2\2\2\u074b\u074f\7L\2\2\u074c\u074e\7\4\2\2\u074d\u074c\3\2\2\2\u074e"+
		"\u0751\3\2\2\2\u074f\u074d\3\2\2\2\u074f\u0750\3\2\2\2\u0750\u0752\3\2"+
		"\2\2\u0751\u074f\3\2\2\2\u0752\u0756\7\32\2\2\u0753\u0755\7\4\2\2\u0754"+
		"\u0753\3\2\2\2\u0755\u0758\3\2\2\2\u0756\u0754\3\2\2\2\u0756\u0757\3\2"+
		"\2\2\u0757\u0759\3\2\2\2\u0758\u0756\3\2\2\2\u0759\u075d\t\n\2\2\u075a"+
		"\u075c\7\4\2\2\u075b\u075a\3\2\2\2\u075c\u075f\3\2\2\2\u075d\u075b\3\2"+
		"\2\2\u075d\u075e\3\2\2\2\u075e\u0760\3\2\2\2\u075f\u075d\3\2\2\2\u0760"+
		"\u0764\7\33\2\2\u0761\u0763\7\3\2\2\u0762\u0761\3\2\2\2\u0763\u0766\3"+
		"\2\2\2\u0764\u0762\3\2\2\2\u0764\u0765\3\2\2\2\u0765K\3\2\2\2\u0766\u0764"+
		"\3\2\2\2\u0767\u076b\7M\2\2\u0768\u076a\7\4\2\2\u0769\u0768\3\2\2\2\u076a"+
		"\u076d\3\2\2\2\u076b\u0769\3\2\2\2\u076b\u076c\3\2\2\2\u076c\u076e\3\2"+
		"\2\2\u076d\u076b\3\2\2\2\u076e\u0772\7\32\2\2\u076f\u0771\7\4\2\2\u0770"+
		"\u076f\3\2\2\2\u0771\u0774\3\2\2\2\u0772\u0770\3\2\2\2\u0772\u0773\3\2"+
		"\2\2\u0773\u0775\3\2\2\2\u0774\u0772\3\2\2\2\u0775\u0779\t\3\2\2\u0776"+
		"\u0778\7\4\2\2\u0777\u0776\3\2\2\2\u0778\u077b\3\2\2\2\u0779\u0777\3\2"+
		"\2\2\u0779\u077a\3\2\2\2\u077a\u077c\3\2\2\2\u077b\u0779\3\2\2\2\u077c"+
		"\u0780\7\33\2\2\u077d\u077f\7\3\2\2\u077e\u077d\3\2\2\2\u077f\u0782\3"+
		"\2\2\2\u0780\u077e\3\2\2\2\u0780\u0781\3\2\2\2\u0781M\3\2\2\2\u0782\u0780"+
		"\3\2\2\2\u0783\u0787\7N\2\2\u0784\u0786\7\4\2\2\u0785\u0784\3\2\2\2\u0786"+
		"\u0789\3\2\2\2\u0787\u0785\3\2\2\2\u0787\u0788\3\2\2\2\u0788\u078a\3\2"+
		"\2\2\u0789\u0787\3\2\2\2\u078a\u078e\7\32\2\2\u078b\u078d\7\4\2\2\u078c"+
		"\u078b\3\2\2\2\u078d\u0790\3\2\2\2\u078e\u078c\3\2\2\2\u078e\u078f\3\2"+
		"\2\2\u078f\u0791\3\2\2\2\u0790\u078e\3\2\2\2\u0791\u0795\t\n\2\2\u0792"+
		"\u0794\7\4\2\2\u0793\u0792\3\2\2\2\u0794\u0797\3\2\2\2\u0795\u0793\3\2"+
		"\2\2\u0795\u0796\3\2\2\2\u0796\u0798\3\2\2\2\u0797\u0795\3\2\2\2\u0798"+
		"\u079c\7\33\2\2\u0799\u079b\7\3\2\2\u079a\u0799\3\2\2\2\u079b\u079e\3"+
		"\2\2\2\u079c\u079a\3\2\2\2\u079c\u079d\3\2\2\2\u079dO\3\2\2\2\u079e\u079c"+
		"\3\2\2\2\u079f\u07a3\7O\2\2\u07a0\u07a2\7\4\2\2\u07a1\u07a0\3\2\2\2\u07a2"+
		"\u07a5\3\2\2\2\u07a3\u07a1\3\2\2\2\u07a3\u07a4\3\2\2\2\u07a4\u07a6\3\2"+
		"\2\2\u07a5\u07a3\3\2\2\2\u07a6\u07aa\7\32\2\2\u07a7\u07a9\7\4\2\2\u07a8"+
		"\u07a7\3\2\2\2\u07a9\u07ac\3\2\2\2\u07aa\u07a8\3\2\2\2\u07aa\u07ab\3\2"+
		"\2\2\u07ab\u07ad\3\2\2\2\u07ac\u07aa\3\2\2\2\u07ad\u07b1\t\n\2\2\u07ae"+
		"\u07b0\7\4\2\2\u07af\u07ae\3\2\2\2\u07b0\u07b3\3\2\2\2\u07b1\u07af\3\2"+
		"\2\2\u07b1\u07b2\3\2\2\2\u07b2\u07b4\3\2\2\2\u07b3\u07b1\3\2\2\2\u07b4"+
		"\u07b8\7\33\2\2\u07b5\u07b7\7\3\2\2\u07b6\u07b5\3\2\2\2\u07b7\u07ba\3"+
		"\2\2\2\u07b8\u07b6\3\2\2\2\u07b8\u07b9\3\2\2\2\u07b9Q\3\2\2\2\u07ba\u07b8"+
		"\3\2\2\2\u07bb\u07c3\5D#\2\u07bc\u07c3\5F$\2\u07bd\u07c3\5H%\2\u07be\u07c3"+
		"\5J&\2\u07bf\u07c3\5L\'\2\u07c0\u07c3\5N(\2\u07c1\u07c3\5P)\2\u07c2\u07bb"+
		"\3\2\2\2\u07c2\u07bc\3\2\2\2\u07c2\u07bd\3\2\2\2\u07c2\u07be\3\2\2\2\u07c2"+
		"\u07bf\3\2\2\2\u07c2\u07c0\3\2\2\2\u07c2\u07c1\3\2\2\2\u07c3\u07cb\3\2"+
		"\2\2\u07c4\u07c6\7\4\2\2\u07c5\u07c4\3\2\2\2\u07c6\u07c9\3\2\2\2\u07c7"+
		"\u07c5\3\2\2\2\u07c7\u07c8\3\2\2\2\u07c8\u07ca\3\2\2\2\u07c9\u07c7\3\2"+
		"\2\2\u07ca\u07cc\7\27\2\2\u07cb\u07c7\3\2\2\2\u07cb\u07cc\3\2\2\2\u07cc"+
		"S\3\2\2\2\u07cd\u07cf\7P\2\2\u07ce\u07d0\7\4\2\2\u07cf\u07ce\3\2\2\2\u07d0"+
		"\u07d1\3\2\2\2\u07d1\u07cf\3\2\2\2\u07d1\u07d2\3\2\2\2\u07d2\u07d3\3\2"+
		"\2\2\u07d3\u07d5\7U\2\2\u07d4\u07d6\7\3\2\2\u07d5\u07d4\3\2\2\2\u07d6"+
		"\u07d7\3\2\2\2\u07d7\u07d5\3\2\2\2\u07d7\u07d8\3\2\2\2\u07d8\u07da\3\2"+
		"\2\2\u07d9\u07db\5\4\3\2\u07da\u07d9\3\2\2\2\u07da\u07db\3\2\2\2\u07db"+
		"\u07df\3\2\2\2\u07dc\u07de\7\3\2\2\u07dd\u07dc\3\2\2\2\u07de\u07e1\3\2"+
		"\2\2\u07df\u07dd\3\2\2\2\u07df\u07e0\3\2\2\2\u07e0\u07ee\3\2\2\2\u07e1"+
		"\u07df\3\2\2\2\u07e2\u07ef\5\24\13\2\u07e3\u07ef\5\4\3\2\u07e4\u07ef\5"+
		"\b\5\2\u07e5\u07ef\5\n\6\2\u07e6\u07ef\5\f\7\2\u07e7\u07ef\5\16\b\2\u07e8"+
		"\u07ef\5\22\n\2\u07e9\u07ef\5\30\r\2\u07ea\u07ef\5\36\20\2\u07eb\u07ef"+
		"\5 \21\2\u07ec\u07ef\5\"\22\2\u07ed\u07ef\7\3\2\2\u07ee\u07e2\3\2\2\2"+
		"\u07ee\u07e3\3\2\2\2\u07ee\u07e4\3\2\2\2\u07ee\u07e5\3\2\2\2\u07ee\u07e6"+
		"\3\2\2\2\u07ee\u07e7\3\2\2\2\u07ee\u07e8\3\2\2\2\u07ee\u07e9\3\2\2\2\u07ee"+
		"\u07ea\3\2\2\2\u07ee\u07eb\3\2\2\2\u07ee\u07ec\3\2\2\2\u07ee\u07ed\3\2"+
		"\2\2\u07ef\u07f0\3\2\2\2\u07f0\u07ee\3\2\2\2\u07f0\u07f1\3\2\2\2\u07f1"+
		"\u07f5\3\2\2\2\u07f2\u07f4\7\3\2\2\u07f3\u07f2\3\2\2\2\u07f4\u07f7\3\2"+
		"\2\2\u07f5\u07f3\3\2\2\2\u07f5\u07f6\3\2\2\2\u07f6\u07f8\3\2\2\2\u07f7"+
		"\u07f5\3\2\2\2\u07f8\u0807\7Q\2\2\u07f9\u07fb\7\3\2\2\u07fa\u07f9\3\2"+
		"\2\2\u07fb\u07fc\3\2\2\2\u07fc\u07fa\3\2\2\2\u07fc\u07fd\3\2\2\2\u07fd"+
		"\u07ff\3\2\2\2\u07fe\u0800\5\4\3\2\u07ff\u07fe\3\2\2\2\u07ff\u0800\3\2"+
		"\2\2\u0800\u0804\3\2\2\2\u0801\u0803\7\3\2\2\u0802\u0801\3\2\2\2\u0803"+
		"\u0806\3\2\2\2\u0804\u0802\3\2\2\2\u0804\u0805\3\2\2\2\u0805\u0808\3\2"+
		"\2\2\u0806\u0804\3\2\2\2\u0807\u07fa\3\2\2\2\u0807\u0808\3\2\2\2\u0808"+
		"U\3\2\2\2\u015eZ\\ackoty{\u0081\u0087\u008b\u0090\u0093\u0098\u009f\u00a5"+
		"\u00ab\u00b1\u00b5\u00ba\u00bd\u00c2\u00c9\u00cf\u00d4\u00db\u00de\u00e3"+
		"\u00ea\u00ef\u00f6\u00f9\u00fe\u0101\u0106\u010a\u010f\u0112\u0117\u011e"+
		"\u0125\u012c\u0130\u0135\u013c\u0143\u0147\u014b\u014e\u0153\u0157\u015e"+
		"\u0160\u0162\u0168\u016d\u0174\u0177\u0179\u017c\u0181\u0188\u018f\u0194"+
		"\u019b\u019e\u01a3\u01a6\u01aa\u01b0\u01b5\u01bc\u01bf\u01c3\u01c8\u01cd"+
		"\u01d4\u01d7\u01da\u01dc\u01de\u01e0\u01e6\u01ec\u01f3\u01fa\u0200\u0203"+
		"\u0208\u020e\u0213\u021a\u021d\u0222\u0228\u022d\u0230\u0236\u0239\u023e"+
		"\u0241\u0249\u024f\u0256\u025c\u0263\u0269\u026f\u0272\u0277\u027a\u027f"+
		"\u0285\u028a\u0291\u0294\u0299\u029c\u02a2\u02a9\u02ad\u02b2\u02ba\u02c1"+
		"\u02c7\u02cd\u02d4\u02da\u02e0\u02e7\u02ed\u02f4\u02fb\u0301\u0305\u030a"+
		"\u030e\u0313\u0316\u031b\u031e\u0322\u0327\u032e\u0331\u0336\u033d\u0342"+
		"\u0349\u034c\u034e\u0350\u0356\u035c\u0362\u0365\u036a\u0371\u0376\u037d"+
		"\u0381\u0388\u038b\u0390\u0393\u0399\u03a0\u03a9\u03b0\u03b7\u03be\u03c4"+
		"\u03ca\u03cd\u03d2\u03d9\u03de\u03e4\u03ea\u03f0\u03f3\u03f8\u03ff\u0405"+
		"\u040b\u040e\u0413\u041a\u0421\u0424\u0429\u0430\u0435\u0439\u0440\u0446"+
		"\u044c\u0453\u0456\u045b\u0462\u0469\u046c\u0471\u0474\u047a\u0480\u0487"+
		"\u048e\u0495\u049b\u04a1\u04a8\u04ab\u04b0\u04b3\u04bf\u04c5\u04cb\u04cf"+
		"\u04d4\u04db\u04e2\u04e9\u04ed\u04f2\u04f9\u0500\u0504\u0508\u050b\u0510"+
		"\u0514\u0519\u051c\u0521\u0528\u052d\u0534\u0537\u053c\u053f\u0545\u054c"+
		"\u0553\u055a\u055d\u0562\u0569\u0570\u0577\u057e\u0585\u058c\u0593\u059a"+
		"\u05a1\u05a8\u05af\u05b6\u05bd\u05c4\u05cb\u05d2\u05d9\u05e0\u05e7\u05ee"+
		"\u05f5\u05fc\u0603\u060a\u0611\u0618\u061f\u0626\u062d\u0634\u063b\u0642"+
		"\u0649\u0650\u0657\u065e\u0665\u066c\u0673\u067a\u0681\u0688\u068f\u0696"+
		"\u069d\u06a4\u06ab\u06b2\u06c2\u06c7\u06cb\u06d1\u06d8\u06df\u06e6\u06ed"+
		"\u06f4\u06fb\u0702\u0709\u0710\u0717\u071e\u0725\u072c\u0733\u073a\u0741"+
		"\u0748\u074f\u0756\u075d\u0764\u076b\u0772\u0779\u0780\u0787\u078e\u0795"+
		"\u079c\u07a3\u07aa\u07b1\u07b8\u07c2\u07c7\u07cb\u07d1\u07d7\u07da\u07df"+
		"\u07ee\u07f0\u07f5\u07fc\u07ff\u0804\u0807";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}