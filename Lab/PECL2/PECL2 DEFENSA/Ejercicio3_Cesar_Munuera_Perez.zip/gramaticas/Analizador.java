import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.FileInputStream;
import java.io.InputStream;;

public class Analizador{
    public static void main(String[] args) throws Exception{

        //Inicializamos la entrada de datos
        String inputFile = null;
        if (args.length>0) inputFile = args[0];

        //Inicializamos los streams de datos
        InputStream is = System.in;
        if (inputFile!=null) is = new FileInputStream(inputFile);

        //Inicializo ANTLR con el fichero
        ANTLRInputStream input = new ANTLRInputStream(is);

        //Conectamos con el lexer
        ElLexer lexer = new ElLexer(input);

        //Inicializamos el canal de tokens
        CommonTokenStream tokens = new CommonTokenStream(lexer);

        //Preparamos el parser
        ElParser parser = new ElParser(tokens);

        //Generar arbol a partir del axioma de la gramatica
        ParseTree tree = parser.fichero();

        //Mostrar el arbol por consola
        //System.out.println(tree.toStringTree(parser));


        // Recorrer el arbol:
        // 1- Inicializar un recorredor
        // 2- Inicializar mi escuchador
        // 3- Recorrer el arbol

        // 1
        ParseTreeWalker walker = new ParseTreeWalker();
        // 2
        AnalizadorListener escuchador = new AnalizadorListener();
        //3
        walker.walk(escuchador, tree);

    }
}