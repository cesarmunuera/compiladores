// Generated from .\ElParser.g4 by ANTLR 4.8
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link ElParser}.
 */
public interface ElParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link ElParser#fichero}.
	 * @param ctx the parse tree
	 */
	void enterFichero(ElParser.FicheroContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#fichero}.
	 * @param ctx the parse tree
	 */
	void exitFichero(ElParser.FicheroContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#comentario}.
	 * @param ctx the parse tree
	 */
	void enterComentario(ElParser.ComentarioContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#comentario}.
	 * @param ctx the parse tree
	 */
	void exitComentario(ElParser.ComentarioContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#textos}.
	 * @param ctx the parse tree
	 */
	void enterTextos(ElParser.TextosContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#textos}.
	 * @param ctx the parse tree
	 */
	void exitTextos(ElParser.TextosContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#leer}.
	 * @param ctx the parse tree
	 */
	void enterLeer(ElParser.LeerContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#leer}.
	 * @param ctx the parse tree
	 */
	void exitLeer(ElParser.LeerContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#definir}.
	 * @param ctx the parse tree
	 */
	void enterDefinir(ElParser.DefinirContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#definir}.
	 * @param ctx the parse tree
	 */
	void exitDefinir(ElParser.DefinirContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#escribir}.
	 * @param ctx the parse tree
	 */
	void enterEscribir(ElParser.EscribirContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#escribir}.
	 * @param ctx the parse tree
	 */
	void exitEscribir(ElParser.EscribirContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#si}.
	 * @param ctx the parse tree
	 */
	void enterSi(ElParser.SiContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#si}.
	 * @param ctx the parse tree
	 */
	void exitSi(ElParser.SiContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#signos}.
	 * @param ctx the parse tree
	 */
	void enterSignos(ElParser.SignosContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#signos}.
	 * @param ctx the parse tree
	 */
	void exitSignos(ElParser.SignosContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#para}.
	 * @param ctx the parse tree
	 */
	void enterPara(ElParser.ParaContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#para}.
	 * @param ctx the parse tree
	 */
	void exitPara(ElParser.ParaContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#asignacion}.
	 * @param ctx the parse tree
	 */
	void enterAsignacion(ElParser.AsignacionContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#asignacion}.
	 * @param ctx the parse tree
	 */
	void exitAsignacion(ElParser.AsignacionContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#asignacion_funciones}.
	 * @param ctx the parse tree
	 */
	void enterAsignacion_funciones(ElParser.Asignacion_funcionesContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#asignacion_funciones}.
	 * @param ctx the parse tree
	 */
	void exitAsignacion_funciones(ElParser.Asignacion_funcionesContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#mientras}.
	 * @param ctx the parse tree
	 */
	void enterMientras(ElParser.MientrasContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#mientras}.
	 * @param ctx the parse tree
	 */
	void exitMientras(ElParser.MientrasContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#comparacion}.
	 * @param ctx the parse tree
	 */
	void enterComparacion(ElParser.ComparacionContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#comparacion}.
	 * @param ctx the parse tree
	 */
	void exitComparacion(ElParser.ComparacionContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#asignacion_restasuma}.
	 * @param ctx the parse tree
	 */
	void enterAsignacion_restasuma(ElParser.Asignacion_restasumaContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#asignacion_restasuma}.
	 * @param ctx the parse tree
	 */
	void exitAsignacion_restasuma(ElParser.Asignacion_restasumaContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#repetir}.
	 * @param ctx the parse tree
	 */
	void enterRepetir(ElParser.RepetirContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#repetir}.
	 * @param ctx the parse tree
	 */
	void exitRepetir(ElParser.RepetirContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#segun}.
	 * @param ctx the parse tree
	 */
	void enterSegun(ElParser.SegunContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#segun}.
	 * @param ctx the parse tree
	 */
	void exitSegun(ElParser.SegunContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#dimension}.
	 * @param ctx the parse tree
	 */
	void enterDimension(ElParser.DimensionContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#dimension}.
	 * @param ctx the parse tree
	 */
	void exitDimension(ElParser.DimensionContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#funciones}.
	 * @param ctx the parse tree
	 */
	void enterFunciones(ElParser.FuncionesContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#funciones}.
	 * @param ctx the parse tree
	 */
	void exitFunciones(ElParser.FuncionesContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#funcion}.
	 * @param ctx the parse tree
	 */
	void enterFuncion(ElParser.FuncionContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#funcion}.
	 * @param ctx the parse tree
	 */
	void exitFuncion(ElParser.FuncionContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#abs}.
	 * @param ctx the parse tree
	 */
	void enterAbs(ElParser.AbsContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#abs}.
	 * @param ctx the parse tree
	 */
	void exitAbs(ElParser.AbsContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#trunc}.
	 * @param ctx the parse tree
	 */
	void enterTrunc(ElParser.TruncContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#trunc}.
	 * @param ctx the parse tree
	 */
	void exitTrunc(ElParser.TruncContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#redon}.
	 * @param ctx the parse tree
	 */
	void enterRedon(ElParser.RedonContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#redon}.
	 * @param ctx the parse tree
	 */
	void exitRedon(ElParser.RedonContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#rc}.
	 * @param ctx the parse tree
	 */
	void enterRc(ElParser.RcContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#rc}.
	 * @param ctx the parse tree
	 */
	void exitRc(ElParser.RcContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#sen}.
	 * @param ctx the parse tree
	 */
	void enterSen(ElParser.SenContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#sen}.
	 * @param ctx the parse tree
	 */
	void exitSen(ElParser.SenContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#cos}.
	 * @param ctx the parse tree
	 */
	void enterCos(ElParser.CosContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#cos}.
	 * @param ctx the parse tree
	 */
	void exitCos(ElParser.CosContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#tan}.
	 * @param ctx the parse tree
	 */
	void enterTan(ElParser.TanContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#tan}.
	 * @param ctx the parse tree
	 */
	void exitTan(ElParser.TanContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#asen}.
	 * @param ctx the parse tree
	 */
	void enterAsen(ElParser.AsenContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#asen}.
	 * @param ctx the parse tree
	 */
	void exitAsen(ElParser.AsenContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#acos}.
	 * @param ctx the parse tree
	 */
	void enterAcos(ElParser.AcosContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#acos}.
	 * @param ctx the parse tree
	 */
	void exitAcos(ElParser.AcosContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#atan}.
	 * @param ctx the parse tree
	 */
	void enterAtan(ElParser.AtanContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#atan}.
	 * @param ctx the parse tree
	 */
	void exitAtan(ElParser.AtanContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#ln}.
	 * @param ctx the parse tree
	 */
	void enterLn(ElParser.LnContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#ln}.
	 * @param ctx the parse tree
	 */
	void exitLn(ElParser.LnContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterExp(ElParser.ExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitExp(ElParser.ExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#azar}.
	 * @param ctx the parse tree
	 */
	void enterAzar(ElParser.AzarContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#azar}.
	 * @param ctx the parse tree
	 */
	void exitAzar(ElParser.AzarContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#func_matematicas}.
	 * @param ctx the parse tree
	 */
	void enterFunc_matematicas(ElParser.Func_matematicasContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#func_matematicas}.
	 * @param ctx the parse tree
	 */
	void exitFunc_matematicas(ElParser.Func_matematicasContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#longitud}.
	 * @param ctx the parse tree
	 */
	void enterLongitud(ElParser.LongitudContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#longitud}.
	 * @param ctx the parse tree
	 */
	void exitLongitud(ElParser.LongitudContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#sub_cadena}.
	 * @param ctx the parse tree
	 */
	void enterSub_cadena(ElParser.Sub_cadenaContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#sub_cadena}.
	 * @param ctx the parse tree
	 */
	void exitSub_cadena(ElParser.Sub_cadenaContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#concatenar}.
	 * @param ctx the parse tree
	 */
	void enterConcatenar(ElParser.ConcatenarContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#concatenar}.
	 * @param ctx the parse tree
	 */
	void exitConcatenar(ElParser.ConcatenarContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#convertir_a_numero}.
	 * @param ctx the parse tree
	 */
	void enterConvertir_a_numero(ElParser.Convertir_a_numeroContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#convertir_a_numero}.
	 * @param ctx the parse tree
	 */
	void exitConvertir_a_numero(ElParser.Convertir_a_numeroContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#convertir_a_texto}.
	 * @param ctx the parse tree
	 */
	void enterConvertir_a_texto(ElParser.Convertir_a_textoContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#convertir_a_texto}.
	 * @param ctx the parse tree
	 */
	void exitConvertir_a_texto(ElParser.Convertir_a_textoContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#mayusculas}.
	 * @param ctx the parse tree
	 */
	void enterMayusculas(ElParser.MayusculasContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#mayusculas}.
	 * @param ctx the parse tree
	 */
	void exitMayusculas(ElParser.MayusculasContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#minusculas}.
	 * @param ctx the parse tree
	 */
	void enterMinusculas(ElParser.MinusculasContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#minusculas}.
	 * @param ctx the parse tree
	 */
	void exitMinusculas(ElParser.MinusculasContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#func_cadenas}.
	 * @param ctx the parse tree
	 */
	void enterFunc_cadenas(ElParser.Func_cadenasContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#func_cadenas}.
	 * @param ctx the parse tree
	 */
	void exitFunc_cadenas(ElParser.Func_cadenasContext ctx);
	/**
	 * Enter a parse tree produced by {@link ElParser#algoritmo}.
	 * @param ctx the parse tree
	 */
	void enterAlgoritmo(ElParser.AlgoritmoContext ctx);
	/**
	 * Exit a parse tree produced by {@link ElParser#algoritmo}.
	 * @param ctx the parse tree
	 */
	void exitAlgoritmo(ElParser.AlgoritmoContext ctx);
}